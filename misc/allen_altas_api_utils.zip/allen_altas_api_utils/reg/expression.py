# %%
import numpy as np
import os
import anndata
import SimpleITK as sitk
import scanpy as sc
import ants
import pickle

from new_pro.reg import reg
from new_pro.utils import basic
from new_pro.utils import rf
from new_pro.prg import info
from new_pro.prg import vlp

def generate_mouse_vol_spot_idxs_dict(ref_vol_parameters:dict = dict(ref_type = "nissl", file_type = "nrrd", spacing = 25), file_path:str = "", is_force:bool = False) -> dict:
    rf_path = rf.get_reference_vol_path(**ref_vol_parameters)
    if not file_path:
        pf = os.path.split(rf_path)[1].split(".")[0]
        file_path = f"{basic.REG_VOL_DATA_PATH}/{pf}_spot_idx.list"
    if is_force or not os.path.exists(file_path):
        rf_np = ants.image_read(rf_path).numpy()
        rf_mask = rf_np.copy()
        rf_mask[rf_mask > 0] = 1
        mask_vector = np.ravel(rf_mask)
        brain_region_mask_index = mask_vector == 1
        res_dict = {}
        res_dict["1d_brain_region_index"] = brain_region_mask_index
        spot_idx = []
        for idx in range(mask_vector.shape[0]):
            if brain_region_mask_index[idx]:
                spot_idx.append(str.join(",",[str(index) for index in list(np.unravel_index(idx, rf_np.shape))]))
        res_dict["3d_spot_idx"] = spot_idx
        with open(file_path, "wb") as f:
            pickle.dump(res_dict, f)
    with open(file_path, "rb") as f:
        res_dict = pickle.load(f)
    return res_dict

def generate_mouse_acr_indexs_dict(spacing:int = 25, file_path:str = "", is_force:bool = False):
    if not file_path:
        file_path = f"{basic.REG_VOL_DATA_PATH}/mouse_{spacing}um_acr_indexs.list"
    if is_force or not os.path.exists(file_path):
        anf_np = ants.image_read(rf.get_reference_vol_path(ref_type = "annotation", spacing = spacing)).numpy()
        uni_arc_indexs = np.unique(anf_np)
        res_dict = {}
        anf_vector = np.ravel(anf_np)
        for i in range(1, len(uni_arc_indexs)):
            idx = uni_arc_indexs[i]
            print(f"{idx}th strat")
            spot_idx = []
            brain_region_mask_index = anf_vector == idx
            for ix in range(anf_vector.shape[0]):
                if brain_region_mask_index[ix]:
                    spot_idx.append(str.join(",",[str(index) for index in list(np.unravel_index(ix, anf_np.shape))]))
            res_dict[idx] = spot_idx
        with open(file_path, "wb") as f:
            pickle.dump(res_dict, f)
    with open(file_path, "rb") as f:
        res_dict = pickle.load(f)
    return res_dict    

def create_anndata_expression_vol_path(donor_id:int, spacing:int = 25, is_grid:bool = True, file_path:str = "", is_force:bool = False, ref_vol_parameters:dict = dict(ref_type = "nissl", file_type = "nrrd"), registration_parameters:dict = dict(type_of_transform = "SyN"),  **rg_donor_vol_parameters) -> str:
    
    if not file_path:
        donor_vol_path = vlp.get_donor_brain_vol_path(donor_id, transform_spacing = spacing, is_2d_grid = is_grid, is_accord = True, view = "expression")
        transform_path = reg.get_donor_ants_registration_transform_path(donor_id, spacing = spacing, is_inverse = False, ref_vol_parameters = ref_vol_parameters, registration_parameters = registration_parameters, **rg_donor_vol_parameters)
        _, sample_name = os.path.split(donor_vol_path)
        dir_path, _ = os.path.split(transform_path)
        sample_name = str.split(sample_name, ".")[0]
        file_path = f"{dir_path}/h5ad/{donor_id}_{sample_name}.h5ad"
        
    if is_force or not os.path.exists(file_path):
        ref_vol_parameters[spacing] = spacing
        matrix = []
        spot_indxs = generate_mouse_vol_spot_idxs_dict(ref_vol_parameters)
        brain_region_mask_index = spot_indxs["1d_brain_region_index"]
        donor_genes_info = info.get_associate_genes_by_donor_id(donor_id)
        for _, sec_id in donor_genes_info.items():
            sec_vol = sitk.ReadImage(reg.get_ants_registration_exp_vol_path(sec_id, is_grid = is_grid, spacing = spacing, ref_vol_parameters = ref_vol_parameters, registration_parameters = registration_parameters, **rg_donor_vol_parameters))
            vol_np = sitk.GetArrayFromImage(sec_vol).transpose(2,1,0)
            vol_np = np.ravel(vol_np)
            vol_np = vol_np[brain_region_mask_index]
            matrix.append(vol_np)
        vol_anndata = anndata.AnnData(np.array(matrix))
        vol_anndata.var_names = spot_indxs["3d_spot_idx"]
        vol_anndata.obs_names = [gene_name for gene_name, _ in donor_genes_info.items()]
        vol_anndata.T.write_h5ad(file_path)
    return file_path

def make_allen_anatomy_gene_expr_demo(h5ad_path:str = f"{basic.EXP_VOL_DATA_PATH}/h5ad/t101_d600s_25um_exp.h5ad"):
    raw = anndata.read_h5ad(h5ad_path, 'r+')
    raw.var_names_make_unique()
    anf_np = ants.image_read(rf.get_reference_vol_path(ref_type = "annotation", spacing = 25)).numpy()
    anf_mask = anf_np.copy()
    anf_mask[anf_mask > 0] = 1
    mask_vector = np.ravel(anf_mask)
    anf_vector = np.ravel(anf_np)
    brain_region_mask_index = mask_vector == 1
    res = anf_vector[brain_region_mask_index]
    res_list = list(res)
    raw.obs['allen_anatomy_idx'] = res_list
    anf_idx_list = list(np.unique(anf_vector).astype(np.int64))
    anf_idx_list.pop(0)
    _, tree = rf.get_allensdk_annotation_tree(25)
    # acy_list = [tree.get_structures_by_id([ix])[0]['acronym'] for ix in anf_idx_list]
    acy_list = []
    for ix in anf_idx_list:
        if tree.get_structures_by_id([ix])[0]:
            acy_list.append(tree.get_structures_by_id([ix])[0]['acronym'])
        else:
            acy_list.append('None')
    res = []
    for idx in anf_idx_list:
        if idx == 0:
            continue
        x = raw[raw.obs['allen_anatomy_idx'] == idx, :].to_memory()
        x.write_h5ad(f"{basic.EXP_VOL_DATA_PATH}/h5ad/allen_anatomy/anatomy{idx}t101_d600s_25um_exp.h5ad")
        res.append(np.mean(x.X, 0))
    res_anndata = anndata.AnnData(np.array(res))
    res_anndata.var_names = raw.var_names
    res_anndata.obs_names = anf_idx_list
    res_anndata.obs['acronym'] = acy_list
    res_anndata.write_h5ad(f"{basic.EXP_VOL_DATA_PATH}/h5ad/allen_anatomy/mean_anatomy_t101_d600s_25um_exp.h5ad")

def mean_duplicate_genes_h5ad_demo(h5ad_path:str = f"/home/t207/lab_data_preproc4/allen_data/exp_vol/h5ad/allen_anatomy/mean_anatomy_t101_d600s_25um_exp.h5ad", res_path:str = "", is_force:bool = False):
    import os
    def find_duplicates_with_positions(lst):
        positions = {}
        bool_index = []
        for index, item in enumerate(lst):
            bool_index.append(True)
            if item in positions:
                positions[item].append(index)
            else:
                positions[item] = [index]

        res_dict = {}
        for item, poss in positions.items():
            if len(poss) > 1:
                res_dict[item] = poss
                for pos in poss:
                    bool_index[pos] = False

        return res_dict, bool_index

    if not res_path:
        prd, fn = os.path.split(h5ad_path)
        res_path = f"{prd}/nodupgene_{fn}"

    if not os.path.exists(res_path) or is_force:
        fg = anndata.read_h5ad(h5ad_path, "r+")
        gene_list = list(fg.var_names)
        res_list = []
        for gene in gene_list:
            res_list.append(str.split(gene, "-")[0])
        fg.var_names = res_list
        duplicate_dict, bool_index = find_duplicates_with_positions(res_list)
        only_ad = fg[:, bool_index]
        duplicate_list = []
        gene_names = []
        for item, positions in duplicate_dict.items():
            s = fg[:, positions].to_memory()
            duplicate_list.append(np.mean(s.X, 1))
            gene_names.append(item)
        duplicate_ad = anndata.AnnData(np.array(duplicate_list).T)
        duplicate_ad.var_names = gene_names
        duplicate_ad.obs = fg.obs
        td = anndata.concat([only_ad, duplicate_ad], axis = 1, merge = 'same')
        td.write_h5ad(res_path)

    return res_path

def slice_anatomy_h5ad_demo(anatomy_idx:int = 1004, plane:str = "c"):
    if plane == "s":
        plane_index = 1
    elif plane == "h":
        plane_index = 2
    else:
        plane_index = 0
    _, tree = rf.get_allensdk_annotation_tree(25)
    fg = anndata.read_h5ad(mean_duplicate_genes_h5ad_demo(f"/home/t207/lab_data_preproc4/allen_data/exp_vol/h5ad/allen_anatomy/anatomy{anatomy_idx}t101_d600s_25um_exp.h5ad"))
    coors = list(fg.obs.index)
    res_dict = {}
    for ix in range(0, fg.X.shape[0]):
        s_index = str.split(coors[ix], ",")[plane_index]
        sli_label = f"{plane}{s_index}_{anatomy_idx}"
        if sli_label not in res_dict.keys():
            res_dict[sli_label] = []
        res_dict[sli_label].append(fg.X[ix, :])
    expr_array = []
    obs_names = []
    sli_index = []
    for s_index, exprs in res_dict.items():
        sli_index.append(str.split(s_index, "_")[0])
        expr_array.append(np.mean(np.array(exprs), 0))
        obs_names.append(s_index)
    res_anndata = anndata.AnnData(np.array(expr_array))
    res_anndata.obs_names = obs_names
    res_anndata.var_names = fg.var_names
    res_anndata.obs['sil_index'] = sli_index
    if tree.get_structures_by_id([anatomy_idx])[0]:
        res_anndata.obs['anatomy'] = tree.get_structures_by_id([anatomy_idx])[0]['acronym']
    else:
        res_anndata.obs['anatomy'] = 'None'
    res_anndata.write_h5ad(f"/home/t207/lab_data_preproc4/allen_data/exp_vol/h5ad/allen_anatomy/{plane}sli_anatomy{anatomy_idx}t101_d600s_25um_exp.h5ad")
    return res_anndata

def run_labels_slice_ad_demo(plane:str = "c", is_force:bool = False):
    if not os.path.exists(f"{plane}_slice_anatomy_t101_d600s_25um_exp.h5ad") or is_force:
        anf_np = ants.image_read(rf.get_reference_vol_path(ref_type = "annotation", spacing = 25)).numpy()
        anf_vector = np.ravel(anf_np)
        anf_idx_list = list(np.unique(anf_vector).astype(np.int64))
        anf_idx_list.pop(0)
        anndata_list = []
        for anatomy_idx in anf_idx_list[:]:
            print(f"{anatomy_idx} start")
            anndata_list.append(slice_anatomy_h5ad_demo(anatomy_idx, plane))
        anndata.concat(anndata_list, axis = 0).write_h5ad(f"{plane}_slice_anatomy_t101_d600s_25um_exp.h5ad")
    return f"{plane}_slice_anatomy_t101_d600s_25um_exp.h5ad"

def plot_cluster_region_demo(slice_list_idx:list = ['208', '130', '140'], ad_path:str = f"{basic.EXP_VOL_DATA_PATH}/t101_d600s_25um_exp_fg150.h5ad", save_fig_path:str = f"cluster_region.png"):
    import anndata
    import scanpy as sc
    from matplotlib.gridspec import GridSpec
    import matplotlib.colors as mcolors
    import matplotlib.pyplot as plt

    def show_axs_color(ax, slice, colors):
        colors.insert(0, '#ffffff')
        cmap_discrete = mcolors.ListedColormap(colors)
        norm_discrete = mcolors.BoundaryNorm(list(np.unique(slice)), cmap_discrete.N)
        ax.imshow(slice, cmap = cmap_discrete, norm = norm_discrete)
        ax.axis("off")
        
    fg = anndata.read_h5ad(ad_path, "r+")
    index_list = [[] for _ in slice_list_idx]
    shape_tuple = (528, 320, 456)
    mask_vol = np.zeros(shape_tuple)
    leiden_vol = mask_vol.copy()
    louvain_vol =  mask_vol.copy()

    for coor_str in list(fg.obs.index):
        for idx in range(len(index_list)):
            flag = False
            if slice_list_idx[idx] == str.split(coor_str, ",")[idx]:
                flag = True
            index_list[idx].append(flag)

    slice_ads = [fg[idx].to_memory() for idx in index_list]

    for slice_ad in slice_ads:
        sc.pp.normalize_total(slice_ad)
        sc.pp.log1p(slice_ad)
        sc.tl.pca(slice_ad)
        sc.pp.neighbors(slice_ad)
        sc.tl.umap(slice_ad)
        sc.tl.tsne(slice_ad)
        sc.tl.leiden(slice_ad, flavor="leidenalg", n_iterations = -1)
        sc.tl.louvain(slice_ad, flavor="vtraag")

    fig = plt.figure(figsize = (6.4 * 3, 4.8 * 3))
    gs = GridSpec(6, 6, fig, hspace = 0.3)
    nrow_st_index = 0

    for idx in range(len(slice_ads)):
        slice_ad = slice_ads[idx]
        index_list = list(slice_ad.obs.index)
        
        for nrow_index in range(nrow_st_index, nrow_st_index + 2):
            color = ["leiden"] if nrow_index % 2 == 0 else ["louvain"]
            sc.pl.pca(slice_ad, color = color, legend_loc="on data", ax = fig.add_subplot(gs[nrow_index, 2]), show = False)
            sc.pl.tsne(slice_ad, color = color, legend_loc="on data", ax = fig.add_subplot(gs[nrow_index, 3]), show = False)
            sc.pl.umap(slice_ad, color = color, legend_loc="on data", ax = fig.add_subplot(gs[nrow_index, 4]), show = False)

        for coor_str in index_list:
            coor_dinate = [int(coor) for coor in str.split(coor_str, ",")]
            mask_vol[coor_dinate[0], coor_dinate[1], coor_dinate[2]] = 1
            leiden_vol[coor_dinate[0], coor_dinate[1], coor_dinate[2]] = int(slice_ad.obs['leiden'][index_list.index(coor_str)]) + 1
            louvain_vol[coor_dinate[0], coor_dinate[1], coor_dinate[2]] = int(slice_ad.obs['louvain'][index_list.index(coor_str)]) + 1

        mask_slice = np.take(mask_vol, int(slice_list_idx[idx]), idx)
        leiden_slice = np.take(leiden_vol, int(slice_list_idx[idx]), idx)
        louvain_slice = np.take(louvain_vol, int(slice_list_idx[idx]), idx)

        show_axs_color(fig.add_subplot(gs[nrow_st_index, 5]), leiden_slice, list(slice_ad.uns['leiden_colors']))
        show_axs_color(fig.add_subplot(gs[nrow_st_index + 1, 5]), louvain_slice, list(slice_ad.uns['louvain_colors']))
        ax = fig.add_subplot(gs[nrow_st_index:nrow_st_index + 2, 0:2])
        ax.imshow(mask_slice, cmap = "Greys")
        ax.axis("off")
        nrow_st_index = nrow_st_index + 2

    if save_fig_path:
        fig.savefig(save_fig_path, dpi = 300, bbox_inches = 'tight', pad_inches = 0.05)