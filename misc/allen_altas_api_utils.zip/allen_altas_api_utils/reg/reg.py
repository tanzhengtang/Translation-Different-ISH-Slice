import ants
import os
import typing
import SimpleITK as sitk
import numpy as np

from new_pro.utils import rf
from new_pro.prg import vlp
from new_pro.utils import basic
from new_pro.prg import info

#TODO. for all functions have many parameters, waiting for log the parameters and optim the way of changing parameters. 

DEMO_ANATOMY_ACRONYM = ["AI", "ACA", "RSP", "HIP", "ENT", "HY", "STRd", "STRv"]

def convert_sitk_to_ants_vol(vol:sitk.Image) -> ants.core.ants_image.ANTsImage:
    if vol.GetNumberOfComponentsPerPixel() == 3:
         return ants.from_numpy(sitk.GetArrayFromImage(vol).transpose(2,1,0,3), spacing = vol.GetSpacing(), is_rgb = vol.GetNumberOfComponentsPerPixel() == 3)
    return ants.from_numpy(sitk.GetArrayFromImage(vol).transpose(2,1,0), spacing = vol.GetSpacing(), is_rgb = vol.GetNumberOfComponentsPerPixel() == 3)

def convert_ants_to_sitk_vol(vol:ants.core.ants_image.ANTsImage) -> sitk.Image:
    vol_np = vol.numpy()
    if len(vol_np.shape) == 4 and vol_np.shape[3] == 3:
        is_vector = True
    else:
        is_vector = False
    sitk_vol = sitk.GetImageFromArray(vol_np, is_vector)
    sitk_vol.SetSpacing((ants.get_spacing(vol)[2], ants.get_spacing(vol)[1], ants.get_spacing(vol)[0]))
    return sitk_vol

def ants_average_channels(vol:ants.core.ants_image.ANTsImage) -> ants.core.ants_image.ANTsImage:
    return ants.average_images(ants.split_channels(vol), False, sum_image_threshold = 0)

def get_donor_ants_registration_transform_path(donor_id:int, file_path:str = "", is_force:bool = False, spacing:int = 25, is_inverse:bool = False, is_accord:bool = True, is_tvr:bool = False, ref_vol_parameters:dict = dict(ref_type = "nissl", file_type = "nrrd"), registration_parameters:dict = dict(type_of_transform = "SyN"), write_vol_path:str = "", **donor_vol_parameters) -> str:
    if not file_path:
        file_path = f"{basic.REG_VOL_DATA_PATH}/{donor_id}/transform"
    donor_path = vlp.get_donor_brain_vol_path(donor_id, is_accord = is_accord, is_tvr = is_tvr, transform_spacing = spacing, **donor_vol_parameters)
    _, sample_name = os.path.split(donor_path)
    ref_prefix = str.join("_", [ref_vol_parameters["ref_type"], str(spacing), ref_vol_parameters["file_type"]])
    sample_prefix = str.split(sample_name, ".")[0]
    registration_prefix = registration_parameters["type_of_transform"]
    file_path = f"{file_path}/{ref_prefix}/{sample_prefix}/{registration_prefix}/"
    os.makedirs(file_path, exist_ok = True)
    mov_to_fix_h5 = f"{file_path}Composite.h5"
    fix_to_mov_h5 = f"{file_path}InverseComposite.h5"
    if is_force or not os.path.exists(mov_to_fix_h5) or not os.path.exists(fix_to_mov_h5):
        ss_vol = ants_average_channels(ants.image_read(donor_path))
        ref_vol = ants.image_read(rf.get_reference_vol_path(spacing = spacing, **ref_vol_parameters))
        res = ants.registration(ref_vol, ss_vol, outprefix = file_path, write_composite_transform = True, **registration_parameters)
        if write_vol_path:
            ants.image_write(res['warpedmovout'], write_vol_path)
            write_vol_path = ""
    if write_vol_path:
        ss_vol = ants_average_channels(ants.image_read(donor_path))
        ref_vol = ants.image_read(rf.get_reference_vol_path(spacing = spacing, **ref_vol_parameters))
        ants.image_write(ants.apply_transforms(ref_vol, ss_vol, mov_to_fix_h5, interpolator = "nearestNeighbor"), write_vol_path)
    if is_inverse:
        return fix_to_mov_h5
    return mov_to_fix_h5

def get_ants_registration_exp_vol_path(sec_id:int, file_path:str = "", is_force:bool = False, is_grid:bool = True, spacing:int = 25,ref_vol_parameters:dict = dict(ref_type = "nissl", file_type = "nrrd"), registration_parameters:dict = dict(type_of_transform = "SyN"), **donor_vol_parameters) -> str:
    donor_id = basic.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[id$eq'{sec_id}']", include = f'specimen')[0]['specimen']['donor_id']
    exp_path = vlp.get_ish_vol_path(sec_id, 'expression', "", False, is_grid, spacing, is_accord = True)
    transform_path = get_donor_ants_registration_transform_path(donor_id, spacing = spacing, ref_vol_parameters = ref_vol_parameters, is_inverse = False, is_accord = True, is_tvr = False, registration_parameters = registration_parameters, **donor_vol_parameters)
    if not file_path:
        _, sample_name = os.path.split(exp_path)
        dir_path, _ = os.path.split(transform_path)
        file_path = f"{dir_path}/{sec_id}_{sample_name}"
    if is_force or not os.path.exists(file_path):
        exp_vol = ants.image_read(exp_path)
        ref_vol = ants.image_read(rf.get_reference_vol_path(spacing = spacing, **ref_vol_parameters))
        tvr_exp_vol = ants.apply_transforms(ref_vol, exp_vol, transform_path, interpolator = "nearestNeighbor")
        ants.image_write(tvr_exp_vol, file_path)
    return file_path

def get_registration_vols_on_donor_vol(donor_id:int, reg_vols:typing.List[ants.core.ants_image.ANTsImage], spacing:int = 25, just_allen_tvr:bool = False, is_accord:bool = True, is_tvr:bool = False, **registration_parameters) -> typing.List[ants.core.ants_image.ANTsImage]:
    res_vols = []
    raw_donor_vol = ants_average_channels(ants.image_read(vlp.get_donor_brain_vol_path(donor_id, transform_spacing = spacing)))
    if just_allen_tvr or is_tvr:
        ants_trv_transform = ants.new_ants_transform(parameters = vlp.build_alignment_3d(info.get_donors_info()[donor_id]['alignment3d'], "tvr"))
    if just_allen_tvr:
        for reg_vol in reg_vols:
            res_vols.append(ants_trv_transform.apply_to_image(reg_vol, raw_donor_vol, 'nearestneighbor'))
        return res_vols
    
    if is_tvr and is_accord:
        raise("is_tvr and is_accord are all true, this will cause error!")
    dfm_file_path = get_donor_ants_registration_transform_path(donor_id, spacing = spacing, is_accord = is_accord, is_tvr = is_tvr, is_inverse = True, **registration_parameters)
    donor_vol = ants_average_channels(ants.image_read(vlp.get_donor_brain_vol_path(donor_id, is_accord = is_accord, is_tvr = is_tvr, transform_spacing = spacing)))
    for reg_vol in reg_vols:
        r1_vol = ants.apply_transforms(donor_vol, reg_vol, dfm_file_path, "nearestNeighbor")
        if is_tvr:
            res_vol = ants_trv_transform.apply_to_image(r1_vol, raw_donor_vol, 'nearestneighbor')
        if is_accord:
            res_vol = ants.from_numpy(np.flip(r1_vol.numpy(), axis = 0).transpose(2, 1, 0), spacing=ants.get_spacing((spacing, spacing, spacing)))
        res_vols.append(res_vol)
    return res_vols

def get_reference_on_donor_vol_path(donor_id:int, blf_type:typing.Literal["boundary", "label"] = "boundary", file_path:str = "", file_type = "nrrd", is_force:bool = False, spacing:int = 25, just_allen_tvr:bool = False, is_accord:bool = True, is_tvr:bool = False, ref_type:str = "nissl", **registration_parameters) -> str:
    if blf_type == "boundary":
        ref_vol = ants.image_read(rf.get_boundary_vol_path(spacing, file_type = file_type))
    else:
        ref_vol = ants.image_read(rf.get_label_vol_path(spacing, file_type = file_type))
    if just_allen_tvr:
        if not file_path:
            file_path = f"{basic.REG_VOL_DATA_PATH}/{donor_id}"
        os.makedirs(file_path, exist_ok = True)
        ref_file_path = f"{file_path}/allen_trv_{blf_type}_{spacing}um.{file_type}" 
        if is_force or not os.path.exists(ref_file_path):
            ants_trv_transform = ants.new_ants_transform(parameters = vlp.build_alignment_3d(info.get_donors_info()[donor_id]['alignment3d'], "tvr"))
            donor_vol = ants_average_channels(ants.image_read(vlp.get_donor_brain_vol_path(donor_id, transform_spacing = spacing)))
            trv_boundary_vol = ants_trv_transform.apply_to_image(ref_vol, donor_vol, 'nearestneighbor')
            ants.image_write(trv_boundary_vol, ref_file_path)
        return ref_file_path
    
    if is_tvr and is_accord:
        raise("is_tvr and is_accord are all true, this will cause error!")
    dfm_prefix = ""
    if is_tvr:
        dfm_prefix = "trv_"
    if is_accord:
        dfm_prefix = "accord_"
    dfm_file_path = get_donor_ants_registration_transform_path(donor_id, file_path = file_path, spacing = spacing, is_accord = is_accord, is_tvr = is_tvr, ref_vol_parameters = dict(file_type = file_type, ref_type = ref_type), is_inverse = True, is_force = is_force, **registration_parameters)
    dfm_dir, _ = os.path.split(dfm_file_path)
    dfm_vol_path = f"{dfm_dir}/{dfm_prefix}dfm_{blf_type}.{file_type}"
    if is_force or not os.path.exists(dfm_vol_path):
        donor_vol = ants_average_channels(ants.image_read(vlp.get_donor_brain_vol_path(donor_id, is_accord = is_accord, is_tvr = is_tvr, transform_spacing = spacing)))
        dfm_ref_vol = ants.apply_transforms(donor_vol, ref_vol, dfm_file_path, "nearestNeighbor")
        if is_tvr:
            ants_trv_transform = ants.new_ants_transform(parameters = vlp.build_alignment_3d(info.get_donors_info()[donor_id]['alignment3d'], "tvr"))
            donor_vol = ants_average_channels(ants.image_read(vlp.get_donor_brain_vol_path(donor_id, transform_spacing = spacing)))
            dfm_ref_vol = ants_trv_transform.apply_to_image(dfm_ref_vol, donor_vol, 'nearestneighbor')
        if is_accord:
            dfm_ref_vol = ants.from_numpy(np.flip(dfm_ref_vol.numpy(), axis = 0).transpose(2, 1, 0), spacing=ants.get_spacing((spacing, spacing, spacing)))
        ants.image_write(dfm_ref_vol, dfm_vol_path)
    return dfm_vol_path

def boolean_dice_score(pred:np.ndarray, target:np.ndarray, smooth_num:float = 1e-8) -> float:
    return 2 * np.sum(pred * target) / (np.sum(pred + target)  + smooth_num)

def cal_anatomy_label_dice_score(pred_vols:typing.List[np.ndarray], target_vol:np.ndarray, resolution:int = 25, acronyms:list = ["CA","DG","FC"], structure_graph_ids:int = 1, smooth_num:float = 1e-8) -> float:
    pred_sss = [rf.make_allensdk_annotation_space(pred_vol, resolution, structure_graph_ids) for pred_vol in pred_vols]
    target_ss = rf.make_allensdk_annotation_space(target_vol, resolution, structure_graph_ids)
    boolean_preds = [pred_ss.make_structure_mask(rf.get_allensdk_anatomy_acronyms_ids(acronyms, structure_graph_ids)) for pred_ss in pred_sss]
    boolean_target = target_ss.make_structure_mask(rf.get_allensdk_anatomy_acronyms_ids(acronyms, structure_graph_ids))
    return [boolean_dice_score(boolean_pred, boolean_target, smooth_num) for boolean_pred in boolean_preds]
