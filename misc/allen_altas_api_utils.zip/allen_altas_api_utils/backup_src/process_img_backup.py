# %%
import SimpleITK as sitk
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
import typing
import numpy as np
import pickle
import ants
import torch
# import concurrent 
# import time

from torchvision import transforms
from PIL import Image
from allensdk.api.queries.rma_api import RmaApi
# from allensdk.api.queries.image_download_api import ImageDownloadApi

import utils
import cgan_net

DEMO_SEC_ID = 74881161
DEMO_DONOR_IDS = [6219, 7100, 7442]

# %%
def find_files_with_suffix(directory, suffix):
    matching_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(suffix):
                matching_files.append(os.path.join(root, file))
    return matching_files

def generate_circle(center, radius, num_points=100):
    theta = np.linspace(0, 2 * np.pi, num_points)  
    x = center[0] + radius * np.cos(theta) 
    y = center[1] + radius * np.sin(theta) 
    return x, y    

def generate_rectangle(center, width, height, num_points_per_side = 10):
    half_width = width / 2
    half_height = height / 2
    top_left = (center[0] - half_width, center[1] + half_height)
    top_right = (center[0] + half_width, center[1] + half_height)
    bottom_left = (center[0] - half_width, center[1] - half_height)
    bottom_right = (center[0] + half_width, center[1] - half_height)
    x = []
    y = []
    for i in range(num_points_per_side + 1):
        x.append(np.linspace(top_left[0], top_right[0], num_points_per_side + 1)[i])
        y.append(top_left[1])
    for i in range(num_points_per_side + 1):
        x.append(top_right[0])
        y.append(np.linspace(top_right[1], bottom_right[1], num_points_per_side + 1)[i])
    for i in range(num_points_per_side + 1):
        x.append(np.linspace(bottom_left[0], bottom_right[0], num_points_per_side + 1)[i])
        y.append(bottom_left[1])
    for i in range(num_points_per_side + 1):
        x.append(bottom_left[0])
        y.append(np.linspace(bottom_left[1], top_left[1], num_points_per_side + 1)[i])
    
    return x, y

def resample_image_specific_spacing(image:sitk.Image, new_spacing:tuple) -> sitk.Image:
    original_size = image.GetSize()
    original_spacing = image.GetSpacing()
    original_origin = image.GetOrigin()
    original_direction = image.GetDirection()

    if image.GetDimension() == 2:
        new_size = [int(round(original_size[0] * (original_spacing[0] / new_spacing[0]))),
                    int(round(original_size[1] * (original_spacing[1] / new_spacing[1])))]
    elif image.GetDimension() == 3:
        new_size = [int(round(original_size[0] * (original_spacing[0] / new_spacing[0]))),
                    int(round(original_size[1] * (original_spacing[1] / new_spacing[1]))),
                    int(round(original_size[1] * (original_spacing[2] / new_spacing[2])))]
    else:
        print(f"image.GetDimension() is equal to {image.GetDimension()}")
        return 0

    resampler = sitk.ResampleImageFilter()
    resampler.SetReferenceImage(image)
    resampler.SetSize(new_size)
    resampler.SetOutputSpacing(new_spacing)
    resampler.SetOutputOrigin(original_origin)
    resampler.SetOutputDirection(original_direction)
    resampler.SetTransform(sitk.Transform())
    resampler.SetInterpolator(sitk.sitkNearestNeighbor) 
    resampled_image = resampler.Execute(image)

    return resampled_image

def basic_ants_make_dataset(A_vol:ants.core.ants_image.ANTsImage, B_vol:ants.core.ants_image.ANTsImage, dir_path:str, axis_index:int = 0, slice_range:typing.Optional[tuple] = None, A_image_suffix:str = "png", B_image_suffix:str = "png", A_image_prefix = "", B_image_prefix = ""):
    
    A_path = f"{dir_path}/trainA"
    B_path = f"{dir_path}/trainB"
    os.makedirs(A_path, exist_ok = True)
    os.makedirs(B_path, exist_ok = True)
    
    for As_idx, Bs_idx in zip(A_vol.shape, B_vol.shape):
        if As_idx != Bs_idx:
            raise('A_vol shape must be same with B_vol shape')
    
    slice_range = slice_range if slice_range else (0, A_vol.shape[axis_index])
    for idx in range(slice_range[0], slice_range[1]):
        A_image = ants.slice_image(A_vol, axis = axis_index, idx = idx)
        B_image = ants.slice_image(B_vol, axis = axis_index, idx = idx)
        if np.max(A_image.numpy()) > 0 and np.max(B_image.numpy()) > 0:
            ants.image_write(A_image, f'{A_path}/{A_image_prefix}{axis_index}_{idx}.{A_image_suffix}')
            ants.image_write(B_image, f'{B_path}/{B_image_prefix}{axis_index}_{idx}.{B_image_suffix}')

# %%

def test_build_alignment_2d(alignment2d:dict, ver = "tsv") -> tuple:
    # TODO. directly return a transform matrix
    return (alignment2d[f'{ver}_00'],alignment2d[f'{ver}_01'],alignment2d[f'{ver}_02'],alignment2d[f'{ver}_03'],alignment2d[f'{ver}_04'],alignment2d[f'{ver}_05'])

def test_build_alignment_3d(alignment3d:dict, ver = "tvr") -> tuple:
    # TODO. directly return a transform matrix
    return (alignment3d[f'{ver}_00'],alignment3d[f'{ver}_01'],alignment3d[f'{ver}_02'],alignment3d[f'{ver}_03'],alignment3d[f'{ver}_04'],alignment3d[f'{ver}_05'], alignment3d[f'{ver}_06'],alignment3d[f'{ver}_07'],alignment3d[f'{ver}_08'],alignment3d[f'{ver}_09'],alignment3d[f'{ver}_10'],alignment3d[f'{ver}_11'])

def syn_expression_img(ish_image:typing.Optional[sitk.Image] = None, exp_image:typing.Optional[sitk.Image] = None, use_img:typing.Literal['exp', 'ish'] = 'ish', ct_index = 2):
    intensity_ct_dict = {1:[0.21, 0.72, 0.07], 2:[0.3,0.59,0.11]} # the order in list is red, green, blue
    # 1 is in https://community.brain-map.org/t/quantification-of-gene-expression-by-in-situ-hybridization-finding-and-using-the-raw-values/153/7 
    # 2 is in supplement of An anatomic gene expression atlas of the adult mouse brain article
    red_ct, green_ct, blue_ct = intensity_ct_dict[ct_index][0], intensity_ct_dict[ct_index][1], intensity_ct_dict[ct_index][2]
    if not ish_image:
        ish_image = sitk.ReadImage(f'{utils.STORE_IMG_DATA_PATH}/74881161/raw/74825013.jpg', sitk.sitkVectorFloat32)
    if not exp_image:
        exp_image = sitk.ReadImage(f'{utils.STORE_IMG_DATA_PATH}/74881161/expression/74825013.jpg', sitk.sitkVectorFloat32)
    pc_img = exp_image if use_img == 'exp' else ish_image
    gray_image = sitk.VectorIndexSelectionCast(exp_image, 0) + sitk.VectorIndexSelectionCast(exp_image, 1) + sitk.VectorIndexSelectionCast(exp_image, 2)  
    binary_mask = sitk.BinaryThreshold(gray_image, lowerThreshold = 1, upperThreshold = 255 * 3, insideValue = 1, outsideValue = 0)
    binary_mask = sitk.Cast(binary_mask, sitk.sitkFloat32)
    intensity_img = red_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 0, sitk.sitkFloat32) + green_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 1, sitk.sitkFloat32) + blue_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 2, sitk.sitkFloat32)
    
    return intensity_img

def get_donor_brain_vol(donor_id:int, set_size:typing.Optional[tuple] = None, img_dtype = sitk.sitkVectorUInt8, transform_spacing = [25, 25], img_path = utils.STORE_IMG_DATA_PATH, view:typing.Literal['raw', 'expression'] = "raw", ver2d:str = "tvs", ver3d:tuple = ("trv", "tvr"), vol_path = utils.STORE_DONOR_VOL_PATH, is_force:bool = False, ref_vol:typing.Optional[sitk.Image] = None, background:typing.Literal['w', 'b'] = 'b') -> list:
    
    if view == "raw":
        suffix_file = f"{background}.nii.gz"
    else:
        background = 'w'
        suffix_file = f"{view}.nii.gz"

    ss_path = f"{vol_path}/{donor_id}/ss_{suffix_file}" 
    tvr_path = f"{vol_path}/{donor_id}/tvr_{suffix_file}"
    trv_path = f"{vol_path}/{donor_id}/trv_{suffix_file}"
    
    if not is_force and os.path.exists(ss_path) and os.path.exists(tvr_path) and os.path.exists(trv_path): 
        return ss_path, tvr_path, trv_path

    os.makedirs(f"{vol_path}/{donor_id}", exist_ok = True)
    RMA = RmaApi()
    
    section_data_metas = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}]), alignment3d, section_images(alignment2d), treatments')
    section_thickness = list(set([section_data_meta['section_thickness'] for section_data_meta in section_data_metas]))
    sec_treatment_kinds = {section_data_meta['id']:section_data_meta['treatments'][0]['name'] for section_data_meta in section_data_metas}
    view_type = None if view == "raw" else view
    imgs_meta = pd.concat([pd.DataFrame(section_data_meta['section_images']) for section_data_meta in section_data_metas]).sort_values('section_number')
    stack_vol_list = []
    prev_section_number = -1
    if not set_size:
        set_size = (12800, 12800) if section_data_metas[0]['plane_of_section_id'] == 1 else (16000, 12000)
    sample_image = sitk.Image((set_size[1], set_size[0]), img_dtype) 
    # start to stack sample vol
    for row in imgs_meta[['data_set_id','id','section_number','alignment2d']].itertuples():
        if view == "expression" and sec_treatment_kinds[row[1]] != "ISH":
            img = sitk.Image((set_size[1], set_size[0]), img_dtype) 
        elif utils.recon_download_image(row[2], view = view_type, file_path = f"{img_path}/{row[1]}/{view}/{row[2]}.jpg"):
            img = 255 - sitk.ReadImage(f"{img_path}/{row[1]}/{view}/{row[2]}.jpg", sitk.sitkVectorUInt8) if background == 'b' else sitk.ReadImage(f"{img_path}/{row[1]}/{view}/{row[2]}.jpg", sitk.sitkVectorUInt8)
            if view == "expression" and utils.recon_download_image(row[2], view = "raw", file_path = f"{img_path}/{row[1]}/raw/{row[2]}.jpg"):
                ish_img = sitk.ReadImage(f"{img_path}/{row[1]}/raw/{row[2]}.jpg")
                img = syn_expression_img(ish_img, img)
        else:
            img = sitk.Image((set_size[1], set_size[0]), img_dtype) 
        transform2d = sitk.AffineTransform(2)
        transform2d.SetParameters(test_build_alignment_2d(row[4], ver2d))
        timage = sitk.Resample(img, sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0)
        stack_vol_list = stack_vol_list + [resample_image_specific_spacing(sample_image, transform_spacing) for _ in range(row[3] - prev_section_number - 1)]
        stack_vol_list.append(resample_image_specific_spacing(timage, transform_spacing))
        prev_section_number = row[3]
    stack_vol_list.append(resample_image_specific_spacing(sample_image, transform_spacing))
    stack_vol = sitk.JoinSeries(stack_vol_list)
    stack_vol.SetSpacing((transform_spacing[0], transform_spacing[1], section_thickness[0])) 
    
    tvr_alignment3ds = list(set([test_build_alignment_3d(section_data_meta['alignment3d'], ver3d[0]) for section_data_meta in section_data_metas]))
    trv_alignment3ds = list(set([test_build_alignment_3d(section_data_meta['alignment3d'], ver3d[1]) for section_data_meta in section_data_metas]))
    if len(tvr_alignment3ds) > 1 or len(trv_alignment3ds) > 1 or len(section_thickness) > 1:
        raise("check alignment3ds and section_thickness, it may have different donor in one data set")
    tvr_transform3d = sitk.AffineTransform(3)
    tvr_transform3d.SetParameters(tvr_alignment3ds[0])
    trv_transform3d = sitk.AffineTransform(3)
    trv_transform3d.SetParameters(trv_alignment3ds[0])
      
    if not ref_vol:
        ref_vol = sitk.ReadImage(utils.get_reference_space())
        
    sitk.WriteImage(sitk.Resample(stack_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), tvr_path)
    sitk.WriteImage(sitk.Resample(ref_vol, stack_vol, trv_transform3d, sitk.sitkNearestNeighbor), trv_path)    
    sitk.WriteImage(stack_vol, ss_path)
    
    return ss_path, tvr_path, trv_path

def test_syn_expression_intensity_img(ish_image = None, exp_image = None, use_img:typing.Literal['exp', 'ish'] = 'ish', px_spacing = 1.0, grid_spacing = 200, ct_index = 2) -> sitk.Image:
    
    intensity_ct_dict = {1:[0.21, 0.72, 0.07], 2:[0.3,0.59,0.11]} # the order in list is red, green, blue
    # 1 is in https://community.brain-map.org/t/quantification-of-gene-expression-by-in-situ-hybridization-finding-and-using-the-raw-values/153/7 
    # 2 is in supplement of An anatomic gene expression atlas of the adult mouse brain article
    red_ct, green_ct, blue_ct = intensity_ct_dict[ct_index][0], intensity_ct_dict[ct_index][1], intensity_ct_dict[ct_index][2]
    if not ish_image:
        ish_image = sitk.ReadImage(f'{utils.STORE_IMG_DATA_PATH}/74881161/raw/74825013.jpg', sitk.sitkVectorFloat32)
    if not exp_image:
        exp_image = sitk.ReadImage(f'{utils.STORE_IMG_DATA_PATH}/74881161/expression/74825013.jpg', sitk.sitkVectorFloat32)
    pc_img = exp_image if use_img == 'exp' else ish_image
    gray_image = sitk.VectorIndexSelectionCast(exp_image, 0) + sitk.VectorIndexSelectionCast(exp_image, 1) + sitk.VectorIndexSelectionCast(exp_image, 2)  
    binary_mask = sitk.BinaryThreshold(gray_image, lowerThreshold = 1, upperThreshold = 255 * 3, insideValue = 1, outsideValue = 0)
    binary_mask = sitk.Cast(binary_mask, sitk.sitkFloat32)
    intensity_img = red_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 0) + green_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 1) + blue_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 2)
    raw_size = np.uint32(np.array(intensity_img.GetSize()))
    grid_px_size = int(np.floor(grid_spacing / px_spacing))
    grid_img_size = np.uint32(np.ceil(raw_size / grid_px_size))
    intensity_array = sitk.GetArrayFromImage(intensity_img).T
    pro_intensity_array = np.zeros(grid_img_size * grid_px_size)
    pro_intensity_array[:intensity_array.shape[0], :intensity_array.shape[1]] = intensity_array
    grid_array = []
    for h in range(0, pro_intensity_array.shape[1], grid_px_size):
        grid_row = list()
        for w in range(0, pro_intensity_array.shape[0], grid_px_size):
            grid_row.append(np.mean(pro_intensity_array[w:w + grid_px_size, h:h + grid_px_size]))
        grid_array.append(grid_row)
    grid_array = np.array(grid_array)
    grid_img = sitk.GetImageFromArray(grid_array)
    grid_img.SetSpacing((grid_spacing, grid_spacing))
    return grid_img

def get_ish_stack_expression_vol(sec_id:typing.Optional[int] = None, gene_name:typing.Optional[str] = None, plane_of_section_id:typing.Literal[1, 2] = 1, file_path = utils.STORE_EXP_VOL_PATH, is_force:bool = False, ref_vol:typing.Optional[sitk.Image] = None) -> sitk.Image:
    '''
        plane_of_section_id: 1 for coronal, 2 for sagittal.
    '''
    if (sec_id and gene_name) or (not sec_id and not gene_name):
        raise('check sec_id and gene_name parameters again')
    if sec_id:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen, alignment3d,genes, section_images(alignment2d)')
    if gene_name:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_of_section_id}]", include=f"specimen, alignment3d, genes[acronym$eq'{gene_name}'], section_images(alignment2d)")
    
    if not sec_info:
        raise('No sec_info for this parameters')
    
    sec_id = sec_info[0]['id']
    exp_path = f"{file_path}/{sec_id}/ss.nii.gz"
    tvr_path = f"{file_path}/{sec_id}/tvr.nii.gz"
    trv_path = f"{file_path}/{sec_id}/trv.nii.gz"
    os.makedirs(f"{file_path}/{sec_id}", exist_ok = True)
    if not is_force and os.path.exists(exp_path) and os.path.exists(tvr_path) and os.path.exists(trv_path):
        return exp_path, tvr_path, trv_path
    
    donor_id = sec_info[0]['specimen']['donor_id']
    gene_name = sec_info[0]['genes'][0]['acronym']
    donor_exp_vol = sitk.ReadImage(get_donor_brain_vol(donor_id, view = 'expression', background = 'w', img_dtype = sitk.sitkFloat32)[0])
    exp_mask_image = sitk.Image(donor_exp_vol.GetSize(), sitk.sitkUInt8)
    for image_info in sec_info[0]['section_images']:
        exp_mask_image[:, :, image_info['section_number']] = 1
        
    exp_vol = sitk.GetImageFromArray(sitk.GetArrayFromImage(donor_exp_vol) * sitk.GetArrayFromImage(exp_mask_image))
    exp_vol.CopyInformation(donor_exp_vol)
    tvr_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'trv')
    trv_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'tvr')
    tvr_transform3d = sitk.AffineTransform(3)
    tvr_transform3d.SetParameters(tvr_alignment3d)
    trv_transform3d = sitk.AffineTransform(3)
    trv_transform3d.SetParameters(trv_alignment3d)
      
    if not ref_vol:
        ref_vol = sitk.ReadImage(utils.get_reference_space())
        
    sitk.WriteImage(sitk.Resample(exp_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), tvr_path)
    sitk.WriteImage(sitk.Resample(ref_vol, exp_vol, trv_transform3d, sitk.sitkNearestNeighbor), trv_path)     
    sitk.WriteImage(exp_vol, exp_path)
    
    return exp_path, tvr_path, trv_path

def get_grid_ish_expression_vol(sec_id:typing.Optional[int] = None, gene_name:typing.Optional[str] = None, plane_of_section_id:typing.Literal[1, 2] = 1, set_size:typing.Optional[tuple] = None, is_force:typing.List[bool] = [False, False], sync_index:typing.Literal[1, 2] = 2, file_path:str = utils.STORE_EXP_VOL_PATH, grid_spacing:int = 200, use_img:typing.Literal['exp', 'ish'] = 'exp', img_path:str = utils.STORE_IMG_DATA_PATH, grid_vol_init_value:int = 0) -> tuple:
    '''
        plane_of_section_id: 1 for coronal, 2 for sagittal. 
        Deprecate parameters: smooth_function:typing.types.FunctionType = sitk.SmoothingRecursiveGaussian, **smooth_function_parameters
    '''
    if (sec_id and gene_name) or (not sec_id and not gene_name):
        raise('check sec_id and gene_name parameters again')
    if sec_id:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen, alignment3d,genes, section_images(alignment2d)')
    if gene_name:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_of_section_id}]", include=f"specimen, alignment3d, genes[acronym$eq'{gene_name}'], section_images(alignment2d)")
    
    if not sec_info:
        raise('No sec_info for this parameters')
    
    grid_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_{grid_vol_init_value}_syn{sync_index}.nii.gz"
    grid_tvr_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_{grid_vol_init_value}_syn{sync_index}_tvr.nii.gz"
    
    os.makedirs(f"{file_path}/{sec_id}", exist_ok = True)
    
    plane_of_section_id = sec_info[0]['plane_of_section_id']
    if not set_size:
        set_size = (12800, 12800) if plane_of_section_id == 1 else (16000, 12000)
        
    imgs_pd = pd.DataFrame(sec_info[0]['section_images']).sort_values('section_number')
    section_thickness = sec_info[0]['section_thickness']
    donor_id = sec_info[0]['specimen']['donor_id']
    donor_vol = sitk.ReadImage(get_donor_brain_vol(donor_id)[0])
    grid_vol_dict = {}
    
    if is_force[0] or not os.path.exists(grid_path):
        sample_image = sitk.GetImageFromArray(np.zeros(set_size, dtype = "float32"), isVector = False)
        for row in imgs_pd[['data_set_id','id','section_number','alignment2d', 'resolution']].itertuples():
            transform2d = sitk.AffineTransform(2)
            transform2d.SetParameters(test_build_alignment_2d(row[4], 'tvs'))
            if utils.recon_download_image(row[2], view = 'expression', file_path = f"{img_path}/{row[1]}/expression/{row[2]}.jpg"):    
                exp_img = sitk.Resample(sitk.ReadImage(f"{utils.STORE_IMG_DATA_PATH}/{row[1]}/expression/{row[2]}.jpg", sitk.sitkVectorFloat32), sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0)
            else:
                exp_img = sample_image
            if utils.recon_download_image(row[2], view = 'raw', file_path = f"{img_path}/{row[1]}/raw/{row[2]}.jpg"):
                ish_img = sitk.Resample(sitk.ReadImage(f"{utils.STORE_IMG_DATA_PATH}/{row[1]}/raw/{row[2]}.jpg", sitk.sitkVectorFloat32), sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0)
            else:
                ish_img = sample_image
            grid_img = test_syn_expression_intensity_img(ish_img, exp_img, use_img = use_img, px_spacing = row[5], ct_index = sync_index, grid_spacing = grid_spacing)
            grid_slice_index = np.int32(np.floor(row[3] / grid_spacing * section_thickness))
            if grid_slice_index in grid_vol_dict.keys():
                grid_vol_dict[grid_slice_index].append(grid_img)
            else:
                grid_vol_dict[grid_slice_index] = [grid_img]
        
        grid_vol = sitk.JoinSeries([sitk.Image(grid_img.GetSize(), sitk.sitkFloat64) for _ in range(np.int32(np.ceil(donor_vol.GetSize()[2] / grid_spacing * section_thickness)))])
        grid_vol.SetSpacing((grid_spacing, grid_spacing, grid_spacing))
        grid_vol[:, :, :] = grid_vol_init_value
        for sli_index in list(grid_vol_dict.keys()):
            sli_sum_img = 0
            for sli_img in grid_vol_dict[sli_index]:
                sli_sum_img = sli_img + sli_sum_img
            grid_vol[:,:, int(sli_index)] = sli_sum_img / len(grid_vol_dict[sli_index])
        sitk.WriteImage(grid_vol, grid_path)
        
    if is_force[1] or not os.path.exists(grid_tvr_path):
        # grid_vol = smooth_function(sitk.ReadImage(grid_path), **smooth_function_parameters)
        grid_vol = sitk.ReadImage(grid_path)
        rfp = utils.get_reference_space_tree(grid_spacing)[0]
        ref_vol_numpy = rfp.annotation if grid_spacing != 200 else rfp.annotation.reshape(utils.ISH_GRID_SHAPE)
        ref_vol = sitk.GetImageFromArray(ref_vol_numpy)
        ref_vol.SetSpacing((grid_spacing, grid_spacing, grid_spacing))
        tvr_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'trv')
        tvr_transform3d = sitk.AffineTransform(3)
        tvr_transform3d.SetParameters(tvr_alignment3d)
        sitk.WriteImage(sitk.Resample(grid_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), grid_tvr_path)
    
    return grid_path, grid_tvr_path

def get_accord_ref_donor_vol(donor_id:int = 6153, ref_type:str = "nissl", vol:typing.Optional[ants.core.ants_image.ANTsImage] = None, is_rgb = False, return_list = True):
    ''' 
        Since the coronal plane in donor volume is different with ref vol, this function is to fix this, let the coronal plane accord with ref vol.
        And also offer Rigid transform vol of ref to donor vol. 
        The return is a tuple which contain two ANTsImage(processed donor vol and transform ref vol).
    '''
    # TODO. just offer 25um, waiting for support other spacing. 
    if not donor_id and not vol:
        raise('error')
    if donor_id and vol:
        raise('error')
    if donor_id:
        vol = ants.image_read(get_donor_brain_vol(donor_id)[0], pixeltype = 'unsigned char')
        
    ss_numpy = vol.numpy()
    
    if len(ss_numpy.shape) == 4 and not is_rgb:
        ss_numpy = np.mean(ss_numpy, axis = 3)
    
    ss_numpy = np.flip(ss_numpy.transpose(2, 1, 0), axis = 0) if not is_rgb else np.flip(ss_numpy.transpose(2, 1, 0, 3), axis = 0)
    
    ss_vol = [ants.from_numpy(ss_numpy[:,:,:, idx], spacing=[25, 25, 25]) for idx in range(3)] if is_rgb else ants.from_numpy(ss_numpy, spacing=[25, 25, 25])
    
    if not return_list and is_rgb:
        ss_vol = ants.merge_channels(ss_vol)

    if ref_type and not is_rgb:
        ref_vol = ants.image_read(utils.get_reference_space(ref_type))
        res = ants.registration(ss_vol, ref_vol, 'Rigid', outprefix=f"{utils.ANTS_REG_TMP}/", aff_metric = 'meansquares')    
        return ss_vol, res['warpedmovout']
    
    return ss_vol

def get_revert_donor_accrod_ref_vol(vols:typing.List[ants.core.ants_image.ANTsImage]) -> list: 
    
    res_list = list()
    for vol in vols:
        ss_numpy = np.flip(vol.numpy(), axis = 0).transpose(2, 1, 0)
        ss_vol = ants.from_numpy(ss_numpy, spacing=ants.get_spacing(vol))
        res_list.append(ss_vol)
    
    return res_list

# %%
def get_donors_info_by_exp_info(plane = "coronal", product = 1, file_path = utils.STORE_DONOR_VOL_PATH, is_force = False):

    donor_info_dict_path = f"{file_path}/{plane}_{product}_donor_ids_info.dict" 
    if not is_force and os.path.exists(donor_info_dict_path):
        with open(donor_info_dict_path, 'rb') as f:
            donor_info_dict = pickle.load(f)
        return donor_info_dict
    
    if not os.path.exists('tmp_donors_infos.dict'):
        pre_donor_infos_list = utils.recon_model_query(model = 'Donor', num_rows = 'all', include = f"specimens(data_sets(treatments[name$in'ISH', 'NISSL'], [failed$eq'false'], products[id$eq{product}], plane_of_section[name$eq'{plane}']))")
        with open('tmp_donors_infos.dict', 'wb') as f:
            pickle.dump(pre_donor_infos_list, f)
    else:
        with open('tmp_donors_infos.dict', 'rb') as f:
            pre_donor_infos_list = pickle.load(f)
    
    pre_donor_infos_list = utils.recon_model_query(model = 'Donor', num_rows = 'all', include = f"specimens(data_sets(treatments[name$in'ISH', 'NISSL'], [failed$eq'false'], products[id$eq{product}], plane_of_section[name$eq'{plane}']))")
    donor_info_dict = {}
    print(f"the num of donor ids is {len(pre_donor_infos_list)}")
    for pre_donor_infos in pre_donor_infos_list:
        print(f"the donor_id {pre_donor_infos['id']} start process")
        secs_pd_dict = {}
        secs_pd_dict['section_images_pd'] = []
        for pre_sec_info in pre_donor_infos['specimens'][0]['data_sets']:
            sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq{pre_sec_info['id']}], [failed$eq'false']", include = "treatments, alignment3d, section_images(alignment2d)")
            if 'alignment3d' not in list(sec_info[0].keys()) or 'alignment2d' not in list(sec_info[0]['section_images'][0].keys()):
                continue
            secs_pd_dict['alignment3d'] = sec_info[0]['alignment3d']
            sec_pd = pd.DataFrame(sec_info[0]['section_images'])
            sec_pd['treatment'] = sec_info[0]['treatments'][0]['name']
            secs_pd_dict['section_images_pd'].append(sec_pd[['data_set_id', 'id', 'section_number', 'alignment2d', 'treatment']])
            
        if not secs_pd_dict['section_images_pd']:
            secs_pd_dict['status'] = 'Null'
        else:    
            secs_pd_dict['section_images_pd'] = pd.concat(secs_pd_dict['section_images_pd']).sort_values('section_number')
            if secs_pd_dict['section_images_pd'].query("treatment == 'ISH'").shape[0] > 0 and secs_pd_dict['section_images_pd'].query("treatment == 'NISSL'").shape[0] > 0:
                secs_pd_dict['status'] = 'Hybrid'
            elif secs_pd_dict['section_images_pd'].query("treatment == 'ISH'").shape[0] > 0:
                secs_pd_dict['status'] = 'ISH'
            else:
                secs_pd_dict['status'] = 'NISSL'
        donor_info_dict[pre_donor_infos['id']] = secs_pd_dict    
                    
    print(f"Writing info into file")                
    with open(donor_info_dict_path, 'wb') as f:
        pickle.dump(donor_info_dict, f)
        
    return donor_info_dict

def get_single_donor_ish_associate_nissl_info(donor_id:int, file_path:str = utils.STORE_DONOR_VOL_PATH, is_force:bool = False, section_images_pd:typing.Optional[pd.DataFrame]= None, **args) -> tuple:
    
    ish_associate_nissl_info_dict_path = f"{file_path}/{donor_id}/{donor_id}_ish_associate_nissl_info.dict"
    if not is_force and os.path.exists(ish_associate_nissl_info_dict_path):
        with open(ish_associate_nissl_info_dict_path, 'rb') as f:
            ish_associate_nissl_info_dict = pickle.load(f)
        return donor_id, ish_associate_nissl_info_dict
    
    if not os.path.exists(f"{file_path}/{donor_id}"):
        os.makedirs(f"{file_path}/{donor_id}")
    
    RMA = RmaApi()
    ish_associate_nissl_info_dict = {}
    section_images_pd = section_images_pd if type(section_images_pd) == pd.DataFrame else get_donors_info_by_exp_info(args)[donor_id]['section_images_pd']
    ish_associate_nissl_info_dict['empty_sec_val'] = section_images_pd[['section_number']].iloc[-1, 0] - len(section_images_pd.index)
    ish_associate_nissl_info_dict['section_number_of_ish_to_associate_nissl_info'] = {}
    for row in section_images_pd[['id','section_number', 'treatment']].itertuples():
        associate_nissl_info_dict = {}
        if row[3] == "ISH":
            associate_nissl_image_info = utils.recon_model_query(model = 'SectionImage', criteria = f"[id$eq{row[1]}]", include = f"associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]
            associate_nissl_info_dict['associate_nissl_data_set_id'] = associate_nissl_image_info['data_set_id']
            associate_nissl_info_dict['associate_nissl_image_id'] = associate_nissl_image_info['id']
            associate_nissl_info_dict['associate_nissl_image_section_number'] = associate_nissl_image_info['section_number']
            ish_associate_nissl_info_dict['section_number_of_ish_to_associate_nissl_info'][row[2]] = associate_nissl_info_dict
    
    with open(ish_associate_nissl_info_dict_path, 'wb') as f:
        pickle.dump(ish_associate_nissl_info_dict, f)
    
    return donor_id, ish_associate_nissl_info_dict

def get_sepcific_donor_ids_ish_associate_nissl_info(plane = "coronal", product = 1, file_path = utils.STORE_DONOR_VOL_PATH, is_force = False, n_process = 8):   
    ''' for all donors, just use in nissl which already have larger empty section numbers( >= 240 slices false qc), then use small thval will give us ish-nissl donors'''    
    import concurrent.futures
    donors_ish_associate_nissl_info_dict_path = f"{file_path}/{plane}_{product}_donors_ish_associate_nissl_info.dict"
    if not is_force and os.path.exists(donors_ish_associate_nissl_info_dict_path):
        with open(donors_ish_associate_nissl_info_dict_path, "rb") as f:
            donors_ish_associate_nissl_info_dict = pickle.load(f)
        return donors_ish_associate_nissl_info_dict
    
    donor_id_infos = get_donors_info_by_exp_info(plane = plane, product = product, file_path = file_path)
    donors_ish_associate_nissl_info_dict = {}
    
    with concurrent.futures.ProcessPoolExecutor(max_workers = n_process) as excutor:
        futs = [excutor.submit(get_single_donor_ish_associate_nissl_info, donor_id = donor_id, file_path = file_path, section_images_pd = donor_infos['section_images_pd']) for donor_id, donor_infos in donor_id_infos.items() if donor_infos['status'] == 'Hybrid']
        for fut in concurrent.futures.as_completed(futs):
            print(f"the donor_id {fut.result()[0]} complete")
            donors_ish_associate_nissl_info_dict[fut.result()[0]] = fut.result()[1]
    
    if donors_ish_associate_nissl_info_dict:        
        with open(donors_ish_associate_nissl_info_dict_path, 'wb') as f:
            pickle.dump(donors_ish_associate_nissl_info_dict, f)
    return donors_ish_associate_nissl_info_dict

def get_dl_convert_vol(vol:ants.core.ants_image.ANTsImage, is_grey = True, **load_net_params):
    
    '''
        the plane of vol which you want convert must be in first direction.
    '''
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = cgan_net.load_G(device = device, **load_net_params) 
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net.to(device)
    net.eval()
    vol_array = vol.numpy()
    tras = transforms.Compose([transforms.Grayscale(1), transforms.ToTensor(), transforms.Normalize((0.5,), (0.5,))]) if is_grey else transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    for sli_idx in range(vol.shape[0]):
        sli_numpy = ants.slice_image(vol, axis = 0, idx = sli_idx).numpy()
        sli = Image.fromarray(sli_numpy) if is_grey else Image.fromarray(sli_numpy, mode = "RGB")
        if np.max(sli) > 0:
            ori_tensor = tras(sli).unsqueeze(0).to(device).float() if is_grey else tras(sli).to(device).float()
            with torch.no_grad():
                ori_fake = net(ori_tensor)
            if is_grey:
                vol_array[sli_idx,:,:] = cgan_net.tensor2im(ori_fake.detach(), is_greyscale_to_RGB = False).squeeze()
            else:
                vol_array[sli_idx,:,:,:] = cgan_net.tensor2im(ori_fake)
    
    return ants.from_numpy(vol_array, spacing = ants.get_spacing(vol), has_components = None if is_grey else 3)

def get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id, net_name, convert_whole_brain = False, convert_grey = False, net = None, is_force = False, donor_info = None, res_vol_path = None, **load_net_params) -> str:

    tras = transforms.Compose([transforms.Grayscale(1), transforms.ToTensor(), transforms.Normalize((0.5,), (0.5,))]) if convert_grey else transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    
    dl_vol_path = f"{res_vol_path}/{donor_id}_dl_{net_name}.nii.gz" if res_vol_path else f"{utils.STORE_DONOR_VOL_PATH}/{donor_id}/{donor_id}_dl_{net_name}.nii.gz"
    tvr_vol_path = f"{res_vol_path}/{donor_id}_dl_{net_name}_tvr.nii.gz" if res_vol_path else f"{utils.STORE_DONOR_VOL_PATH}/{donor_id}/{donor_id}_dl_{net_name}_tvr.nii.gz"
    trv_vol_path = f"{res_vol_path}/{donor_id}_dl_{net_name}_trv.nii.gz" if res_vol_path else f"{utils.STORE_DONOR_VOL_PATH}/{donor_id}/{donor_id}_dl_{net_name}_trv.nii.gz"
    
    if not is_force and os.path.exists(dl_vol_path) and os.path.exists(tvr_vol_path) and os.path.exists(trv_vol_path):
        return dl_vol_path, tvr_vol_path, trv_vol_path 
    
    if not (net or load_net_params):
        raise("net and load_net_params are all None, one of those must be have an actual input")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = cgan_net.load_G(device = device, **load_net_params) if not net else net
    # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net.to(device)
    net.eval()
    # raw_vol = Image.open(get_donor_brain_vol(donor_id)[0])
    # vol_array = np.array(raw_vol)
    raw_vol = sitk.ReadImage(get_donor_brain_vol(donor_id)[0])
    vol_array = sitk.GetArrayFromImage(raw_vol)
    if convert_grey:
        vol_array = np.mean(vol_array, axis = 3)
    donor_info = get_single_donor_ish_associate_nissl_info(donor_id)[1] if not donor_info else donor_info
    idxs_list = [ish_section_order for ish_section_order, _ in donor_info['section_number_of_ish_to_associate_nissl_info'].items()] if not convert_whole_brain else [idx for idx in range(raw_vol.GetSize()[2])]
    for idx in idxs_list:
        # ori_tensor = torch.tensor(vol_array[ish_section_number,:,:]).unsqueeze(0).to(device).float() if convert_grey else torch.tensor(vol_array[ish_section_number,:,:,:]).to(device).float()
        sli = Image.fromarray(vol_array[idx,:,:]) if convert_grey else Image.fromarray(vol_array[idx,:,:,:], mode = "RGB")
        if not np.max(sli) > 0:
            continue
        ori_tensor = tras(sli).unsqueeze(0).to(device).float() if convert_grey else tras(sli).to(device).float()
        with torch.no_grad():
            ori_fake = net(ori_tensor)
        if convert_grey:
            vol_array[idx,:,:] = cgan_net.tensor2im(ori_fake.detach(), is_greyscale_to_RGB = False).squeeze()
        else:
            vol_array[idx,:,:,:] = cgan_net.tensor2im(ori_fake)
            
    res_vol = sitk.GetImageFromArray(vol_array)
    res_vol.CopyInformation(raw_vol)
    alignment_3d = get_donors_info_by_exp_info()[donor_id]['alignment3d']
    tvr_alignment3d = test_build_alignment_3d(alignment_3d, 'trv')
    trv_alignment3d = test_build_alignment_3d(alignment_3d, 'tvr')
    tvr_transform3d = sitk.AffineTransform(3)
    tvr_transform3d.SetParameters(tvr_alignment3d)
    trv_transform3d = sitk.AffineTransform(3)
    trv_transform3d.SetParameters(trv_alignment3d)
    ref_vol = sitk.ReadImage(utils.get_reference_space())
    sitk.WriteImage(res_vol, dl_vol_path)
    sitk.WriteImage(sitk.Resample(res_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), tvr_vol_path)
    sitk.WriteImage(sitk.Resample(ref_vol, res_vol, trv_transform3d, sitk.sitkNearestNeighbor), trv_vol_path)
    
    return dl_vol_path, tvr_vol_path, trv_vol_path 

# %%
def get_donor_section_images_infos(donor_id:int) -> pd.DataFrame:
    
    donor_info =  utils.recon_model_query(model = 'Donor', num_rows = 'all', criteria=f"[id$eq{donor_id}]", include = f"specimens(data_sets(treatments[name$in'ISH', 'NISSL'], [failed$eq'false'], genes))")
    print(donor_info)

    section_images_pd_list = []

    for sec_info in donor_info[0]['specimens'][0]['data_sets']:
        
        imgs_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_info['id']}], [failed$eq'false']", include = "treatments, alignment3d, section_images(alignment2d)")
        if 'alignment3d' not in list(imgs_info[0].keys()) or 'alignment2d' not in list(imgs_info[0]['section_images'][0].keys()):
            continue
        
        sec_pd = pd.DataFrame(imgs_info[0]['section_images'])
        sec_pd['treatment'] = imgs_info[0]['treatments'][0]['name']
        sec_pd['gene_name'] = sec_info['genes'][0]['acronym'] if sec_info['genes'] else imgs_info[0]['treatments'][0]['name']
        
        section_images_pd_list.append(sec_pd[['data_set_id', 'id', 'section_number', 'treatment', 'gene_name']])

    section_images_pd = pd.concat(section_images_pd_list, ignore_index = True).sort_values('section_number')
    
    return section_images_pd

def get_associate_genes_by_donor_id(donor_id:int, plane_id:int = 1):
    res_dict = {}
    sec_infos = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_id}]", include=f"specimen(donor[id$eq{donor_id}]), genes")
    for sec_info in sec_infos:
        if sec_info['genes']:
            res_dict[sec_info['genes'][0]['acronym']] = sec_info['id']
            
    return res_dict

def make_single_donor_data_set_of_ish_to_nissl(file_path, donor_id, donor_ish_associate_nissl_info_dict = None, plane = "c", is_target_ref = False, ref_type = "nissl", slice_range = (20, 461)):
    import scipy
    
    ish_dir = f"{file_path}/trainA"
    nissl_dir = f"{file_path}/trainB"
    os.makedirs(ish_dir, exist_ok = True)
    os.makedirs(nissl_dir, exist_ok = True)
    
    if is_target_ref:
        vols = get_accord_ref_donor_vol(donor_id, ref_type)
        donor_ss_vol, ref_vol = ants.from_numpy(np.flip(vols[0].numpy().transpose(2, 1, 0), axis = 2)).astype('uint8'), ants.iMath_normalize(ants.from_numpy(np.flip(vols[1].numpy().transpose(2, 1, 0), axis = 2))) * 255
        ref_vol = ref_vol.astype('uint8')

        for slice_idx in range(slice_range[0], slice_range[1]):
            donor_sli_numpy = ants.slice_image(donor_ss_vol, axis = 2, idx = slice_idx).numpy()
            target_sli_numpy = ants.slice_image(ref_vol, axis = 2, idx = slice_idx).numpy()
            ants.image_write(ants.from_numpy(donor_sli_numpy, spacing=[25,25]), f"{ish_dir}/{donor_id}_{plane}_{slice_idx}.png")
            ants.image_write(ants.from_numpy(target_sli_numpy, spacing=[25,25]), f"{nissl_dir}/{donor_id}_{plane}_{slice_idx}.png")
    else:
        donor_ss_vol = ants.image_read(get_donor_brain_vol(donor_id)[0], pixeltype = 'unsigned char')
        if not donor_ish_associate_nissl_info_dict:
            donor_ish_associate_nissl_info_dict = get_sepcific_donor_ids_ish_associate_nissl_info()[donor_id]
        for ish_section_number, associate_nissl_infos in donor_ish_associate_nissl_info_dict['section_number_of_ish_to_associate_nissl_info'].items():
            donor_sli_numpy = ants.slice_image(donor_ss_vol, axis = 2, idx = ish_section_number).numpy()
            target_sli_numpy = ants.slice_image(donor_ss_vol, axis = 2, idx = associate_nissl_infos['associate_nissl_image_section_number']).numpy()
            if np.max(donor_sli_numpy) > 0 and np.max(target_sli_numpy) > 0:
                ants.image_write(ants.from_numpy(donor_sli_numpy, spacing=[25, 25], is_rgb = True), f"{ish_dir}/{donor_id}_{plane}_{ish_section_number}.png")
                ants.image_write(ants.from_numpy(target_sli_numpy, spacing=[25, 25], is_rgb = True), f"{nissl_dir}/{donor_id}_{plane}_{ish_section_number}.png") 
                
    return donor_id

def get_ish_to_nissl_data_set(file_path, empty_slice_thval:int = 10, plane = "coronal"):    
    donors_ish_associate_nissl_info_dict = get_sepcific_donor_ids_ish_associate_nissl_info(plane)
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= empty_slice_thval]
    p = "c" if plane == "coronal" else "s"             
    for donor_id in donor_ids:
        print(f"{make_single_donor_data_set_of_ish_to_nissl(donor_id = donor_id, file_path = file_path, donor_ish_associate_nissl_info_dict = donors_ish_associate_nissl_info_dict[donor_id], is_force = False, plane = p)} data set complete")        
        
def get_sum_sample_dl_ish_convert_nissl_vol(file_path, vol_type_index = 1, net_name = None, is_force = False, empty_slice_thval:int = 10, plane = "coronal", **load_net_params):
    if vol_type_index == 0:
        vol_type = "ss"
    elif vol_type_index == 1:
        vol_type = "tvr"
    else:
        vol_type = "trv"
    net_name = net_name if net_name else ""
    donors_ish_associate_nissl_info_dict = get_sepcific_donor_ids_ish_associate_nissl_info(plane)
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= empty_slice_thval]
    sum_vol_path = f"{file_path}/sum{len(donor_ids)}_{plane}_thv{empty_slice_thval}_{net_name}_{vol_type}.nii.gz"
    if not is_force and os.path.exists(sum_vol_path):
        return sum_vol_path
    dl_vols_paths = [get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id = donor_id, net_name = net_name, **load_net_params)[vol_type_index] for donor_id in donor_ids]
    sum_vol = 0
    for dl_vol_path in dl_vols_paths:
        sum_vol = sitk.ReadImage(dl_vol_path, sitk.sitkVectorUInt32) + sum_vol
    sitk.WriteImage(sum_vol, sum_vol_path)
    return sum_vol_path

def get_averge_RGBimage(image:sitk.Image, divid_num):
    red_channel = sitk.VectorIndexSelectionCast(image, 0, sitk.sitkFloat32)
    green_channel = sitk.VectorIndexSelectionCast(image, 1, sitk.sitkFloat32)
    blue_channel = sitk.VectorIndexSelectionCast(image, 2, sitk.sitkFloat32)
    red_channel = sitk.Divide(red_channel, divid_num)
    green_channel = sitk.Divide(green_channel, divid_num)
    blue_channel = sitk.Divide(blue_channel, divid_num)
    processed_image = sitk.Compose([red_channel, green_channel, blue_channel])
    
    return processed_image

def RGB2Gray(image:sitk.Image, red_weight = 0.34, green_weight = 0.34, blue_weight = 0.34, image_type = sitk.sitkUInt8) -> sitk.Image:
    red_channel = sitk.VectorIndexSelectionCast(image, 0, image_type)
    green_channel = sitk.VectorIndexSelectionCast(image, 1, image_type)
    blue_channel = sitk.VectorIndexSelectionCast(image, 2, image_type)
    processed_image = red_channel * red_weight + green_channel * green_weight + blue_channel * blue_weight 
    return processed_image

# %%
def test_get_donor_brain_nii_by_sec_id(sec_id:int = 74864369) -> list:
    RMA = RmaApi()
    donor_id = RMA.model_query('SectionDataSet', num_rows = 'all', criteria=f"[id$eq{sec_id}]", include='specimen')[0]['specimen']['donor_id']
    return get_donor_brain_vol(donor_id, ref_vol = sitk.ReadImage('/home/t207/wd_disk/server/allen_project/data/reference_cache/ara_nissl/ara_nissl_25.nrrd'))
    
def demo_get_donor_brain_vol_by_plane(plane = "coronal", n_process = 24):
    import concurrent.futures
    import progressbar
    RMA = RmaApi()
    donor_ids = list(get_donors_info_by_exp_info(plane).keys())
    ref_vol = sitk.ReadImage('/home/t207/wd_disk/server/allen_project/data/reference_cache/ara_nissl/ara_nissl_25.nrrd')
    with concurrent.futures.ProcessPoolExecutor(max_workers = n_process) as excutor:
        bar = progressbar.ProgressBar(max_value = len(donor_ids))
        i = 0
        futs = [excutor.submit(get_donor_brain_vol, donor_id = donor_id, ref_vol = ref_vol) for donor_id in donor_ids]
        for _ in concurrent.futures.as_completed(futs):
            bar.update(i + 1)
            i = i + 1

def normalize_sitk_image(img:sitk.Image) -> sitk.Image:
    sf = sitk.StatisticsImageFilter()
    sf.Execute(img)
    return sitk.ShiftScale(img, -1 * sf.GetMinimum(), 1 / (sf.GetMaximum() - sf.GetMinimum()))

def make_reference_train_data_pair(data_set_path, spacing = 25, plane:typing.Literal["c","f","s"] = "c", is_norm:bool = True, contain_zero:bool = False, slice_range:typing.Optional[list] = None):
    if not os.path.exists(f"{data_set_path}/trainA"):
        os.makedirs(f"{data_set_path}/trainA")
        
    if not os.path.exists(f"{data_set_path}/trainB"):
        os.makedirs(f"{data_set_path}/trainB")
    
    ara_nissl_vol = sitk.ReadImage(f'/home/t207/wd_disk/server/allen_project/data/reference_cache/ara_nissl/ara_nissl_{spacing}.nrrd')
    average_template_vol = sitk.ReadImage(f'/home/t207/wd_disk/server/allen_project/data/reference_cache/average_template/average_template_{spacing}.nrrd', sitk.sitkFloat32)
    if is_norm:
        ara_nissl_vol = normalize_sitk_image(ara_nissl_vol)
        average_template_vol = normalize_sitk_image(average_template_vol)
    if not contain_zero:
        ara_nissl_vol = ara_nissl_vol + 1
        average_template_vol = average_template_vol + 1
        
    if plane == "c":
        if not slice_range:
            slice_range = [0, ara_nissl_vol.GetSize()[0]]
        for index in range(slice_range[0], slice_range[1]):
            sitk.WriteImage(ara_nissl_vol[index, :, :], f"{data_set_path}/trainA/{plane}_{index}.tiff")
            sitk.WriteImage(average_template_vol[index, :, :], f"{data_set_path}/trainB/{plane}_{index}.tiff")
    elif plane == "s":
        if not slice_range:
            slice_range = [0, ara_nissl_vol.GetSize()[2]]
        for index in range(slice_range[0], slice_range[1]):
            sitk.WriteImage(ara_nissl_vol[:, :, index], f"{data_set_path}/trainA/{plane}_{index}.tiff")
            sitk.WriteImage(average_template_vol[:, :, index], f"{data_set_path}/trainB/{plane}_{index}.tiff")
    else:
        if not slice_range:
            slice_range = [0, ara_nissl_vol.GetSize()[1]]
        for index in range(slice_range[0], slice_range[1]):
            sitk.WriteImage(ara_nissl_vol[:, index, :], f"{data_set_path}/trainA/{plane}_{index}.tiff")
            sitk.WriteImage(average_template_vol[:, index, :], f"{data_set_path}/trainB/{plane}_{index}.tiff")

# %%
if __name__ == "__main__":
    # reample_section_data_set_demo(set_size = (utils.RFP_RES_GRIDSHAPE[10][0], utils.RFP_RES_GRIDSHAPE[10][1]))
    # make_nissl_train_dataset_demo(data_set_path = '/home/t207/wd_disk/server/allen_project/notebook/cgan/datasets/nissl/mouse_ish_paired_coronal_all', ref_vol = sitk.ReadImage('/home/t207/wd_disk/server/allen_project/data/reference_cache/average_template/average_template_25.nrrd'), ids_range = None, n_process = 16)
    # res = test_average_nii_demo()
    # demo_get_donor_brain_vol_by_plane()
    # get_sepcific_donor_ids_ish_associate_nissl_info(n_process = 8)
    # get_ish_to_nissl_data_set("/home/t207/wd_disk/server/allen_project/notebook/cgan/datasets/ish")
    # get_donors_info_by_exp_info("sagittal")
    # dl_image = sitk.ReadImage(get_deep_learning_single_donor_ish_convert_nissl_vol(6886, net_name = 'c_icn_st10_s0', input_nc = 3, output_nc = 3, ngf = 128, pth_file = "/home/t207/wd_disk/server/allen_project/notebook/cgan/checkpoints/c_icn_st10_s0/latest_net_G_A.pth")[0])
    # get_sum_sample_dl_ish_convert_nissl_vol('/home/t207/Lab_Data_preproc2/allen_data/dl_datasets/', vol_type_index = 0, is_force = True, net_name = 'c_icn_st10_s0', input_nc = 3, output_nc = 3, ngf = 128, pth_file = "/home/t207/wd_disk/server/allen_project/notebook/cgan/checkpoints/c_icn_st10_s0/latest_net_G_A.pth")
    # sitk.WriteImage(get_averge_sample(sitk.ReadImage('/home/t207/Lab_Data_preproc2/allen_data/dl_datasets/sum101_coronal_thv10_c_icn_st10_s0_tvr.nii.gz'), 101), '/home/t207/Lab_Data_preproc2/allen_data/dl_datasets/averge101_coronal_thv10_c_icn_st10_s0_tvr.nii.gz')
    pass


