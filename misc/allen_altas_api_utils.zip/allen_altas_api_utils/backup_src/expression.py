# %%
import numpy as np
import typing
import os
import matplotlib.pyplot as plt
import anndata

import process_img as prg
import utils
import SimpleITK as sitk
import register as reg
import scanpy as sc
# import scanorama as sma

def create_anndata_expression_slice(plane:typing.Literal["s", "c", "h"], slice_index:int, spacing:typing.Literal[10,25] = 25, empty_sli_thval:int = 50, is_grid:bool = True, is_force:bool = False, file_path:str = utils.STORE_EXP_VOL_PATH, vol_path:str = utils.STORE_EXP_VOL_PATH):

    import anndata

    file_path = f"{file_path}/slice_h5ad"
    os.makedirs(file_path, exist_ok = True)
    spot_prefix = f"{plane}_{slice_index}_{spacing}"
    file_path = f"{file_path}/{spot_prefix}.h5ad"

    if is_force or not os.path.exists(file_path):
        plane_index_dict = {"c":[1,2], "h":[0,2], "s":[0,1]}
        slice_shape = [utils.RFP_RES_GRIDSHAPE[spacing][idx] for idx in plane_index_dict[plane]]
        spot_num = slice_shape[0] * slice_shape[1]
        print(slice_shape[0], slice_shape[1])
        spot_idx = [f"{spot_prefix}_{idx}" for idx in range(spot_num)]
        donors_ish_associate_nissl_info_dict = prg.get_sepcific_donor_ids_ish_associate_nissl_info()
        donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= empty_sli_thval]
        gene_names = []
        sec_ids = []
        for donor_id in donor_ids:
            gene_secid_dict = prg.get_associate_genes_by_donor_id(donor_id)
            gene_names = gene_names + [gene_name for gene_name, _ in gene_secid_dict.items()]
            sec_ids = sec_ids + [sec_id for _, sec_id in gene_secid_dict.items()]
        
        plane_index_dict = {"c": 2, "h": 1, "s": 0}
        matrix = []
        for sec_id in sec_ids:
            exp_vol = sitk.GetArrayFromImage(sitk.ReadImage(reg.get_reference_transform_exp_vol(sec_id, is_grid = is_grid, file_path = vol_path)))
            exp_vector = np.take(exp_vol, slice_index, plane_index_dict[plane])
            exp_vector = exp_vector.flatten()
            if exp_vector.shape[0] != len(spot_idx):
                raise("error")
            matrix.append(exp_vector)
            
        sli_anndata = anndata.AnnData(np.array(matrix))
        sli_anndata.var_names = spot_idx
        sli_anndata.obs_names = gene_names
        sli_anndata.obs['sec_id'] = np.array(sec_ids)
        sli_anndata.uns['is_grid'] = is_grid
        sli_anndata.uns['spacing'] = spacing
        sli_anndata.uns['empty_sli_thval'] = empty_sli_thval
        sli_anndata.uns['slice_index'] = slice_index
        sli_anndata.uns['plane'] = plane
        sli_anndata.T.write_h5ad(file_path)
        
    return file_path    

def demo():
    for plane in ["s", "c", "h"]:
        for slice_index in range(210, 250):
            create_anndata_expression_slice(plane, slice_index)
            print(plane,slice_index,"completed")

if __name__ == "__main__":
    create_anndata_expression_slice('s',186)
    pass