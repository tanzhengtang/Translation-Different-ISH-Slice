# %%
def center_allen_ish(file_path, ref_space:sitk.Image = None, transform_pic_path = None, label_pic_path = None, sitk_type = sitk.sitkUInt8, gs_kernel = 100, otsu_his_bins = 20) -> sitk.Image:
    img = sitk.ReadImage(file_path, sitk_type)
    gs_img = sitk.SmoothingRecursiveGaussian(img, gs_kernel, True)
    otsuf = sitk.OtsuThresholdImageFilter()
    otsuf.SetNumberOfHistogramBins(otsu_his_bins)
    gs_osu_img = sitk.BinaryFillhole(otsuf.Execute(gs_img), fullyConnected = False)
    lbc = sitk.ConnectedComponent(gs_osu_img)
    lsf = sitk.LabelShapeStatisticsImageFilter()
    lsf.Execute(lbc)
    max_label_size = 0
    max_label = 0
    for label in range(1, lsf.GetNumberOfLabels() + 1):
        if lsf.GetNumberOfPixels(label) > max_label_size:
            max_label_size = lsf.GetNumberOfPixels(label)
            max_label = label
    shape_center = lsf.GetCentroid(max_label)
    ts = sitk.AffineTransform(2)
    if ref_space:
        ts.SetParameters((1.0,0,0,1.0, shape_center[0] - ref_space.GetWidth() / 2, shape_center[1] - ref_space.GetHeight() / 2))
    else:
        ts.SetParameters((1.0,0,0,1.0, shape_center[0] - img.GetWidth() / 2, shape_center[1] - img.GetHeight() / 2))
    if label_pic_path:
        plt.imshow(sitk.GetArrayFromImage(gs_osu_img), cmap = 'grey')
        plt.plot([0,shape_center[0]],[0,shape_center[1]])
        plt.savefig(label_pic_path)
        plt.close()
    if transform_pic_path:
        sitk.WriteImage(sitk.Resample(255 - img, ref_space, ts, sitk.sitkLinear), transform_pic_path)
        
    return sitk.Resample(255 - img, ref_space, ts, sitk.sitkLinear)

def allen_ish_reg_slices_to_stacks(img_path_lists, stack_file_path, set_size = None, fix_id = None, sec_thickness = 25, transform = sitk.AffineTransform(2),  img_center_type = sitk.CenteredTransformInitializerFilter.GEOMETRY):
    if not set_size:
        images = [sitk.ReadImage(img_path, sitk.sitkUInt8) for img_path in img_path_lists]
        max_width = 0
        max_height = 0
        for image in images:
            max_width = max_width if max_width > image.GetWidth() else image.GetWidth()
            max_height = max_height if max_height > image.GetHeight() else image.GetHeight()
        set_size = (max_width, max_height)
        del(images)
    else:
        max_width = set_size[0]
        max_height = set_size[1]
    
    ref_space = sitk.GetImageFromArray(np.zeros((max_height, max_width), dtype = 'uint8'))
    ref_slice_index = 0
    
    if fix_id:
        for ref_slice_index in range(0, len(img_path_lists)):
            if str(fix_id) in img_path_lists[ref_slice_index]:
                break
            
    ref_img = center_allen_ish(img_path_lists[ref_slice_index], ref_space = ref_space)
    images_series = img_path_lists.copy()
    images_series[ref_slice_index] = ref_img
    left_distance = 0
    right_distance = 0
    
    while ref_slice_index - left_distance:
        if not left_distance:
            mov = ref_img
            mov.MakeUnique()
        left_distance = left_distance + 1
        print('The number of rest in left_dirction is', ref_slice_index - left_distance)
        fix = mov 
        mov = center_allen_ish(img_path_lists[ref_slice_index - left_distance], ref_space = ref_space)
        initial_transform = sitk.CenteredTransformInitializer(fix, mov, transform, img_center_type)
        reg = sitk.ImageRegistrationMethod()
        reg.SetMetricAsMeanSquares()
        reg.SetInitialTransform(initial_transform, inPlace = False)
        reg.SetInterpolator(sitk.sitkLinear)
        reg.SetOptimizerAsLBFGS2()
        reg.SetOptimizerScalesFromPhysicalShift()
        tr = reg.Execute(sitk.Cast(fix, sitk.sitkFloat32), sitk.Cast(mov, sitk.sitkFloat32))
        mov = sitk.Resample(mov, fix, tr, sitk.sitkLinear, 0.0, sitk.sitkUInt8)
        images_series[ref_slice_index - left_distance] = mov
    
    while ref_slice_index + right_distance < len(images_series) - 1:
        if not right_distance:
            mov = ref_img
            mov.MakeUnique()
        right_distance = right_distance + 1
        print('The number of rest in right_dirction is', len(images_series) - ref_slice_index - right_distance)
        fix = mov 
        mov =  center_allen_ish(img_path_lists[ref_slice_index + right_distance], ref_space = ref_space)
        initial_transform = sitk.CenteredTransformInitializer(fix, mov, transform, img_center_type)
        reg = sitk.ImageRegistrationMethod()
        reg.SetMetricAsMeanSquares()
        reg.SetInitialTransform(initial_transform, inPlace = False)
        reg.SetInterpolator(sitk.sitkLinear)
        reg.SetOptimizerAsLBFGS2()
        reg.SetOptimizerScalesFromPhysicalShift()
        tr = reg.Execute(sitk.Cast(fix, sitk.sitkFloat32), sitk.Cast(mov, sitk.sitkFloat32))
        mov = sitk.Resample(mov, fix, tr, sitk.sitkLinear, 0.0, sitk.sitkUInt8)
        images_series[ref_slice_index + right_distance] = mov
        
    join_filter = sitk.JoinSeriesImageFilter()
    join_filter.SetSpacing(sec_thickness)
    stack_3d_img = join_filter.Execute(images_series)
    sitk.WriteImage(stack_3d_img, stack_file_path)

def test_stack_sample_image(sec_id:int = 74881161, view:str = "raw", imgs_folder_path:str = utils.IMG_DATA_PATH, set_size:typing.Optional[tuple] = None, filter_sec_img_ids:list = [], is_force:bool = False, spacing = (0.00105, 0.00105)) -> str:
    
    folder_path = f"{imgs_folder_path}/{sec_id}/{view}"
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    resample_file_path = f"{folder_path}_resample"
    if not os.path.exists(resample_file_path):
        os.makedirs(resample_file_path)
    
    if not is_force and set_size:
        resample_file = f"{resample_file_path}/{set_size[0]}_{set_size[1]}_resample.nii.gz"
        if os.path.exists(resample_file) and os.path.getsize(resample_file) > 1024000:
            return resample_file

    view = None if view == "raw" else view    
    RMA = RmaApi()
    imapi = ImageDownloadApi()
    section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "section_images")[0]
    sec_thickness = section_data_meta['section_thickness']
    img_meta = pd.DataFrame(section_data_meta['section_images'])
    img_ids = [row[1] for row in img_meta.sort_values(by = 'section_number')[['id','section_number']].itertuples()]
    images = []
    for img_id in img_ids:
        img_file_path = os.path.join(folder_path, f"{img_id}.jpg")
        download_time = 20
        while download_time and (not os.path.exists(img_file_path) or os.path.getsize(img_file_path) < 10240):
            try:
                imapi.download_image(img_id, view = view, file_path = img_file_path)
            except:
                pass
            download_time = download_time - 1
            time.sleep(2)

        if os.path.exists(img_file_path) and os.path.getsize(img_file_path) > 10240:
            if img_id not in filter_sec_img_ids:
                images.append(sitk.ReadImage(img_file_path)) 

    if not set_size:
        max_width = 0
        max_height = 0
        for image in images:
            max_width = max_width if max_width > image.GetWidth() else image.GetWidth()
            max_height = max_height if max_height > image.GetHeight() else image.GetHeight()
        set_size = (max_width, max_height)

    resample_file = f"{resample_file_path}/{set_size[0]}_{set_size[1]}_resample.nii.gz"

    if not is_force and os.path.exists(resample_file) and os.path.getsize(resample_file) > 1024000:
        return resample_file 

    newSize = np.array(set_size, float)
    resample = sitk.ResampleImageFilter() 
    resample.SetSize(set_size)
    resample.SetTransform(sitk.Transform(2, sitk.sitkIdentity))
    resample.SetInterpolator(sitk.sitkLinear)

    new_images = []
    sort = 0
    for image in images:
        newSpacing = (image.GetSize() / newSize) * image.GetSpacing()
        resample.SetOutputSpacing(newSpacing)
        new_image = resample.Execute(image)
        new_image.SetSpacing(spacing)
        # sitk.WriteImage(new_image, f"{resample_file_path}/{sort}.jpg")
        new_images.append(new_image)
        sort = sort + 1

    join_filter = sitk.JoinSeriesImageFilter()
    join_filter.SetSpacing(sec_thickness)
    stack_3d_img = join_filter.Execute(new_images)
    sitk.WriteImage(stack_3d_img, resample_file)

    return resample_file

def reample_section_data_set_demo(plane = 'coronal', n_process:int = 8, sec_imgs_thval = 100, set_size = None):
    sec_imgs_count_dict = utils.count_num_imgs_of_all_ish(plane = plane)
    sec_ids = [sec_id for sec_id, sec_imgs_count in sec_imgs_count_dict.items() if sec_imgs_count >= sec_imgs_thval]

    for sec_id in sec_ids:
        print(sec_id)
        test_stack_sample_image(sec_id, set_size = set_size)

    # with concurrent.futures.ProcessPoolExecutor(max_workers = n_process) as excutor:
    #     futs = [excutor.submit(test_stack_sample_image, sec_id = sec_id, set_size = set_size) for sec_id in sec_ids]
    #     for _ in concurrent.futures.as_completed(futs):
    #         pass
    

# %%
def test_average_nii_demo(plane = 'coronal'):
    nissl_ids = utils.test_count_nissl_coronal_plane_ids(plane)[0]
    # ref_vol = sitk.ReadImage('/home/t207/wd_disk/server/allen_project/data/reference_cache/average_template/average_template_25.nrrd')
    total_image = 0
    count = 0
    
    for nissl_id in nissl_ids:
        if not os.path.exists(f'/home/t207/Lab_Data_preproc2/allen_data/img_data/{nissl_id}/tvr.nii.gz'):
            continue  
        # tvr = test_stack_sample_image_by_allen_alignment(nissl_ids, file_path = '/home/t207/Lab_Data_preproc2/allen_data/img_data', set_size = (11400, 11000),  transform_spacing = [25, 25], ref_vol = ref_vol)[1]
        tvr_float = sitk.ReadImage(f'/home/t207/Lab_Data_preproc2/allen_data/img_data/{nissl_id}/tvr.nii.gz', sitk.sitkFloat32)
        total_image += tvr_float
        count += 1
    
    sitk.WriteImage(total_image, 'total.nii.gz')
    sitk.WriteImage(total_image / count, 'average.nii.gz')
    return total_image, total_image / count

def test_local_alignment(moving_image:sitk.Image, fixed_image:sitk.Image, coarse_grid_size = [8,8]) -> sitk.Image:
    import SimpleITK as sitk
    
    initial_transform = sitk.BSplineTransformInitializer(fixed_image, coarse_grid_size)
    registration_method = sitk.ImageRegistrationMethod()
    registration_method.SetMetricAsMattesMutualInformation()
    registration_method.SetOptimizerAsLBFGS2()
    registration_method.SetInitialTransform(initial_transform, inPlace=False)
    registration_method.SetOptimizerScalesFromPhysicalShift()
    registration_method.SetInterpolator(sitk.sitkLinear)
    final_transform = registration_method.Execute(fixed_image, moving_image)
    resampler = sitk.ResampleImageFilter()
    resampler.SetReferenceImage(fixed_image)
    resampler.SetInterpolator(sitk.sitkLinear)
    resampler.SetTransform(final_transform)
    aligned_image = resampler.Execute(moving_image)
    
    return aligned_image

def test_local_aligenment_demo(sample_vol:sitk.Image, conv_ref_vol:sitk.Image):
    
    image_res_list = []
    for index in range(sample_vol.GetSize()[2]):
        if np.max(sitk.GetArrayFromImage(sample_vol[:,:,index])) > 0 and np.max(sitk.GetArrayFromImage(conv_ref_vol[:,:,index])) > 0:
            image_res_list.append(test_local_alignment(sample_vol[:,:,index], conv_ref_vol[:,:,index]))
        else:
            image_res_list.append(sample_vol[:,:,index])
    
    image_res = sitk.JoinSeries(image_res_list)
    image_res.SetSpacing(sample_vol.GetSpacing()) 
    
    return image_res

def test_center_ish_allen_img(img, out_img_path:typing.Optional[str] = None):
    if isinstance(img, str):
        img = sitk.ReadImage(img, sitk.sitkUInt8)
    elif isinstance(img, np.ndarray):
        img = sitk.GetImageFromArray(np.array(img, dtype = "uint8"), isVector = False)
    else:
        return 0
    # gg = sitk.SmoothingRecursiveGaussian(sitk.IntensityWindowing(img, intensity_min, intensity_max), 150, True)
    otsu = sitk.OtsuThresholdImageFilter()
    otsu.SetNumberOfHistogramBins(10)
    otsu.SetInsideValue(1)
    otsu.SetOutsideValue(0)
    og = otsu.Execute(img)
    fs = sitk.LabelShapeStatisticsImageFilter()
    fs.SetBackgroundValue(0)
    fs.Execute(og)
    center_physical_coordinates = fs.GetCentroid(1)
    if out_img_path:
        plt.imshow(sitk.GetArrayFromImage(og), cmap = 'gray_r')
        plt.plot([0, center_physical_coordinates[0]],[0, center_physical_coordinates[1]])
        plt.savefig(out_img_path)
        plt.close()
    return og.TransformPhysicalPointToIndex(center_physical_coordinates)

def test_center_ish_allen_img_demo(nii_path, out_img_dir, n_process = 8):
    def find_jpg_files(directory):
        file_lists = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.lower().endswith('.jpg'):
                    file_lists.append(file)
        return file_lists
    
    # jpg_files = find_jpg_files(img_dir)
    # for jpg_file_path in jpg_files:
    #     test_center_nissl_allen_img(img_path = jpg_file_path, out_img_path = str.replace(jpg_file_path, '.jpg', '_center.jpg'), img_type = img_type)

    if not os.path.exists(out_img_dir):
        os.makedirs(out_img_dir)

    nii_array = sitk.GetArrayFromImage(sitk.ReadImage(nii_path))
    if len(nii_array.shape) == 4:
        nii_array = nii_array[:,:,:,0].copy()
    elif len(nii_array.shape) == 3:
        pass
    else:
        return 0
    
    print('read over')
    slice_indexs = [index for index in range(0, nii_array.shape[0])]
    with concurrent.futures.ProcessPoolExecutor(max_workers = n_process) as excutor:
        futs = [excutor.submit(test_center_ish_allen_img, img = nii_array[index, :, :].copy(), out_img_path = f"{out_img_dir}/{index}_center.jpg") for index in slice_indexs]
        for _ in concurrent.futures.as_completed(futs):
            pass
        

def test_single_nissl_train_dataset(sec_id, ref_vol, sample_image_path, conv_ref_image_path):
    import SimpleITK as sitk
    vols = test_stack_sample_image_by_allen_alignment(sec_id, file_path = utils.STORE_IMG_DATA_PATH, set_size = (11400, 11000),  transform_spacing = [25, 25], ref_vol = ref_vol)
    for index in range(vols[0].GetSize()[2]):
        if np.max(sitk.GetArrayFromImage(vols[0][:,:,index])) > 0 and np.max(sitk.GetArrayFromImage(vols[2][:,:,index])) > 0:
            sitk.WriteImage(vols[0][:,:,index], f"{sample_image_path}/{sec_id}_{index}.tiff")
            sitk.WriteImage(vols[2][:,:,index], f"{conv_ref_image_path}/{sec_id}_{index}.tiff")
    print(sec_id, "finished")
    
def make_nissl_train_dataset_demo(data_set_path, ref_vol, plane = 'coronal', ids_range = (0, 100), n_process = 12):
    import concurrent.futures
    if ids_range:
        nissl_ids = utils.test_count_nissl_coronal_plane_ids(plane)[0][ids_range[0]:ids_range[1]]
    else:
        nissl_ids = utils.test_count_nissl_coronal_plane_ids(plane)[0]
    
    print(f"The nums of samples is {len(nissl_ids)}")
    if not os.path.exists(f"{data_set_path}/trainA"):
        os.makedirs(f"{data_set_path}/trainA")
        
    if not os.path.exists(f"{data_set_path}/trainB"):
        os.makedirs(f"{data_set_path}/trainB")
    
    with concurrent.futures.ProcessPoolExecutor(max_workers = n_process) as excutor:
        futs = [excutor.submit(test_single_nissl_train_dataset, sec_id = sec_id,  ref_vol = ref_vol, sample_image_path = f"{data_set_path}/trainA", conv_ref_image_path = f"{data_set_path}/trainB") for sec_id in nissl_ids]
        for _ in concurrent.futures.as_completed(futs):
            pass

def get_ish_stack_expression_vol(sec_id:typing.Optional[int] = None, gene_name:typing.Optional[str] = None, plane_of_section_id:typing.Literal[1, 2] = 1, file_path = utils.STORE_EXP_VOL_PATH, is_force:bool = False, ref_vol:typing.Optional[sitk.Image] = None) -> sitk.Image:
    '''
        plane_of_section_id: 1 for coronal, 2 for sagittal.
    '''
    
    if (sec_id and gene_name) or (not sec_id and not gene_name):
        raise('check sec_id and gene_name parameters again')
    if sec_id:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen, alignment3d,genes, section_images(alignment2d)')
    if gene_name:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_of_section_id}]", include=f"specimen, alignment3d, genes[acronym$eq'{gene_name}'], section_images(alignment2d)")
    
    if not sec_info:
        raise('No sec_info for this parameters')
    
    sec_id = sec_info[0]['id']
    exp_path = f"{file_path}/{sec_id}/ss.nii.gz"
    tvr_path = f"{file_path}/{sec_id}/tvr.nii.gz"
    trv_path = f"{file_path}/{sec_id}/trv.nii.gz"
    os.makedirs(f"{file_path}/{sec_id}", exist_ok = True)
    if not is_force and os.path.exists(exp_path) and os.path.exists(tvr_path) and os.path.exists(trv_path):
        return exp_path, tvr_path, trv_path
    
    donor_id = sec_info[0]['specimen']['donor_id']
    gene_name = sec_info[0]['genes'][0]['acronym']
    donor_exp_vol = sitk.ReadImage(get_donor_brain_vol(donor_id, view = 'expression')[0])
    exp_mask_image = sitk.Image(donor_exp_vol.GetSize(), sitk.sitkUInt8)
    exp_mask_image.CopyInformation(donor_exp_vol)
    for image_info in sec_info[0]['section_images']:
        exp_mask_image[:,:,image_info['section_number']] = 1
        
    exp_vol = sitk.Mask(donor_exp_vol, exp_mask_image, maskingValue = 1)
    tvr_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'trv')
    trv_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'tvr')
    tvr_transform3d = sitk.AffineTransform(3)
    tvr_transform3d.SetParameters(tvr_alignment3d)
    trv_transform3d = sitk.AffineTransform(3)
    trv_transform3d.SetParameters(trv_alignment3d)
      
    if not ref_vol:
        ref_vol = sitk.ReadImage('/home/t207/wd_disk/server/allen_project/data/reference_cache/stpt/average_template_25.nrrd')
        
    sitk.WriteImage(sitk.Resample(exp_vol, ref_vol, tvr_transform3d), tvr_path)
    sitk.WriteImage(sitk.Resample(ref_vol, exp_vol, trv_transform3d), trv_path)    
    sitk.WriteImage(exp_vol, exp_path)
    
    return exp_path, tvr_path, trv_path

# %%
def test_alignment_2d(x:int, y:int, alignment2d:dict, ver = "tsv") -> tuple:
   
    vx = x * alignment2d[f'{ver}_00'] + y * alignment2d[f'{ver}_01'] + alignment2d[f'{ver}_04']
    vy = x * alignment2d[f'{ver}_02'] + y * alignment2d[f'{ver}_03'] + alignment2d[f'{ver}_05']

    return vx, vy

def test_alignment_3d(x:float, y:float, z:float, alignment3d:dict, ver = "tvr") -> tuple:

    vx = x * alignment3d[f'{ver}_00'] + y * alignment3d[f'{ver}_01'] + z * alignment3d[f'{ver}_02'] + alignment3d[f'{ver}_09']
    vy = x * alignment3d[f'{ver}_03'] + y * alignment3d[f'{ver}_04'] + z * alignment3d[f'{ver}_05'] + alignment3d[f'{ver}_10']
    vz = x * alignment3d[f'{ver}_06'] + y * alignment3d[f'{ver}_07'] + z * alignment3d[f'{ver}_08'] + alignment3d[f'{ver}_11']

    return vx, vy, vz

def test_alignment2d_section_image_to_3dreference(sec_id:int, image_id:int, ref_shape:tuple = RFP_RES_GRIDSHAPE[10], ref_spacing:int = (10, 10, 10), file_path:str = IMG_DATA_PATH, view:str = "raw", ver2d = "tsv", ver3d = "tvr") -> sitk.Image:
    section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "alignment3d")[0]
    sub_image_meta = RMA.model_query('SectionImage', num_rows = 'all', criteria = f"[id$eq{image_id}]", include = "alignment2d")[0]
    section_number = sub_image_meta['section_number']
    section_thickness = section_data_meta['section_thickness']
    raw_img = sitk.ReadImage(f"{file_path}/{sec_id}/{view}/{image_id}.jpg")
    ref_img = sitk.Image((ref_shape), sitk.sitkVectorUInt8, 3)
    ref_img.SetSpacing(ref_spacing)
    set_pixel_times = 0
    for w in range(0, raw_img.GetWidth()):
        for h in range(0, raw_img.GetHeight()):
            t_wx, t_hy = test_alignment_2d(w, h, sub_image_meta["alignment2d"], ver2d)
            pval = raw_img.GetPixel(w, h)
            p_ref = ref_img.TransformPhysicalPointToIndex(test_alignment_3d(t_wx, t_hy, section_number * section_thickness, section_data_meta["alignment3d"], ver3d))
            if not np.argwhere(np.array(p_ref) < 0).size > 0:
                try:
                    ref_img.SetPixel(p_ref, pval)
                    set_pixel_times = set_pixel_times + 1
                except:
                    print(w, h)
                    print(p_ref)

    return ref_img

def test_alignment_section_images_to_3dreference(sec_id:int, ref_shape:tuple = RFP_RES_GRIDSHAPE[10], ref_spacing:int = (10, 10, 10), file_path:str = IMG_DATA_PATH, view:str = "raw", ver2d = "tsv", ver3d = "tvr") -> sitk.Image:
    section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "alignment3d, section_images")[0]
    section_thickness = section_data_meta['section_thickness']
    ref_img = sitk.Image((ref_shape), sitk.sitkVectorUInt8, 3)
    ref_img.SetSpacing(ref_spacing)
    set_pixel_times = 0
    for section_image_meta in section_data_meta['section_images']:
        raw_img = sitk.ReadImage(f"{file_path}/{sec_id}/{view}/{section_image_meta['id']}.jpg")
        section_number = section_image_meta['section_number']
        alignment2d = RMA.model_query('SectionImage', num_rows = 'all', criteria = f"[id$eq{section_image_meta['id']}]", include = "alignment2d")[0]["alignment2d"]
        for w in range(0, raw_img.GetWidth()):
            for h in range(0, raw_img.GetHeight()):
                t_wx, t_hy = test_alignment_2d(w, h, alignment2d, ver2d)
                pval = raw_img.GetPixel(w, h)
                p_ref = ref_img.TransformPhysicalPointToIndex(test_alignment_3d(t_wx, t_hy, section_number * section_thickness, section_data_meta["alignment3d"], ver3d))
                if not np.argwhere(np.array(p_ref) < 0).size > 0:
                    try:
                        ref_img.SetPixel(p_ref, pval)
                        set_pixel_times = set_pixel_times + 1
                    except:
                        pass

    return ref_img


def test_build_alignment_2d(alignment2d:dict, ver = "tsv") -> tuple:

    return (alignment2d[f'{ver}_00'],alignment2d[f'{ver}_01'],alignment2d[f'{ver}_02'],alignment2d[f'{ver}_03'],alignment2d[f'{ver}_04'],alignment2d[f'{ver}_05'])

def test_build_alignment_3d(alignment3d:dict, ver = "tvr") -> tuple:

    return (alignment3d[f'{ver}_00'],alignment3d[f'{ver}_01'],alignment3d[f'{ver}_02'],alignment3d[f'{ver}_03'],alignment3d[f'{ver}_04'],alignment3d[f'{ver}_05'], alignment3d[f'{ver}_06'],alignment3d[f'{ver}_07'],alignment3d[f'{ver}_08'],alignment3d[f'{ver}_09'],alignment3d[f'{ver}_10'],alignment3d[f'{ver}_11'])

def test_second_alignment2d_section_image_to_3dreference(sec_id:int, ref_shape:tuple = RFP_RES_GRIDSHAPE[10], ref_spacing:int = (10, 10, 10), file_path:str = IMG_DATA_PATH, view:str = "raw", ver2d = "tsv", ver3d = "tvr", img_dtype = sitk.sitkVectorUInt8) -> sitk.Image :

    ref_vol = sitk.Image((ref_shape), img_dtype, 3)
    ref_vol.SetSpacing(ref_spacing)

    section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "alignment3d, section_images(alignment2d)")[0]
    section_thickness = section_data_meta['section_thickness']

    max_section_number, max_width, max_height = 0, 0, 0
    alignment3d = section_data_meta['alignment3d']
    transform3d = sitk.AffineTransform(3)
    transform3d.SetParameters(test_build_alignment_3d(alignment3d, ver3d))

    for sec_img_meta in section_data_meta['section_images']:
        max_width = max_width if max_width > sec_img_meta['width'] else sec_img_meta['width']
        max_height = max_height if max_height > sec_img_meta['height'] else sec_img_meta['height']
        max_section_number = max_section_number if max_section_number > sec_img_meta['section_number'] else sec_img_meta['section_number']

    sample_stack_vol = sitk.Image((max_width, max_height, max_section_number), img_dtype, 3)
    sample_stack_vol.SetSpacing((1, 1, int(section_thickness)))
    # sample_stack_vol = sitk.Image((ref_shape), img_dtype, 3)
    # sample_stack_vol.SetSpacing(ref_spacing)

    for sec_img_meta in section_data_meta['section_images']:
        img = sitk.ReadImage(f"{file_path}/{sec_id}/{view}/{sec_img_meta['id']}.jpg")
        # img = image_utilities.resample_volume(raw_img, [max_width, max_height], img_dtype, sitk.sitkLinear)
        transform2d = sitk.AffineTransform(2)
        transform2d.SetParameters(test_build_alignment_2d(sec_img_meta['alignment2d']))
        sample_stack_vol = image_utilities.resample_into_volume(img, transform2d, sec_img_meta['section_number'], sample_stack_vol, img_dtype)
        # sample_stack_vol = image_utilities.resample_into_volume(img, transform2d, int(sec_img_meta['section_number'] * section_thickness), sample_stack_vol, img_dtype)
        # ref_vol = image_utilities.resample_into_volume(sitk.Resample(image1 = img, transform = transform2d), transform3d, sec_img_meta['section_number'], ref_vol, img_dtype)
    
    return sitk.Resample(image1 = sample_stack_vol, referenceImage = ref_vol, transform = transform3d)

def test_stack_sample_image_by_allen_alignment(sec_id:int = 74881161, file_path:str = utils.IMG_DATA_PATH, view:str = "raw", ver2d:str = "tvs", ver3d:tuple = ("trv", "tvr"), img_dtype = sitk.sitkVectorUInt8, set_size:tuple = (11400, 10000), transform_spacing:tuple = (25, 25), is_download:bool = False, ref_vol:typing.Optional[sitk.Image] = None, is_force = False) -> tuple:
    
    ss_path = f"{file_path}/{sec_id}/ss.nii.gz"
    tvr_path = f"{file_path}/{sec_id}/tvr.nii.gz"
    trv_path = f"{file_path}/{sec_id}/trv.nii.gz"
    
    if not is_force and os.path.exists(ss_path) and os.path.exists(tvr_path) and os.path.exists(trv_path):
        return sitk.ReadImage(ss_path), sitk.ReadImage(tvr_path), sitk.ReadImage(trv_path)
    
    RMA = RmaApi()
    if is_download:
        utils.download_section_data_set_images(sec_id, file_path = file_path, view = view)
    section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "alignment3d, section_images(alignment2d)")[0]
    section_thickness = section_data_meta['section_thickness']
    imgs_meta = pd.DataFrame(section_data_meta['section_images']).sort_values(by = 'section_number')

    alignment3d = section_data_meta['alignment3d']
    tvr_transform3d = sitk.AffineTransform(3)
    tvr_transform3d.SetParameters(test_build_alignment_3d(alignment3d,  ver3d[0]))
    trv_transform3d = sitk.AffineTransform(3)
    trv_transform3d.SetParameters(test_build_alignment_3d(alignment3d, ver3d[1]))
    if not ref_vol:
        ref_vol = sitk.ReadImage('/home/t207/wd_disk/server/allen_project/data/reference_cache/average_template/average_template_25.nrrd')
    
    if not set_size:
        max_width, max_height = max(imgs_meta['width']), imgs_meta['height']
    else:
        max_width, max_height = set_size[0], set_size[1]
        
    isVector = False if img_dtype == sitk.sitkUInt8 else True    
    sample_shape = (max_height, max_width) if img_dtype == sitk.sitkUInt8 else (max_height, max_width, 3)
    sample_image = sitk.GetImageFromArray(np.zeros(sample_shape, dtype = "uint8"), isVector = isVector)
    prev_section_number = -1
    stack_vol_list = []
    
    stack_vol_list.append(resample_image_specific_spacing(sample_image, transform_spacing))
    for row in imgs_meta[['id','section_number','alignment2d']].itertuples():
        img = 255 - sitk.ReadImage(f"{file_path}/{sec_id}/{view}/{row[1]}.jpg", img_dtype)
        transform2d = sitk.AffineTransform(2)
        transform2d.SetParameters(test_build_alignment_2d(row[3], ver2d))
        timage = sitk.Resample(img, sample_image, transform2d, sitk.sitkLinear, 0.0)
        stack_vol_list.append(resample_image_specific_spacing(timage, transform_spacing))
        stack_vol_list = stack_vol_list + [resample_image_specific_spacing(sample_image, transform_spacing) for _ in range(row[2] - prev_section_number - 1)]
        prev_section_number = row[2]
        
    stack_vol_list.append(resample_image_specific_spacing(sample_image, transform_spacing))
    stack_vol = sitk.JoinSeries(stack_vol_list)
    stack_vol.SetSpacing((transform_spacing[0], transform_spacing[1], section_thickness))
    
    sitk.WriteImage(stack_vol, ss_path)
    sitk.WriteImage(sitk.Resample(stack_vol, ref_vol, tvr_transform3d), tvr_path)
    sitk.WriteImage(sitk.Resample(ref_vol, stack_vol, trv_transform3d), trv_path)
    
    return stack_vol, sitk.Resample(stack_vol, ref_vol, tvr_transform3d), sitk.Resample(ref_vol, stack_vol, trv_transform3d)

def test_get_paired_train_data_set(sample_vol:sitk.Image, conv_ref_vol:sitk.Image, mode:typing.Literal['aligned', 'unaligned'] = 'unaligned', datasets_dir:str = "/home/t207/wd_disk/server/allen_project/notebook/cgan/datasets/nissl"):
    
    if mode == 'unaligned':
        trainA_dir = f"{datasets_dir}/trainA"
        trainB_dir = f"{datasets_dir}/trainB"
    else:
        trainA_dir = f"{datasets_dir}/A/train"
        trainB_dir = f"{datasets_dir}/B/train"
        
    if not os.path.exists(trainA_dir):
        os.makedirs(trainA_dir)
    if not os.path.exists(trainB_dir):
        os.makedirs(trainB_dir)
    
    for index in range(sample_vol.GetSize()[2]):
        if np.max(sitk.GetArrayFromImage(sample_vol[:,:,index])) > 0 and np.max(sitk.GetArrayFromImage(conv_ref_vol[:,:,index])) > 0:
            sitk.WriteImage(sample_vol[:,:,index], f"{trainA_dir}/{index}.tiff")
            sitk.WriteImage(conv_ref_vol[:,:,index], f"{trainB_dir}/{index}.tiff")

def test_syn_expression_intensity_img(ish_image = None, exp_image = None, use_img:typing.Literal['exp', 'ish'] = 'ish', px_spacing = 1.0, grid_spacing = 200, ct_index = 2) -> sitk.Image:
    
    intensity_ct_dict = {1:[0.21, 0.72, 0.07], 2:[0.3,0.59,0.11]} # the order in list is red, green, blue
    # 1 is in https://community.brain-map.org/t/quantification-of-gene-expression-by-in-situ-hybridization-finding-and-using-the-raw-values/153/7 
    # 2 is in supplement of An anatomic gene expression atlas of the adult mouse brain article
    red_ct, green_ct, blue_ct = intensity_ct_dict[ct_index][0], intensity_ct_dict[ct_index][1], intensity_ct_dict[ct_index][2]
    if not ish_image:
        ish_image = sitk.ReadImage(f'{utils.STORE_IMG_DATA_PATH}/74881161/raw/74825013.jpg', sitk.sitkVectorFloat32)
    if not exp_image:
        exp_image = sitk.ReadImage(f'{utils.STORE_IMG_DATA_PATH}/74881161/expression/74825013.jpg', sitk.sitkVectorFloat32)
    pc_img = exp_image if use_img == 'exp' else ish_image
    gray_image = sitk.VectorIndexSelectionCast(exp_image, 0) + sitk.VectorIndexSelectionCast(exp_image, 1) + sitk.VectorIndexSelectionCast(exp_image, 2)  
    binary_mask = sitk.BinaryThreshold(gray_image, lowerThreshold = 1, upperThreshold = 255 * 3, insideValue = 1, outsideValue = 0)
    binary_mask = sitk.Cast(binary_mask, sitk.sitkFloat32)
    intensity_img = red_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 0) + green_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 1) + blue_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 2)
    raw_size = np.uint32(np.array(intensity_img.GetSize()))
    grid_px_size = int(np.floor(grid_spacing / px_spacing))
    grid_img_size = np.uint32(np.ceil(raw_size / grid_px_size))
    intensity_array = sitk.GetArrayFromImage(intensity_img).T
    pro_intensity_array = np.zeros(grid_img_size * grid_px_size)
    pro_intensity_array[:intensity_array.shape[0], :intensity_array.shape[1]] = intensity_array
    grid_array = []
    for h in range(0, pro_intensity_array.shape[1], grid_px_size):
        grid_row = list()
        for w in range(0, pro_intensity_array.shape[0], grid_px_size):
            grid_row.append(np.mean(pro_intensity_array[w:w + grid_px_size, h:h + grid_px_size]))
        grid_array.append(grid_row)
    grid_array = np.array(grid_array)
    grid_img = sitk.GetImageFromArray(grid_array)
    grid_img.SetSpacing((grid_spacing, grid_spacing))
    return grid_img

def get_ish_stack_expression_vol(sec_id:typing.Optional[int] = None, gene_name:typing.Optional[str] = None, plane_of_section_id:typing.Literal[1, 2] = 1, file_path = utils.STORE_EXP_VOL_PATH, is_force:bool = False, ref_vol:typing.Optional[sitk.Image] = None) -> sitk.Image:
    '''
        plane_of_section_id: 1 for coronal, 2 for sagittal.
    '''
    if (sec_id and gene_name) or (not sec_id and not gene_name):
        raise('check sec_id and gene_name parameters again')
    if sec_id:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen, alignment3d,genes, section_images(alignment2d)')
    if gene_name:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_of_section_id}]", include=f"specimen, alignment3d, genes[acronym$eq'{gene_name}'], section_images(alignment2d)")
    
    if not sec_info:
        raise('No sec_info for this parameters')
    
    sec_id = sec_info[0]['id']
    exp_path = f"{file_path}/{sec_id}/ss.nii.gz"
    tvr_path = f"{file_path}/{sec_id}/tvr.nii.gz"
    trv_path = f"{file_path}/{sec_id}/trv.nii.gz"
    os.makedirs(f"{file_path}/{sec_id}", exist_ok = True)
    if not is_force and os.path.exists(exp_path) and os.path.exists(tvr_path) and os.path.exists(trv_path):
        return exp_path, tvr_path, trv_path
    
    donor_id = sec_info[0]['specimen']['donor_id']
    gene_name = sec_info[0]['genes'][0]['acronym']
    donor_exp_vol = sitk.ReadImage(get_donor_brain_vol(donor_id, view = 'expression', background = 'w', img_dtype = sitk.sitkFloat32)[0])
    exp_mask_image = sitk.Image(donor_exp_vol.GetSize(), sitk.sitkUInt8)
    for image_info in sec_info[0]['section_images']:
        exp_mask_image[:, :, image_info['section_number']] = 1
        
    exp_vol = sitk.GetImageFromArray(sitk.GetArrayFromImage(donor_exp_vol) * sitk.GetArrayFromImage(exp_mask_image))
    exp_vol.CopyInformation(donor_exp_vol)
    tvr_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'trv')
    trv_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'tvr')
    tvr_transform3d = sitk.AffineTransform(3)
    tvr_transform3d.SetParameters(tvr_alignment3d)
    trv_transform3d = sitk.AffineTransform(3)
    trv_transform3d.SetParameters(trv_alignment3d)
      
    if not ref_vol:
        ref_vol = sitk.ReadImage(utils.get_reference_space())
        
    sitk.WriteImage(sitk.Resample(exp_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), tvr_path)
    sitk.WriteImage(sitk.Resample(ref_vol, exp_vol, trv_transform3d, sitk.sitkNearestNeighbor), trv_path)     
    sitk.WriteImage(exp_vol, exp_path)
    
    return exp_path, tvr_path, trv_path

def get_grid_ish_expression_rgb_vol(sec_id:typing.Optional[int] = None, gene_name:typing.Optional[str] = None, plane_of_section_id:typing.Literal[1, 2] = 1, set_size:typing.Optional[tuple] = None, is_force:typing.List[bool] = [False, False], sync_index:typing.Literal[1, 2] = 2, file_path:str = utils.STORE_EXP_VOL_PATH, grid_spacing:int = 200, use_img:typing.Literal['exp', 'ish'] = 'ish', img_path:str = utils.STORE_IMG_DATA_PATH, grid_vol_init_value:int = -1, smth_2d_sigma:int = 1, smth_3d_z_sigma:int = 1) -> tuple:
    '''
        The get_ish_stack_expression_vol function is for dowansample to 25um for expression intensity img, I want to from 1.04 res to get grid expression vol, then rewrite this function. 
        plane_of_section_id: 1 for coronal, 2 for sagittal. 
        Deprecate parameters: smooth_function:typing.types.FunctionType = sitk.SmoothingRecursiveGaussian, **smooth_function_parameters
    '''
    if (sec_id and gene_name) or (not sec_id and not gene_name):
        raise('check sec_id and gene_name parameters again')
    if sec_id:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen, alignment3d,genes, section_images(alignment2d)')
    if gene_name:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_of_section_id}]", include=f"specimen, alignment3d, genes[acronym$eq'{gene_name}'], section_images(alignment2d)")
    
    if not sec_info:
        raise('No sec_info for this parameters')
    
    grid_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_{grid_vol_init_value}_syn{sync_index}_{smth_2d_sigma}.nii.gz"
    grid_tvr_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_{grid_vol_init_value}_syn{sync_index}_{smth_2d_sigma}z{smth_3d_z_sigma}_tvr.nii.gz"
    grid_r_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_r.nii.gz"
    grid_g_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_g.nii.gz"
    grid_b_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_b.nii.gz"
    grid_path_lists = [grid_path, grid_r_path, grid_g_path, grid_b_path]
    
    os.makedirs(f"{file_path}/{sec_id}", exist_ok = True)
    
    plane_of_section_id = sec_info[0]['plane_of_section_id']
    if not set_size:
        set_size = (12800, 12800) if plane_of_section_id == 1 else (16000, 12000)
        
    imgs_pd = pd.DataFrame(sec_info[0]['section_images']).sort_values('section_number')
    section_thickness = sec_info[0]['section_thickness']
    donor_id = sec_info[0]['specimen']['donor_id']
    donor_vol = sitk.ReadImage(get_donor_brain_vol(donor_id)[0])
    
    grid_vol_dict = {}
    r_vol_dict = {}
    g_vol_dict = {}
    b_vol_dict = {}
    vol_dict_list = [grid_vol_dict, r_vol_dict, g_vol_dict, b_vol_dict]
    
    if is_force[0] or not os.path.exists(grid_path):
        sample_image = sitk.GetImageFromArray(np.zeros(set_size, dtype = "float32"), isVector = False)
        for row in imgs_pd[['data_set_id','id','section_number','alignment2d', 'resolution']].itertuples():
            transform2d = sitk.AffineTransform(2)
            transform2d.SetParameters(test_build_alignment_2d(row[4], 'tvs'))
            if utils.recon_download_image(row[2], view = 'expression', file_path = f"{img_path}/{row[1]}/expression/{row[2]}.jpg"):    
                exp_img = sitk.Resample(sitk.ReadImage(f"{img_path}/{row[1]}/expression/{row[2]}.jpg", sitk.sitkVectorFloat32), sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0)
            else:
                exp_img = sample_image
            if utils.recon_download_image(row[2], view = 'raw', file_path = f"{img_path}/{row[1]}/raw/{row[2]}.jpg"):
                ish_img = sitk.Resample(sitk.ReadImage(f"{img_path}/{row[1]}/raw/{row[2]}.jpg", sitk.sitkVectorFloat32), sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0)
            else:
                ish_img = sample_image
            intensity_img = syn_expression_img(ish_img, exp_img, use_img = use_img, ct_index = sync_index)
            intensity_img.SetSpacing((row[5], row[5]))
            mask_img = sitk.BinaryThreshold(intensity_img)
            rgb_img = ish_img if use_img == "ish" else exp_img 
            rgb_img.SetSpacing((row[5], row[5]))          
            r_grid_img = grid_image_by_spacing(sitk.VectorIndexSelectionCast(rgb_img, 0, sitk.sitkUInt8) * mask_img, grid_spacing)
            g_grid_img = grid_image_by_spacing(sitk.VectorIndexSelectionCast(rgb_img, 1, sitk.sitkUInt8) * mask_img, grid_spacing)
            b_grid_img = grid_image_by_spacing(sitk.VectorIndexSelectionCast(rgb_img, 2, sitk.sitkUInt8) * mask_img, grid_spacing)
            # grid_img = sitk.SmoothingRecursiveGaussian(grid_image_by_spacing(intensity_img, grid_spacing), sigma = smth_2d_sigma)
            grid_img = grid_image_by_spacing(intensity_img, grid_spacing)
            grid_img_list = [grid_img, r_grid_img, g_grid_img, b_grid_img] 
            
            for idx in range(4):
                grid_slice_index = np.int32(np.floor(row[3] / grid_spacing * section_thickness))
                if grid_slice_index in vol_dict_list[idx].keys():
                    vol_dict_list[idx][grid_slice_index].append(grid_img_list[idx])
                else:
                    vol_dict_list[idx][grid_slice_index] = [grid_img_list[idx]]
        
        for idx in range(4):     
            grid_vol = sitk.JoinSeries([sitk.Image(grid_img.GetSize(), sitk.sitkFloat64) for _ in range(np.int32(np.ceil(donor_vol.GetSize()[2] / grid_spacing * section_thickness)))])
            grid_vol.SetSpacing((grid_spacing, grid_spacing, grid_spacing))
            grid_vol[:, :, :] = grid_vol_init_value
            
            for sli_index in list(vol_dict_list[idx].keys()):
                sli_sum_img = 0
                for sli_img in vol_dict_list[idx][sli_index]:
                    sli_sum_img = sli_img + sli_sum_img
                grid_vol[:,:, int(sli_index)] = sli_sum_img / len(vol_dict_list[idx][sli_index])
            
            sitk.WriteImage(grid_vol, grid_path_lists[idx])
        
    if is_force[1] or not os.path.exists(grid_tvr_path):
        # grid_vol = smooth_function(sitk.ReadImage(grid_path), **smooth_function_parameters)
        grid_vol = sitk.ReadImage(grid_path)
        rfp = utils.get_reference_space_tree(grid_spacing)[0]
        ref_vol_numpy = rfp.annotation if grid_spacing != 200 else rfp.annotation.reshape(utils.ISH_GRID_SHAPE)
        ref_vol = sitk.GetImageFromArray(ref_vol_numpy)
        ref_vol.SetSpacing((grid_spacing, grid_spacing, grid_spacing))
        tvr_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'trv')
        tvr_transform3d = sitk.AffineTransform(3)
        tvr_transform3d.SetParameters(tvr_alignment3d)
        sitk.WriteImage(sitk.SmoothingRecursiveGaussian(sitk.Resample(grid_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), [smth_3d_z_sigma, 1, 1]), grid_tvr_path)
    
    return grid_path, grid_tvr_path

def get_ish_stack_expression_vol(sec_id:typing.Optional[int] = None, gene_name:typing.Optional[str] = None, plane_of_section_id:typing.Literal[1, 2] = 1, file_path = utils.STORE_EXP_VOL_PATH, is_force:bool = False, ref_vol:typing.Optional[sitk.Image] = None) -> sitk.Image:
    '''
        plane_of_section_id: 1 for coronal, 2 for sagittal.
    '''
    if (sec_id and gene_name) or (not sec_id and not gene_name):
        raise('check sec_id and gene_name parameters again')
    if sec_id:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen, alignment3d,genes, section_images(alignment2d)')
    if gene_name:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_of_section_id}]", include=f"specimen, alignment3d, genes[acronym$eq'{gene_name}'], section_images(alignment2d)")
    
    if not sec_info:
        raise('No sec_info for this parameters')
    
    sec_id = sec_info[0]['id']
    exp_path = f"{file_path}/{sec_id}/ss.nii.gz"
    tvr_path = f"{file_path}/{sec_id}/tvr.nii.gz"
    trv_path = f"{file_path}/{sec_id}/trv.nii.gz"
    os.makedirs(f"{file_path}/{sec_id}", exist_ok = True)
    if not is_force and os.path.exists(exp_path) and os.path.exists(tvr_path) and os.path.exists(trv_path):
        return exp_path, tvr_path, trv_path
    
    donor_id = sec_info[0]['specimen']['donor_id']
    gene_name = sec_info[0]['genes'][0]['acronym']
    donor_exp_vol = sitk.ReadImage(get_donor_brain_vol(donor_id, view = 'expression', background = 'w', img_dtype = sitk.sitkFloat32)[0])
    exp_mask_image = sitk.Image(donor_exp_vol.GetSize(), sitk.sitkUInt8)
    for image_info in sec_info[0]['section_images']:
        exp_mask_image[:, :, image_info['section_number']] = 1
        
    exp_vol = sitk.GetImageFromArray(sitk.GetArrayFromImage(donor_exp_vol) * sitk.GetArrayFromImage(exp_mask_image))
    exp_vol.CopyInformation(donor_exp_vol)
    tvr_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'trv')
    trv_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'tvr')
    tvr_transform3d = sitk.AffineTransform(3)
    tvr_transform3d.SetParameters(tvr_alignment3d)
    trv_transform3d = sitk.AffineTransform(3)
    trv_transform3d.SetParameters(trv_alignment3d)
      
    if not ref_vol:
        ref_vol = sitk.ReadImage(utils.get_reference_space())
        
    sitk.WriteImage(sitk.Resample(exp_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), tvr_path)
    sitk.WriteImage(sitk.Resample(ref_vol, exp_vol, trv_transform3d, sitk.sitkNearestNeighbor), trv_path)     
    sitk.WriteImage(exp_vol, exp_path)
    
    return exp_path, tvr_path, trv_path


def get_grid_ish_expression_vol(sec_id:typing.Optional[int] = None, gene_name:typing.Optional[str] = None, plane_of_section_id:typing.Literal[1, 2] = 1, set_size:typing.Optional[tuple] = None, is_force:typing.List[bool] = [False, False], sync_index:typing.Literal[1, 2] = 2, file_path:str = utils.STORE_EXP_VOL_PATH, grid_spacing:int = 200, use_img:typing.Literal['exp', 'ish'] = 'ish', img_path:str = utils.STORE_IMG_DATA_PATH, grid_vol_init_value:int = -1, smth_2d_sigma:int = 1, smth_3d_z_sigma:int = 1) -> tuple:
    '''
        The get_ish_stack_expression_vol function is for dowansample to 25um for expression intensity img, I want to from 1.04 res to get grid expression vol, then rewrite this function. 
        plane_of_section_id: 1 for coronal, 2 for sagittal. 
        Deprecate parameters: smooth_function:typing.types.FunctionType = sitk.SmoothingRecursiveGaussian, **smooth_function_parameters
    '''
    if (sec_id and gene_name) or (not sec_id and not gene_name):
        raise('check sec_id and gene_name parameters again')
    if sec_id:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen, alignment3d,genes, section_images(alignment2d)')
    if gene_name:
        sec_info = utils.recon_model_query(model = 'SectionDataSet', num_rows = 1, criteria = f"[failed$eq'false'], [plane_of_section_id$eq{plane_of_section_id}]", include=f"specimen, alignment3d, genes[acronym$eq'{gene_name}'], section_images(alignment2d)")
    
    if not sec_info:
        raise('No sec_info for this parameters')
    
    grid_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_{grid_vol_init_value}_syn{sync_index}_p{smth_2d_sigma}z{smth_3d_z_sigma}.nii.gz"
    grid_tvr_path = f"{file_path}/{sec_id}/grid_{grid_spacing}um_{use_img}_{grid_vol_init_value}_syn{sync_index}_p{smth_2d_sigma}z{smth_3d_z_sigma}_tvr.nii.gz"
    
    os.makedirs(f"{file_path}/{sec_id}", exist_ok = True)
    
    plane_of_section_id = sec_info[0]['plane_of_section_id']
    if not set_size:
        set_size = (12800, 12800) if plane_of_section_id == 1 else (16000, 12000)
        
    imgs_pd = pd.DataFrame(sec_info[0]['section_images']).sort_values('section_number')
    section_thickness = sec_info[0]['section_thickness']
    donor_id = sec_info[0]['specimen']['donor_id']
    donor_vol = sitk.ReadImage(get_donor_brain_vol(donor_id)[0])
    grid_vol_dict = {}
    
    if is_force[0] or not os.path.exists(grid_path):
        sample_image = sitk.GetImageFromArray(np.zeros(set_size, dtype = "float32"), isVector = False)
        for row in imgs_pd[['data_set_id','id','section_number','alignment2d', 'resolution']].itertuples():
            transform2d = sitk.AffineTransform(2)
            transform2d.SetParameters(test_build_alignment_2d(row[4], 'tvs'))
            if utils.recon_download_image(row[2], view = 'expression', file_path = f"{img_path}/{row[1]}/expression/{row[2]}.jpg"):    
                exp_img = sitk.Resample(sitk.ReadImage(f"{utils.STORE_IMG_DATA_PATH}/{row[1]}/expression/{row[2]}.jpg", sitk.sitkVectorFloat32), sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0)
            else:
                exp_img = sample_image
            if utils.recon_download_image(row[2], view = 'raw', file_path = f"{img_path}/{row[1]}/raw/{row[2]}.jpg"):
                ish_img = sitk.Resample(sitk.ReadImage(f"{utils.STORE_IMG_DATA_PATH}/{row[1]}/raw/{row[2]}.jpg", sitk.sitkVectorFloat32), sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0)
            else:
                ish_img = sample_image
            intensity_img = syn_expression_img(ish_img, exp_img, use_img = use_img, ct_index = sync_index)
            intensity_img.SetSpacing((row[5], row[5]))
            grid_img = sitk.SmoothingRecursiveGaussian(grid_image_by_spacing(intensity_img, grid_spacing), sigma = smth_2d_sigma)
            grid_slice_index = np.int32(np.floor(row[3] / grid_spacing * section_thickness))
            if grid_slice_index in grid_vol_dict.keys():
                grid_vol_dict[grid_slice_index].append(grid_img)
            else:
                grid_vol_dict[grid_slice_index] = [grid_img]
        
        grid_vol = sitk.JoinSeries([sitk.Image(grid_img.GetSize(), sitk.sitkFloat64) for _ in range(np.int32(np.ceil(donor_vol.GetSize()[2] / grid_spacing * section_thickness)))])
        grid_vol.SetSpacing((grid_spacing, grid_spacing, grid_spacing))
        grid_vol[:, :, :] = grid_vol_init_value
        for sli_index in list(grid_vol_dict.keys()):
            sli_sum_img = 0
            for sli_img in grid_vol_dict[sli_index]:
                sli_sum_img = sli_img + sli_sum_img
            grid_vol[:,:, int(sli_index)] = sli_sum_img / len(grid_vol_dict[sli_index])
        
        grid_vol = sitk.SmoothingRecursiveGaussian(grid_vol, sigma = [smth_3d_z_sigma, 1, 1])
        sitk.WriteImage(grid_vol, grid_path)
        
    if is_force[1] or not os.path.exists(grid_tvr_path):
        # grid_vol = smooth_function(sitk.ReadImage(grid_path), **smooth_function_parameters)
        grid_vol = sitk.ReadImage(grid_path)
        rfp = utils.get_reference_space_tree(grid_spacing)[0]
        ref_vol_numpy = rfp.annotation if grid_spacing != 200 else rfp.annotation.reshape(utils.ISH_GRID_SHAPE)
        ref_vol = sitk.GetImageFromArray(ref_vol_numpy)
        ref_vol.SetSpacing((grid_spacing, grid_spacing, grid_spacing))
        tvr_alignment3d = test_build_alignment_3d(sec_info[0]['alignment3d'], 'trv')
        tvr_transform3d = sitk.AffineTransform(3)
        tvr_transform3d.SetParameters(tvr_alignment3d)
        sitk.WriteImage(sitk.Resample(grid_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), grid_tvr_path)
    
    return grid_path, grid_tvr_path

def get_sum_sample_dl_ish_convert_nissl_vol(file_path, vol_type_index = 1, net_name = None, is_force = False, empty_slice_thval:int = 10, plane = "coronal", **load_net_params):
    if vol_type_index == 0:
        vol_type = "ss"
    elif vol_type_index == 1:
        vol_type = "tvr"
    else:
        vol_type = "trv"
    net_name = net_name if net_name else ""
    donors_ish_associate_nissl_info_dict = get_sepcific_donor_ids_ish_associate_nissl_info(plane)
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= empty_slice_thval]
    sum_vol_path = f"{file_path}/sum{len(donor_ids)}_{plane}_thv{empty_slice_thval}_{net_name}_{vol_type}.nii.gz"
    if not is_force and os.path.exists(sum_vol_path):
        return sum_vol_path
    dl_vols_paths = [get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id = donor_id, net_name = net_name, **load_net_params)[vol_type_index] for donor_id in donor_ids]
    sum_vol = 0
    for dl_vol_path in dl_vols_paths:
        sum_vol = sitk.ReadImage(dl_vol_path, sitk.sitkVectorUInt32) + sum_vol
    sitk.WriteImage(sum_vol, sum_vol_path)
    return sum_vol_path

def test_count_nissl_coronal_plane_ids(plane = 'coronal', file_path = IMG_DATA_PATH):
    import pickle
    import time
    
    RMA = RmaApi()
    comids = list(get_experiment_ids(plane, 1, 'ISH'))
    
    if not os.path.exists(file_path):
        os.makedirs(file_path)
    if os.path.exists(f"{file_path}/{plane}_paired_ish_nissl_id.tuple"):
        with open(f"{file_path}/{plane}_paired_ish_nissl_id.tuple", "rb") as f:
            res_ids = pickle.load(f)
        return res_ids
    
    nissl_res_ids = []
    fail_ids = []
    print(f"The nums of samples is {len(comids)}")
    for sec_id in comids:
        print(f"Now {comids.index(sec_id)}th sample")
        retry_times = 10
        is_success = False
        while not is_success:
            print(f"Process {sec_id}")
            try:
                section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "section_images")[0]
                is_success = True
            except:
                time.sleep(2)
        while is_success and retry_times:   
            try:
                nissl_data_set_id = RMA.model_query('SectionImage', criteria = f"[id$eq{section_data_meta['section_images'][0]['id']}]", include = "associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]['data_set']['id']
                nissl_res_ids.append(nissl_data_set_id)
                is_success = False
            except:
                retry_times = retry_times - 1
                time.sleep(2)
        if retry_times:
            fail_ids.append(sec_id)
            
    with open(f"{file_path}/{plane}_paired_ish_nissl_id.tuple", "wb") as f:
        pickle.dump((nissl_res_ids, fail_ids), f)
        
    return nissl_res_ids, fail_ids

# %%
def sagittal_half_mask(mask:np.ndarray, grid_shape:typing.Union[list, tuple, np.ndarray], sag_direction_index:typing.Literal[0, 1, 2], select_semi_brain:typing.Literal['l','r'], is_fallten:bool = True) -> np.ndarray:
    '''
        Params:
        sag_direction_index: for the 3d shape, which direction for the sagittal slice. i.e. if the index is 1, then we will select the first position and half it. See the source code for details.  
        select_semi_brain: for select left or right brian in sagittal direction. and 'r' for right, 'l' for left.  
    '''
    mask_copy = mask.copy().reshape(grid_shape)
    left_border = int(grid_shape[sag_direction_index] / 2) if select_semi_brain == 'r' else 0
    right_border = grid_shape[sag_direction_index] if select_semi_brain == 'r' else int(grid_shape[sag_direction_index] / 2) 
    if sag_direction_index == 0:
        mask_copy[left_border: right_border, :, :] = 0
    elif sag_direction_index == 1:
        mask_copy[:, left_border: right_border, :] = 0
    else:
        mask_copy[:, :, left_border: right_border] = 0
    if is_fallten:
        return mask_copy.flatten()
    return mask_copy

def grid_exp_normalization(grid:np.ndarray, miss_val:int = -1) -> np.ndarray:
    grid = grid.copy()
    gd = grid[np.where(grid != miss_val)]
    max_val = np.max(gd)
    min_val = np.min(gd)
    grid[np.where(grid != miss_val)] = (np.log2(gd + 1) - np.log2(min_val + 1)) / (np.log2(max_val + 1) - np.log2(min_val + 1))
    return grid

def count_imgs_of_ish_plane(is_cache:bool = True, plane:str = 'coronal', file_path = IMG_DATA_PATH) -> list:
    import pickle
    dict_path = f"{IMG_DATA_PATH}/count_sec_img_nums_{plane}.dict"
    if not os.path.exists(dict_path):
        is_cache = False

    if is_cache:
        with open(dict_path, "rb") as f:
            res_sec_dict = pickle.load(f)
        return res_sec_dict

    res_sec_dict = {}
    sec_ids =  get_ish_plane_ids(plane, '1')
    for sec_id in sec_ids:
        section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "section_images[failed$eq'False']")[0]
        res_sec_dict[sec_id] = len(section_data_meta['section_images'])

    with open(dict_path, "wb") as f:
        pickle.dump(res_sec_dict, f)       
    return res_sec_dict

def get_paired_nissl_images(sec_id:int = 74881161, sec_id_folder_path:str = IMG_DATA_PATH) -> dict:
    RMA = RmaApi()
    imapi = ImageDownloadApi()

    section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "section_images")[0]
    nissl_data_set_id = RMA.model_query('SectionImage', criteria = f"[id$eq{section_data_meta['section_images'][0]['id']}]", include = "associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]['data_set']['id']
    
    folder_path = f"{sec_id_folder_path}/{nissl_data_set_id}/raw"
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    
    img_meta = pd.DataFrame(section_data_meta['section_images'])
    img_ids = [row[1] for row in img_meta.sort_values(by = 'section_number')[['id','section_number']].itertuples()]
    nissl_ids = [RMA.model_query('SectionImage', criteria = f"[id$eq{img_id}]", include = "associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]['id'] for img_id in img_ids]
    
    img_downloaded_dict = dict()
    img_downloaded_dict['nissl_data_set_id'] = nissl_data_set_id
    
    for nissl_id in nissl_ids:
        img_download_path = f"{folder_path}/{nissl_id}.jpg"
        download_time = 20
        while download_time and (not os.path.exists(img_download_path) or os.path.getsize(img_download_path) < 1024):
            try:
                imapi.download_image(nissl_id, file_path = img_download_path)
            except:
                print('Download Code May Contain Wrong Parameters, Please Check')
            download_time = download_time - 1
            time.sleep(2)
        if download_time:
            img_downloaded_dict[img_ids[nissl_ids.index(nissl_id)]] = img_download_path
            
    return img_downloaded_dict


