# %%
import pathlib
import json
import anndata
import typing
import requests
import zipfile
import os
import concurrent
import abc_atlas_access
import nrrd
import time
import shutil

import numpy as np
import pandas as pd
import SimpleITK as sitk
import skimage as ski

from abc_atlas_access.abc_atlas_cache.abc_project_cache import AbcProjectCache
from allensdk.core.reference_space_cache import ReferenceSpaceCache
from allensdk.api.queries.ontologies_api import OntologiesApi
from allensdk.core.structure_tree import StructureTree
from allensdk.core.reference_space import ReferenceSpace
from allensdk.api.queries.rma_api import RmaApi
from allensdk.api.queries.grid_data_api import GridDataApi
from allensdk.core.mouse_connectivity_cache import MouseConnectivityCache
from allensdk.api.queries.image_download_api import ImageDownloadApi
from allensdk.api.queries.grid_data_api import GridDataApi

from allensdk.api.queries.mouse_connectivity_api import MouseConnectivityApi
from allensdk.api.queries.synchronization_api import SynchronizationApi
from allensdk.mouse_connectivity.grid.utilities import image_utilities

# %%
# macro variables
# abc
PATH_PRFIX = "/home/t207/wd_disk/server"
ABC_MANIFEST_PATH = PATH_PRFIX + "/" + "allen_project/data/abc_data"
REF_MANIFEST_PATH = PATH_PRFIX + "/" + "allen_project/data/reference_cache"
ISH_DATA_PATH = PATH_PRFIX + "/" + "allen_project/data/ish_data"
ALLEN_CCF = 'Allen-CCF-2020'
ALLEN_CCF_FILES = ['average_template_10', 'annotation_10', 'annotation_boundary_10']
SP_DATASETS = ['Zhuang-ABCA-1', 'Zhuang-ABCA-2', 'Zhuang-ABCA-3', 'Zhuang-ABCA-4', 'MERFISH-C57BL6J-638850', 'MERFISH-C57BL6J-638850-imputed']
ALLEN_CCF_FILENAME = 'ccf_coordinates'
GENE_EXPR_NUMERIC_TYPES = ['log2', 'raw']
IMG_DATA_PATH = PATH_PRFIX + "/" + 'allen_project/data/img_data'
CON_DATA_PATH = PATH_PRFIX + "/" + 'allen_project/data/con_data'
MRI_DATA_PATH = PATH_PRFIX + "/" + 'allen_project/data/mri_data'
CCF_DATA_PATH = PATH_PRFIX + "/" + 'allen_project/data/ccf_data'
STORE_IMG_DATA_PATH = '/home/t207/Lab_Data_preproc2/allen_data/img_data'
STORE_DONOR_VOL_PATH = '/home/t207/Lab_Data_preproc2/allen_data/donor_vol'
STORE_EXP_VOL_PATH = '/home/t207/Lab_Data_preproc2/allen_data/exp_vol'
STORE_REG_VOL_PATH = '/home/t207/lab_data_preproc3/allen_data/reg_vol'
ANTS_REG_TMP = f"{STORE_REG_VOL_PATH}/tmp"

# allen sectiondataset
# The Common Coordinate Framework (CCF) is defined in a basic image coordinate system, using the top-left-rear pixel as its origin, and incrementing in the X, Y and Z axes up to the number of pixels in each dimension (ML, DV, AP respectively). 
RMA = RmaApi()
RFP_RES_GRIDSHAPE = { # RES : (AP,DV,ML)
        10 : (1320, 800, 1140),
        25 : (528, 320, 456),
        50 : (264, 160, 228),
        100 : (132, 80, 114)
        }
ISH_GRID_SHAPE = (58, 41, 67) # (ML, DV, AP)
SAG_NO_ENERGY_ID = [1013, 822, 526, 819, 784, 1267, 1426, 813, 375, 639, 386, 442, 695, 627, 564] # Note: those IDs is sagital plane ISH grid data and have no energy voulume type data.

# %%
def clear_folder(folder_path):
    if not os.path.exists(folder_path):
        print("the dir does not exists")
        return
    
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print(f"has a error when delete {file_path}: {e}")

def download_file(url:str, filename:str) -> bool:
    # Send a GET request to the URL
    response = requests.get(url)
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Open the file in binary write mode and write the content from the response
        with open(filename, 'wb') as file:
            file.write(response.content)
        return True
    return False

def check_internet_status() -> bool:
    response = requests.get('https://www.baidu.com', timeout=10)
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        return True
    return False

def extract_zip_numpy(zip_file_path:str, fn:str, dtype:str = "float32") -> np.ndarray:
    with zipfile.ZipFile(zip_file_path, mode="r") as archive:
        buf = archive.read(fn)
        var = np.frombuffer(buf, dtype = dtype, count = -1)
    return var

def write_zip_numpy(var:np.ndarray, zip_file_path:str, zn:str = 'energy.raw'):
    fn = "tmpfile"
    with zipfile.ZipFile(zip_file_path, mode = "w", compression = zipfile.ZIP_DEFLATED, compresslevel = 9) as archive:
        with open(fn, "wb") as f:
            var.tofile(f)
        archive.write(filename = fn, arcname = zn)
    os.remove(fn)

def remove_empty_dirs(path):
    if not os.path.exists(path):
        return
    
    if not os.path.isdir(path):
        return
    
    if not os.listdir(path):
        print(f'Deleting empty directory: {path}')
        os.rmdir(path)
    else:
        for item in os.listdir(path):
            item_path = os.path.join(path, item)
            remove_empty_dirs(item_path)

# %%
def get_reference_space(ref_type: typing.Literal["nissl", "stpt"] = "nissl", file_type:typing.Literal["nrrd", "nii.gz"] = "nrrd", spacing: int = 25, file_dir: typing.Optional[str] = None) -> str:
    file_dir = REF_MANIFEST_PATH if not file_dir else file_dir
    if os.path.exists(f"{file_dir}/{ref_type}/ara_{ref_type}_{spacing}.{file_type}"):
        return f"{file_dir}/{ref_type}/ara_{ref_type}_{spacing}.{file_type}"
    else:
        return False

def get_label_space(file_type:typing.Literal["nrrd", "nii.gz"] = "nrrd", spcing: int = 25, file_dir: typing.Optional[str] = None) -> str:
    file_dir = REF_MANIFEST_PATH if not file_dir else file_dir
    if os.path.exists(f"{file_dir}/annotation/annotation_{spcing}.{file_type}"):
        return f"{file_dir}/annotation/annotation_{spcing}.{file_type}"
    else:
        return False

def get_resample_spacing_rfvol_path(file_path, res_file_path, spacing = 25, is_force = False):
    import ants

    if not is_force and os.path.exists(res_file_path):
        return res_file_path
    
    vol = ants.image_read(file_path)
    if spacing != 10:
        vol = ants.resample_image(vol, RFP_RES_GRIDSHAPE[spacing], True, 1)
    
    vol_numpy = vol.numpy()
    vol = ants.from_numpy(vol_numpy, spacing = (spacing, spacing, spacing))
    
    ants.image_write(vol, res_file_path)
    
    return res_file_path    

def get_boundary_space(spacing = 25, file_path = '/home/t207/Lab_Data_preproc2/allen_data/ccf_files', is_force = False, only_isocortex = False):
    file_name = f"isocortex_boundary" if only_isocortex else f"annotation_boundary"
    
    raw_boundary_file_path = f"{file_path}/{file_name}_{10}.nii.gz"
    boundary_file_path = f"{file_path}/{file_name}_{spacing}.nrrd"
    
    return get_resample_spacing_rfvol_path(raw_boundary_file_path, boundary_file_path, spacing, is_force) 

def get_isocortex_mask_vol(spacing = 25, file_path = '/home/t207/Lab_Data_preproc2/allen_data/ccf_files', is_force = False):
    
    raw_mask_file_path = f"{file_path}/isocortex_mask_10.nii.gz"
    mask_file_path = f"{file_path}/isocortex_mask_{spacing}.nrrd"
    
    return get_resample_spacing_rfvol_path(raw_mask_file_path, mask_file_path, spacing, is_force)

# %%
def get_abc_cache(manifest_path:str = ABC_MANIFEST_PATH, is_check_downloaded_data_json:bool = False) -> abc_atlas_access.abc_atlas_cache.abc_project_cache.AbcProjectCache:
    if not os.path.exists(manifest_path):
        os.makedirs(manifest_path)

    # if have downloaded data, and changed the path in somewhere, then the all data paths in "/_downloaded_data.json" must be also changed to the new path in coord with the new manifest_path.  
    # offical api will not change it by itself.  
    download_data_json_path = manifest_path + "/_downloaded_data.json"
    if os.path.exists(download_data_json_path) and is_check_downloaded_data_json:
        with open(download_data_json_path, "r") as f:
            data_paths = json.load(f)
        if data_paths:
            data_path = data_paths[0]
            # TODO.  use simple key words to get the path prefix.  
            for key_word in ["expression_matrices", "image_volumes", "mapmycells", "metadata"]:
                if key_word in data_path:
                    old_manifest_prefix_right_border = data_path.index(key_word)
                    break
            old_manifest_path = data_path[:old_manifest_prefix_right_border]
            new_data_paths = []
            for data_path in data_paths: 
                if old_manifest_path in data_path:
                    new_data_paths.append(data_path.replace(old_manifest_path, manifest_path + "/"))
            with open(download_data_json_path,"w") as f:
                json.dump(new_data_paths, f)

    return AbcProjectCache.from_s3_cache(pathlib.Path(manifest_path))

def get_abc_all_data(abc_cache:typing.Optional[abc_atlas_access.abc_atlas_cache.abc_project_cache.AbcProjectCache], skip_hash_check:bool = True, force_download:bool = False, max_workers:int = 8) -> bool:
    def work_download_function(item):
        try:
            abc_cache.get_directory_data(directory = item, skip_hash_check = skip_hash_check, force_download = force_download)
        except:
            abc_cache.get_directory_metadata(directory = item, skip_hash_check = skip_hash_check, force_download = force_download)

    '''manifest_path is the path for data storing'''
    if abc_cache is None:  
        return False
    abc_cache.load_latest_manifest()
    with concurrent.futures.ThreadPoolExecutor(max_workers = max_workers) as executor:
        futs = [executor.submit(work_download_function, item = item) for item in abc_cache.list_directories]
        for _ in concurrent.futures.as_completed(futs):
            pass
    return True

# %%
def convert_pixel_continuous_coordinates_to_voxels_index(coordinate:typing.Union[np.ndarray, float], spacing:typing.Union[np.ndarray, float] = 10, physical_unit:float = 1) -> typing.Union[np.ndarray, float]:

    return np.floor((np.around(coordinate, 3) + (spacing / 2)) / spacing)

def convert_ccf_coordinates_to_voxels_index(coordinate:typing.Union[np.ndarray, float], spacing:typing.Literal[10, 25, 50, 100, 200] = 10) -> typing.Union[np.ndarray, np.float64]:
    '''
        For that convert every cell's ccf coordinate(x, y, z) to the indexs of voxels in the Allen CCFv3 10um's template. 
        For example, if spacing is 10um, the defualte extent for the coordinates of voxels in template is (-0.5 * spacing[0], (size[0]-0.5) * spacing[0], (size[1]-0.5) * spacing[1], -0.5 * spacing[1])
        size: (1320, 800, 1140) voxels
        spacing: (0.001, 0.001, 0.001) mm
    '''
    # spacing is the params of 10um, 25um, 50um, 100um, 200um
    # return np.floor((np.around(x, 3) + 0.005) /  ((spacing / 10) * 0.01))
    return convert_pixel_continuous_coordinates_to_voxels_index(coordinate, spacing * 0.001)

# %%
def get_abc_sp_h5ad_by_ccf_voxel_index(DatasetName:typing.Literal['Zhuang-ABCA-1', 'Zhuang-ABCA-2', 'Zhuang-ABCA-3', 'Zhuang-ABCA-4', 'MERFISH-C57BL6J-638850', 'MERFISH-C57BL6J-638850-imputed'], VoxelKind:typing.Literal['x', 'y', 'z', 'X', 'Y', 'Z'], VoxelSliceIndex:int, QueryGeneSymbols:list, GeneExprNumericType:typing.Literal['log2', 'raw']) -> anndata.AnnData:
    '''
        Different VoxelKind decide which direction will be selected and VoxelSliceIndex decide which Nth slices in this directrion to return. 
        i.e. VoxelKind is "x" and VoxelSliceIndex is 260, repsent that the 260th slice along the ML is selected.  
        The Common Coordinate Framework (CCF) is defined in a basic image coordinate system, using the top-left-rear pixel as its origin, and incrementing in the X, Y and Z axes up to the number of pixels in each dimension (ML, DV, AP respectively).  
    '''
    VoxelKind = str.lower(VoxelKind)
    voxel_index_name = VoxelKind+'_voxels_index'
    abc_cache = get_abc_cache()

    DatasetNameCCF = DatasetName + '-CCF' if DatasetName != 'MERFISH-C57BL6J-638850-imputed' else 'MERFISH-C57BL6J-638850' + '-CCF'
    ccf_coordinates = abc_cache.get_metadata_dataframe(DatasetNameCCF, file_name = 'ccf_coordinates')
    ccf_coordinates[voxel_index_name] = convert_ccf_coordinates_to_voxels_index(ccf_coordinates[VoxelKind])
    query_cell_labels = list(ccf_coordinates['cell_label'][ccf_coordinates[voxel_index_name] == VoxelSliceIndex])
    if len(query_cell_labels) == 0:
        raise RuntimeError(f"{DatasetName} does not have the cells on the {VoxelKind} direction of {VoxelSliceIndex}th slices!")
    # print(f"Number of query cell is {len(query_cell_labels)}")

    expression_h5data_filenames = [filename for filename in abc_cache.list_data_files(DatasetName) if filename.count(GeneExprNumericType)]
    if not expression_h5data_filenames:
        print(abc_cache.list_data_files(DatasetName)) 
        raise RuntimeError(f"{DatasetName} does not have the {GeneExprNumericType} type expression file!")

    expression_h5data = anndata.read_h5ad(abc_cache.get_data_path(directory = DatasetName, file_name = expression_h5data_filenames[0]), backed='r')
    contain_gene_symbol = [gs for gs in QueryGeneSymbols if np.isin(gs, expression_h5data.var['gene_symbol'])]

    if not contain_gene_symbol:
        raise RuntimeError(f"Your query gene symbols is not in the {DatasetName}!")
    
    not_contain_gene_symbol = [gs for gs in QueryGeneSymbols if not np.isin(gs, expression_h5data.var['gene_symbol'])]
    if not_contain_gene_symbol:
        print(f"There has {len(not_contain_gene_symbol)} gene symbol is not in the {DatasetName}:")
        print(not_contain_gene_symbol)

    # Always error in this code, so use another way to get result.
    # expression_query_anndatas = expression_h5data[query_cell_labels, list(expression_h5data.var.query('gene_symbol in @QueryGeneSymbols').index)].to_memory()

    expression_query_anndata_list = []
    for gs in contain_gene_symbol:
        # Only the index of gene symbol in h5ad data could be used for select.    
        gs_index = list(expression_h5data.var.loc[expression_h5data.var['gene_symbol'] == gs].index)[0]
        expression_query_anndata = expression_h5data[query_cell_labels, gs_index].to_memory()
        expression_query_anndata_list.append(expression_query_anndata)

    expression_h5data.file.close()
    expression_query_anndatas = anndata.concat(expression_query_anndata_list, axis = 1, join = 'inner', merge = 'same').to_memory()

    return expression_query_anndatas

# %%
def recon_allen_function(allen_sdk_function, query_times = 10, sleep_times = 2, *args, **kwargs):
    while query_times:
        try:
            res_info = allen_sdk_function(*args, **kwargs)
            return res_info
        except:
            query_times = query_times - 1
            time.sleep(sleep_times)
    if query_times == 0:
        print(f"the connection of from allen web site is broken, please check again")
    return ""
    
def recon_model_query(query_times = 10, sleep_times = 2, *args, **kwargs):
    RMA = RmaApi()
    return recon_allen_function(RMA.model_query, query_times = query_times, sleep_times = sleep_times, *args, **kwargs)

def recon_download_image(image_id, view, file_path, download_times = 10, check_size = 4096, query_times = 10, sleep_times = 2, *args, **kwargs) -> bool:
    view = None if view == "raw" else view
    imapi = ImageDownloadApi()
    abs_path, download_image = os.path.split(file_path)
    os.makedirs(abs_path, exist_ok = True)
    while (not os.path.exists(file_path) or os.path.getsize(file_path) < check_size) and download_times:
        recon_allen_function(imapi.download_image, query_times = query_times, sleep_times = sleep_times, image_id = image_id, view = view, file_path = file_path, *args, **kwargs)
        download_times = download_times - 1
    if not download_times:
        log_file_path = os.path.join(abs_path, 'download_image.log')
        local_time = time.localtime()
        formatted_date_time = time.strftime("%Y-%-m-%d %H:%M:%S", local_time)
        with open(log_file_path, 'a') as log_file:
            log_file.write(f"{formatted_date_time} - {download_image} is less {check_size} KB, check it\n")
            print("the download image seems to be failed, please check the image status and log!")
        return False
    else:
        print(f"{file_path} already download!")
    return True

def get_allen_sec_dataset_ids(criteria:str) -> pd.DataFrame:
    # SectionDataSet of Allen is a very big dataset contains differen subsets. i.e. conn data, ish data.  
    # how to use criteria to find the id you want, please see: 
    # https://allensdk.readthedocs.io/en/latest/data_api_client.html and
    # http://api.brain-map.org/api/v2/data/SectionDataSet/describe.xml
    return pd.DataFrame(recon_model_query(model = 'SectionDataSet', num_rows = 'all',  criteria=criteria, only=['id']))['id'].values

def get_allen_sec_dataset_gene_acronym_by_id(sec_id:int) -> str:
    # TODO. this simple script for accessing gene symbol. date: 2024.09.02, allen
    return recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria=f"[id$eq{sec_id}]", include='genes')[0]['genes'][0]['acronym']

def get_experiment_ids(plane:typing.Literal["sagittal","coronal","both"], product:typing.Literal[1,3], treatments:typing.Literal["ISH", "NISSL"]):
    if plane == "both":
        criteria = f"[failed$eq'false'],products[id$eq{product}],treatments[name$eq'{treatments}']"
    else:
        criteria = f"[failed$eq'false'],products[id$eq{product}],plane_of_section[name$eq'{plane}'],treatments[name$eq'{treatments}']" 
    return get_allen_sec_dataset_ids(criteria)

def get_allen_ish_ids(plane, product):
    # ISH data is part of SectionDataSet in Allen. 
    # product param value just in [1,3], 1 for adult mouse, 3 for develop mouse. 
    # plane param value coulde see: https://community.brain-map.org/t/api-for-mouse-brain-atlas/2766. 
    return get_experiment_ids(plane, product, "ISH")

def get_gene_expression_grid_data(sec_id:int, file_path:str = ISH_DATA_PATH, volume_type:typing.Literal['energy', 'density', 'intensity'] = 'energy') -> np.ndarray:
    final_file_path = f"{file_path}/{sec_id}.zip" if volume_type == 'energy' else f"{file_path}/{sec_id}_{volume_type}.zip" 
    if not os.path.exists(final_file_path):
        gaai = GridDataApi()
        '''Note: GridDataApi.download_gene_expression_grid_data function will download the zip file and auto extract the files of zip. In fact it use the retrieve_file_over_http(url, path, zipped=True) to get the zip file. Here change the zipped=True to zipped=False in source code to prevent the auto-extract, just get the zip file.'''
        gaai.download_gene_expression_grid_data(sec_id, volume_type, final_file_path) 
    return extract_zip_numpy(final_file_path, f"{volume_type}.raw", "float32")
    
def get_reference_space_tree(resolution:int, manifest_path:str = REF_MANIFEST_PATH) -> tuple:
    '''
        resolution is one int number in (10, 25, 50, 100, 200). If resolution < 200, then could use offical function api for getting reference space. If resolution equals 200um, this is for grid expression and no api support it, then we need download annotation file by manual and construct rfp and tree.
        reference_space_key is in fact the data path in allen web server. This is the url of data: https://download.alleninstitute.org/informatics-archive/current-release/mouse_ccf/annotation/
    '''
    if resolution == 200:
        annotation_200um_file_name = "P56_Mouse_gridAnnotation.zip"
        annotation_200um_file_path = f"{manifest_path}/{annotation_200um_file_name}"
        if not os.path.exists(annotation_200um_file_path):
                if not download_file(url = f"http://download.alleninstitute.org/informatics-archive/current-release/mouse_annotation/{annotation_200um_file_name}", filename = annotation_200um_file_path):
                    raise RuntimeError("Downloading 200um annotation file fails.")
        annotation_200um = extract_zip_numpy(zip_file_path = annotation_200um_file_path, fn = "gridAnnotation.raw", dtype = "int32")
        oapi = OntologiesApi()
        structure_graph = oapi.get_structures_with_sets(1) # ID 1 is the adult mouse structure graph
        structure_graph = StructureTree.clean_structures(structure_graph) 
        tree = StructureTree(structure_graph)
        rfp = ReferenceSpace(tree, annotation_200um, resolution)
        rfp.remove_unassigned()
        return rfp, tree
            
    reference_space_key = f'annotation/ccf_2017'
    rspc = ReferenceSpaceCache(resolution = resolution, reference_space_key = reference_space_key, manifest = pathlib.Path(manifest_path) / 'manifest.json')
    rspc.get_annotation_volume()
    return rspc.get_reference_space(), rspc.get_structure_tree(structure_graph_id = 1) # ID 1 is the adult mouse structure graph

# %%
def sagittal_half_mask(mask:np.ndarray, grid_shape:typing.Union[list, tuple, np.ndarray], sag_direction_index:typing.Literal[0, 1, 2], select_semi_brain:typing.Literal['l','r'], is_fallten:bool = True) -> np.ndarray:
    '''
        Params:
        sag_direction_index: for the 3d shape, which direction for the sagittal slice. i.e. if the index is 1, then we will select the first position and half it. See the source code for details.  
        select_semi_brain: for select left or right brian in sagittal direction. and 'r' for right, 'l' for left.  
    '''
    mask_copy = mask.copy().reshape(grid_shape)
    left_border = int(grid_shape[sag_direction_index] / 2) if select_semi_brain == 'r' else 0
    right_border = grid_shape[sag_direction_index] if select_semi_brain == 'r' else int(grid_shape[sag_direction_index] / 2) 
    if sag_direction_index == 0:
        mask_copy[left_border: right_border, :, :] = 0
    elif sag_direction_index == 1:
        mask_copy[:, left_border: right_border, :] = 0
    else:
        mask_copy[:, :, left_border: right_border] = 0
    if is_fallten:
        return mask_copy.flatten()
    return mask_copy

def grid_exp_normalization(grid:np.ndarray, miss_val:int = -1) -> np.ndarray:
    grid = grid.copy()
    gd = grid[np.where(grid != miss_val)]
    max_val = np.max(gd)
    min_val = np.min(gd)
    grid[np.where(grid != miss_val)] = (np.log2(gd + 1) - np.log2(min_val + 1)) / (np.log2(max_val + 1) - np.log2(min_val + 1))
    return grid

def download_projection_vol(exp_id:int, resolution:typing.Literal[10, 25, 50, 100, 200] = 10, cache_dir:str = CON_DATA_PATH, data_type:typing.Literal['projection_density', 'projection_energy', 'injection_fraction', 'injection_density', 'injection_energy', 'data_mask'] = "projection_energy", is_cache:bool = True, proj_file_name:str = "", data_mask:bool = True) -> typing.Union[str, tuple]:
    grid_api = GridDataApi()
    if not proj_file_name:
        proj_file_name = f"{cache_dir}/{exp_id}/{data_type}_{resolution}.nrrd"
    if not os.path.exists(proj_file_name) or os.path.getsize(proj_file_name) < 1024:
        is_cache = False
    if not is_cache:
        if not os.path.exists(cache_dir + "/" + f"{exp_id}"):
            os.makedirs(cache_dir + "/" + f"{exp_id}")
        if resolution == 200:
            proj_file_100um_name = f"{cache_dir}/{exp_id}/{data_type}_{100}.nrrd"
            if not os.path.exists(proj_file_100um_name):
                grid_api.download_projection_grid_data(exp_id, [data_type], 100, proj_file_100um_name)
            proj_vol = ski.transform.resize(nrrd.read(proj_file_100um_name)[0], (67,41,58), order = 0, preserve_range = True, anti_aliasing = False, cval = 0)
            nrrd.write(proj_file_name, proj_vol)
        else:
            grid_api.download_projection_grid_data(exp_id, [data_type], resolution, proj_file_name)

    if data_mask:
        data_mask_file_name = f"{cache_dir}/{exp_id}/data_mask_{resolution}.nrrd"
        if not os.path.exists(data_mask_file_name) or os.path.getsize(data_mask_file_name) < 1024:
            if resolution == 200:
                data_mask_100um_file_name = f"{cache_dir}/{exp_id}/data_mask_{100}.nrrd"
                if not os.path.exists(data_mask_100um_file_name):
                    grid_api.download_projection_grid_data(exp_id, ["data_mask"], 100, data_mask_100um_file_name)
                data_mask_vol = ski.transform.resize(nrrd.read(data_mask_100um_file_name)[0], (67,41,58), order = 0, preserve_range = True, anti_aliasing = False, cval = 0)
                nrrd.write(data_mask_file_name, data_mask_vol)
            else:
                grid_api.download_projection_grid_data(exp_id, ["data_mask"], resolution, data_mask_file_name)

        return proj_file_name, data_mask_file_name

    return proj_file_name

def download_all_proj_data(n_thread:int = 16, injection_structure_ids:typing.Optional[list] = None, cre:typing.Optional[list] = None, resolution:int = 10, cache_dir:str = CON_DATA_PATH, data_type:str = "projection_energy") -> list:
    mcc = MouseConnectivityCache(resolution = resolution, manifest_file = cache_dir + '/' + 'manifest.json')
    proj_ids = list(mcc.get_experiments(dataframe = True, cre = cre, injection_structure_ids = injection_structure_ids).id)
    download_paths = []

    with concurrent.futures.ThreadPoolExecutor(max_workers = n_thread) as excutor:
        futs = [excutor.submit(download_projection_vol, exp_id = exp_id, resolution = resolution, cache_dir = cache_dir, data_type = data_type) for exp_id in proj_ids]
        for fut in concurrent.futures.as_completed(futs):
            download_paths.append(fut.result()[data_type])

    return download_paths

def download_section_data_set_images(query_id:int, query_type:typing.Literal['altas','section_data_set'] = 'section_data_set',  file_path:str = IMG_DATA_PATH, view:typing.Literal["raw", "expression", "projection", "tumor_feature_annotation", "tumor_feature_boundary"] = "raw") -> list:
    '''
    Ref: https://community.brain-map.org/t/downloading-an-image/2865  
    img_info: RMA.model_query('SectionImage', num_rows = 'all', criteria = criteria, include = include)
    '''
    imapi = ImageDownloadApi()
    if query_type == 'altas':
        query_image_function = imapi.atlas_image_query
        store_path = f'{file_path}/altas/{query_id}'
        '''allensdk.api.queries.ontologies_api.OntologiesApi.get_atlases` can also be used to list atlases along with their ids.'''
    else:
        query_image_function = imapi.section_image_query
        store_path = f"{file_path}/{query_id}/{view}"

    img_ids = [it['id'] for it in query_image_function(query_id)]

    if not os.path.exists(store_path):
        os.makedirs(store_path)

    img_downloaded_list = []
    for image_id in img_ids:
        img_download_path = f"{store_path}/{image_id}.jpg"
        if recon_download_image(image_id = image_id, view = view, file_path = img_download_path):
            img_downloaded_list.append(img_download_path)

    return img_downloaded_list

def parallel_download_section_image(all_sec_ids, file_path:str = IMG_DATA_PATH, n_process:int = 8, view = 'raw'):
    with concurrent.futures.ThreadPoolExecutor(max_workers = n_process) as excutor:
        futs = [excutor.submit(download_section_data_set_images, query_id = sec_id, view = view, file_path = file_path) for sec_id in all_sec_ids]
        for _ in concurrent.futures.as_completed(futs):
            pass

def count_num_imgs_of_all_ish(is_cache:bool = True, plane:str = 'coronal', file_path = IMG_DATA_PATH) -> list:
    import pickle
    dict_path = f"{IMG_DATA_PATH}/count_sec_img_nums_{plane}.dict"
    if not os.path.exists(dict_path):
        is_cache = False

    if is_cache:
        with open(dict_path, "rb") as f:
            res_sec_dict = pickle.load(f)
        return res_sec_dict

    res_sec_dict = {}
    sec_ids =  get_allen_ish_ids(plane, '1')
    for sec_id in sec_ids:
        section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "section_images[failed$eq'False']")[0]
        res_sec_dict[sec_id] = len(section_data_meta['section_images'])

    with open(dict_path, "wb") as f:
        pickle.dump(res_sec_dict, f)       
    return res_sec_dict

def get_paired_nissl_images(sec_id:int = 74881161, sec_id_folder_path:str = IMG_DATA_PATH) -> dict:
    RMA = RmaApi()
    imapi = ImageDownloadApi()

    section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "section_images")[0]
    nissl_data_set_id = RMA.model_query('SectionImage', criteria = f"[id$eq{section_data_meta['section_images'][0]['id']}]", include = "associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]['data_set']['id']
    
    folder_path = f"{sec_id_folder_path}/{nissl_data_set_id}/raw"
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    
    img_meta = pd.DataFrame(section_data_meta['section_images'])
    img_ids = [row[1] for row in img_meta.sort_values(by = 'section_number')[['id','section_number']].itertuples()]
    nissl_ids = [RMA.model_query('SectionImage', criteria = f"[id$eq{img_id}]", include = "associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]['id'] for img_id in img_ids]
    
    img_downloaded_dict = dict()
    img_downloaded_dict['nissl_data_set_id'] = nissl_data_set_id
    
    for nissl_id in nissl_ids:
        img_download_path = f"{folder_path}/{nissl_id}.jpg"
        download_time = 20
        while download_time and (not os.path.exists(img_download_path) or os.path.getsize(img_download_path) < 1024):
            try:
                imapi.download_image(nissl_id, file_path = img_download_path)
            except:
                print('Download Code May Contain Wrong Parameters, Please Check')
            download_time = download_time - 1
            time.sleep(2)
        if download_time:
            img_downloaded_dict[img_ids[nissl_ids.index(nissl_id)]] = img_download_path
            
    return img_downloaded_dict

# %%
def test_count_nissl_coronal_plane_ids(plane = 'coronal', file_path = IMG_DATA_PATH):
    import pickle
    import time
    
    RMA = RmaApi()
    comids = list(get_experiment_ids(plane, 1, 'ISH'))
    
    if not os.path.exists(file_path):
        os.makedirs(file_path)
    if os.path.exists(f"{file_path}/{plane}_paired_ish_nissl_id.tuple"):
        with open(f"{file_path}/{plane}_paired_ish_nissl_id.tuple", "rb") as f:
            res_ids = pickle.load(f)
        return res_ids
    
    nissl_res_ids = []
    fail_ids = []
    print(f"The nums of samples is {len(comids)}")
    for sec_id in comids:
        print(f"Now {comids.index(sec_id)}th sample")
        retry_times = 10
        is_success = False
        while not is_success:
            print(f"Process {sec_id}")
            try:
                section_data_meta = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_id}]", include = "section_images")[0]
                is_success = True
            except:
                time.sleep(2)
        while is_success and retry_times:   
            try:
                nissl_data_set_id = RMA.model_query('SectionImage', criteria = f"[id$eq{section_data_meta['section_images'][0]['id']}]", include = "associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]['data_set']['id']
                nissl_res_ids.append(nissl_data_set_id)
                is_success = False
            except:
                retry_times = retry_times - 1
                time.sleep(2)
        if retry_times:
            fail_ids.append(sec_id)
            
    with open(f"{file_path}/{plane}_paired_ish_nissl_id.tuple", "wb") as f:
        pickle.dump((nissl_res_ids, fail_ids), f)
        
    return nissl_res_ids, fail_ids


# %%
def download_human_altas_images_and_mri_demo():

    ot = OntologiesApi()
    ot.get_atlases()
    # there has three human altas id 265297126, 265297125, 138322605, select 138322605
    altas_id = 138322605
    img_api = ImageDownloadApi()

    # the first way to download altas images
    download_section_data_set_images(altas_id, 'altas')

    # the second way to download altas images
    data_set_id = img_api.atlas_image_query(altas_id)[0]['data_set_id']
    specimen_id = RMA.model_query('SectionDataSet', num_rows = 'all', criteria = f'[id$eq{data_set_id}]')[0]['specimen_id']
    donor_id = RMA.model_query('Specimen', num_rows = 'all', criteria = f'[id$eq{specimen_id}]', include = "donor")[0]['donor']['id']

    # there has two section_data_set for altas's specimen_id
    sec_ids = [res['id'] for res in RMA.model_query('SectionDataSet', num_rows = 'all', include = f"specimen[donor_id$eq{donor_id}]")] 
    for sec_id in sec_ids:
        download_section_data_set_images(sec_id)
    
    # donwload this specimen mri data
    # mri data is well known file. ref: https://community.brain-map.org/t/human-brain-atlas-api/2876
    # download well known file ref: https://community.brain-map.org/t/downloading-a-wellknownfile/2881
    allen_downlaod_prefix = "http://api.brain-map.org"
    well_known_file_list = RMA.model_query('Donor', num_rows = 'all', criteria = f'[id$eq{donor_id}]', include = "specimens(well_known_files(well_known_file_type[name$in'T1-MRI','T2-MRI','DTI-MRI']))")[0]['specimens'][0]['well_known_files']
    for well_known_file in well_known_file_list:
        img_api.retrieve_file_over_http(f"{allen_downlaod_prefix}/{well_known_file['download_link']}", file_path = f"{MRI_DATA_PATH}/{well_known_file['id']}.tgz")


# %%
if __name__ == "__main__":
    # download_proj_data()
    # test_alignment_demo()
    # download_all_ish_primary_image(file_path = '/home/t207/Lab_Data_preproc2/allen_data/img_data', view = 'raw')
    # download_all_ish_primary_image(file_path = '/home/t207/Lab_Data_preproc2/allen_data/img_data', view = 'expression')
    # sitk.WriteImage(test_second_alignment2d_section_image_to_3dreference(74658173), 'new_74658173_rf.nrrd')
    # all_sec_ids = test_count_nissl_coronal_plane_ids('sagittal')
    pass


