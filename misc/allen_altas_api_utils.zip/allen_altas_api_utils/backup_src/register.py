import ants
import numpy as np
import typing
import os
import matplotlib.pyplot as plt

import process_img as prg
import utils
import SimpleITK as sitk

def slice_registration_function(ss_vol, ref_vol, ss_ex_vols = [], ref_ex_vols = [], vol_spacing = [25, 25, 25], global_register_type = "Rigid", slice_register_type = "SyN", axis_index = 0, tmp_nii_dir = f"{utils.ANTS_REG_TMP}", is_return_tdict = False):

    os.makedirs(tmp_nii_dir, exist_ok = True)
    fix_ss_slice_list = [] # ss fix
    mov_ref_slice_slist = [] # rf mov
    slice_register_transform_dict = {}
    
    if ref_ex_vols:
        for ref_ex_vol in ref_ex_vols:
            for dx, ix in zip(ref_vol.shape, ref_ex_vol.shape):
                if dx != ix:
                    raise('the shape of label vol must equal to the shape of ref vol!')

    ss_ex_npys = [[] for _ in ss_ex_vols] # init empty list
    ref_ex_npys = [[] for _ in ref_ex_vols]
    
    res = ants.registration(ss_vol, ref_vol, global_register_type, outprefix=f"{tmp_nii_dir}/rigid")
    
    if ref_ex_vols:
        ref_ex_vols = [ants.apply_transforms(ss_vol, ref_ex_vol, res['fwdtransforms'], 'nearestNeighbor') for  ref_ex_vol in ref_ex_vols]
    
    for slice_index in range(res['warpedmovout'].shape[axis_index]):
        ff = ants.slice_image(ss_vol, axis = axis_index, idx = slice_index)
        mm = ants.slice_image(res['warpedmovout'], axis = axis_index, idx  = slice_index)
        ex_ffs = [ants.slice_image(ss_ex_vol, axis = axis_index, idx = slice_index) for ss_ex_vol in ss_ex_vols] if ss_ex_vols else []
        ex_mms = [ants.slice_image(ref_ex_vol, axis = axis_index, idx = slice_index) for ref_ex_vol in ref_ex_vols] if ref_ex_vols else []
        tmp = None
        
        if np.max(ff.numpy()) <= 0 or np.max(mm.numpy()) <= 0:
            fix_ss_slice_list.append(ff.numpy())
            mov_ref_slice_slist.append(mm.numpy())
            slice_register_transform_dict[slice_index] = None
        else:
            tmp = ants.registration(ff, mm, slice_register_type, outprefix = f'{tmp_nii_dir}/{slice_index}')
            fix_ss_slice_list.append(tmp['warpedfixout'].numpy())
            mov_ref_slice_slist.append(tmp['warpedmovout'].numpy())
            slice_register_transform_dict[slice_index] = {'invtransforms':tmp['invtransforms'], 'fwdtransforms':tmp['fwdtransforms']}

        for idx in range(len(ex_ffs)):
            if np.max(ex_ffs[idx].numpy()) > 0 and tmp:
                ss_ex_npys[idx].append(ants.apply_transforms(mm, ex_ffs[idx], tmp['invtransforms'], 'nearestNeighbor').numpy())
            else:
                ss_ex_npys[idx].append(ex_ffs[idx].numpy())

        for idx in range(len(ex_mms)):
            if np.max(ex_ffs[idx].numpy()) > 0 and tmp:
                ref_ex_npys[idx].append(ants.apply_transforms(ff, ex_mms[idx], tmp['fwdtransforms'], 'nearestNeighbor').numpy())           
            else:
                ref_ex_npys[idx].append(ex_mms[idx].numpy())           
      
    pre_sec_fix_ss_stack_vol = ants.from_numpy(np.array(fix_ss_slice_list), spacing = vol_spacing)
    pre_sec_mov_ref_stack_vol = ants.from_numpy(np.array(mov_ref_slice_slist), spacing = vol_spacing)
    
    pre_sec_fix_ex_stack_vols = [ants.from_numpy(np.array(ss_ex_npy), spacing = vol_spacing) for ss_ex_npy in ss_ex_npys] if ss_ex_npys else []
    pre_sec_mov_ex_stack_vols = [ants.from_numpy(np.array(ref_ex_npy), spacing = vol_spacing) for ref_ex_npy in ref_ex_npys] if ref_ex_npys else []
    
    if not is_return_tdict:
        utils.clear_folder(tmp_nii_dir)

    return pre_sec_fix_ss_stack_vol, pre_sec_mov_ref_stack_vol, pre_sec_fix_ex_stack_vols, pre_sec_mov_ex_stack_vols, slice_register_transform_dict

def get_slice_registration_vol(donor_id:int, file_path = f"{utils.STORE_REG_VOL_PATH}", global_register_type:typing.Literal["SyN", "Rigid"] = "SyN", slice_register_type:typing.Literal["SyN", "Rigid"] = "Rigid", is_force = False):
    
    os.makedirs(f"{file_path}/{donor_id}", exist_ok = True)
    first_name = "S" if global_register_type == "SyN" else "R"
    second_name = "S" if slice_register_type == "SyN" else "R"
    
    ssrf_vol =  f"{file_path}/{donor_id}/{donor_id}_ssrf_vol.nii.gz"
    rg_vol_path = f"{file_path}/{donor_id}/{donor_id}_sli_rgs_{first_name}{second_name}.nii.gz"
    rg_ref_path = f"{file_path}/{donor_id}/{donor_id}_sli_rgrf_{first_name}{second_name}.nii.gz"
    
    ss_vol = prg.get_accord_ref_donor_vol(donor_id, ref_type = "")
    
    if not os.path.exists(ssrf_vol):
        ants.image_write(ss_vol, ssrf_vol)
        
    if is_force or not os.path.exists(rg_ref_path) or not os.path.exists(rg_vol_path):
        ref_vol = ants.image_read(utils.get_reference_space())
        res = slice_registration_function(ss_vol, ref_vol, global_register_type = global_register_type, slice_register_type = slice_register_type)
        ants.image_write(res[0], rg_vol_path)
        ants.image_write(res[1], rg_ref_path)
    
    return rg_vol_path, rg_ref_path

def get_double_registration_vol(donor_id, sec_id = None, vol_type:typing.Literal["raw", "dl"] = "raw", vol_ref_type = "stpt", sli_ref_type = "nissl", file_path = utils.STORE_DONOR_VOL_PATH, is_force = False, exp_vol_path = utils.STORE_EXP_VOL_PATH, net_name = "", tmp_nii_dir = f"{utils.ANTS_REG_TMP}", **net_params):
    
    print(donor_id)
    if sec_id and not exp_vol_path:
        raise("please check exp vol parameters")
    
    os.makedirs(f"{file_path}/{donor_id}", exist_ok = True)    
    os.makedirs(tmp_nii_dir, exist_ok = True)
    
    if vol_type == "raw" and net_name:
        raise("some error")

    net_name_face = f"{net_name}_" if net_name else ""
    
    pre_sec_fix_stack_path = f"{file_path}/{donor_id}/{net_name_face}{vol_type}_sli_{sli_ref_type}_fix_stack.nii.gz"
    pre_sec_mov_stack_path = f"{file_path}/{donor_id}/{net_name_face}{vol_type}_sli_{sli_ref_type}_mov_stack.nii.gz"
    sec_fix_vol_path = f'{file_path}/{donor_id}/{net_name_face}{vol_type}_{sli_ref_type}_{vol_ref_type}_fix.nii.gz'
    sec_mov_vol_path = f'{file_path}/{donor_id}/{net_name_face}{vol_type}_{sli_ref_type}_{vol_ref_type}_mov.nii.gz'
    sec_mov_label_path = f'{file_path}/{donor_id}/{net_name_face}{vol_type}_{sli_ref_type}_{vol_ref_type}_mov_label.nii.gz'
    sec_mov_boundary_path = f'{file_path}/{donor_id}/{net_name_face}{vol_type}_{sli_ref_type}_{vol_ref_type}_mov_boundary.nii.gz'
    
    pre_sec_fix_exp_path = f"{exp_vol_path}/{sec_id}/{net_name_face}{vol_type}_sli_{sli_ref_type}_fix_exp.nii.gz" if sec_id else ""
    sec_fix_exp_path = f"{exp_vol_path}/{sec_id}/{net_name_face}{vol_type}_{sli_ref_type}_{vol_ref_type}_fix_exp.nii.gz" if sec_id else ""
    
    sli_ref_nii = ants.image_read(utils.get_reference_space(sli_ref_type))
    vol_ref_nii = ants.image_read(utils.get_reference_space(vol_ref_type))

    if is_force or (not os.path.exists(pre_sec_fix_stack_path) or not os.path.exists(pre_sec_mov_stack_path)) or (sec_id and not os.path.exists(pre_sec_fix_exp_path)):
        if vol_type == "raw":
            ss_vol = ants.image_read(prg.get_donor_brain_vol(donor_id)[0])
        else:
            ss_vol = ants.image_read(prg.get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id, net_name = net_name, **net_params)[0])
            
        # To make the coronal direction accord with ref vol.
        ss_numpy = ss_vol.numpy()
        ss_numpy = np.mean(ss_numpy, axis = 3).transpose(2, 1, 0)
        ss_numpy = np.flip(ss_numpy, axis = 0)
        ss_vol = ants.from_numpy(ss_numpy, spacing=[25, 25, 25])
        if sec_id:
            exp_vol = ants.image_read(prg.get_ish_stack_expression_vol(sec_id)[0])
            exp_numpy = exp_vol.numpy().transpose(2, 1, 0)
            exp_numpy = np.flip(exp_numpy, axis = 0)
            exp_vol = ants.from_numpy(exp_numpy, spacing=[25, 25, 25])
        else:
            exp_vol = None
            
        slice_vols = slice_registration_function(ss_vol, sli_ref_nii, ss_ex_vols = [exp_vol], tmp_nii_dir = f"{tmp_nii_dir}/")
        ants.image_write(slice_vols[0], pre_sec_fix_stack_path)
        ants.image_write(slice_vols[1], pre_sec_mov_stack_path)
        if pre_sec_fix_exp_path:
            ants.image_write(slice_vols[2][0], pre_sec_fix_exp_path)
    
    if is_force or (not os.path.exists(sec_fix_vol_path) or not os.path.exists(sec_mov_vol_path) or not os.path.exists(sec_mov_label_path)) or not os.path.exists(sec_mov_boundary_path) or (sec_id and not os.path.exists(sec_fix_exp_path)):
        sec_res = ants.registration(ants.image_read(pre_sec_fix_stack_path), vol_ref_nii, "SyN", outprefix = f"{tmp_nii_dir}/")
        ants.image_write(sec_res['warpedfixout'], sec_fix_vol_path)
        ants.image_write(sec_res['warpedmovout'], sec_mov_vol_path)
        label_vol = ants.image_read(utils.get_label_space())
        boundary_vol = ants.image_read(utils.get_boundary_space())
        ants.image_write(ants.apply_transforms(ants.image_read(pre_sec_fix_stack_path), label_vol, sec_res['fwdtransforms'], 'nearestNeighbor'),  sec_mov_label_path)
        ants.image_write(ants.apply_transforms(ants.image_read(pre_sec_fix_stack_path), boundary_vol, sec_res['fwdtransforms'], 'nearestNeighbor'),  sec_mov_boundary_path)
        if sec_fix_exp_path:
            ants.image_write(ants.apply_transforms(vol_ref_nii, ants.image_read(pre_sec_fix_exp_path), sec_res['invtransforms'], 'nearestNeighbor'),  sec_fix_exp_path)
    
    if sec_id:
        return pre_sec_fix_stack_path, pre_sec_mov_stack_path, sec_fix_vol_path, sec_mov_vol_path, pre_sec_fix_exp_path, sec_fix_exp_path
    
    return pre_sec_fix_stack_path, pre_sec_mov_stack_path, sec_fix_vol_path, sec_mov_vol_path, sec_mov_boundary_path

def get_registration_boundary_vol(donor_id:int = 7430, ref_type = 'nissl', file_path = '/home/t207/Lab_Data_preproc2/allen_data/reg_vol', is_slice_reg = False, is_force = False, net_name = '', **net_params):
    
    def inner_registration_function(is_slice_reg, rg_vol, ref_vol, boundary_vol, ss_vol_path, ants_ss_tbv_path):
        if is_slice_reg:
            sli_res = slice_registration_function(rg_vol, ref_vol, is_return_tdict = True)
            rg_vol, ss_ts_dict = sli_res[0], sli_res[4]
            
        ants.image_write(rg_vol, ss_vol_path)
        
        ants_ss_res = ants.registration(rg_vol, ref_vol, outprefix=f'{utils.ANTS_REG_TMP}/{donor_id}_')
        ants_ss_tbv = ants.apply_transforms(rg_vol, boundary_vol, ants_ss_res['fwdtransforms'], 'nearestNeighbor')
        
        if is_slice_reg:
            # ants_ss_tbv = ants.apply_transforms(rg_vol, ants_ss_tbv, ss_ts_dict[-1]['fwdtransforms'], 'nearestNeighbor')
            # del ss_ts_dict[-1]
            ants_ss_tbv_list = []
            for slice_index, trfs in ss_ts_dict.items():
                if trfs:
                    boundary_mm = ants.apply_transforms(rg_vol[slice_index, :, :], ants_ss_tbv[slice_index, :, :], trfs['fwdtransforms'], 'nearestNeighbor').numpy()
                else:
                    print(ants_ss_tbv[slice_index, :, :])
                    # ants_ss_tbv_list.append(ants_ss_tbv[slice_index, :, :].numpy())
                    boundary_mm = ants.slice_image(ants_ss_tbv, axis = 0, idx = slice_index).numpy()
                ants_ss_tbv_list.append(boundary_mm)                
            ants_ss_tbv = ants.from_numpy(np.array(ants_ss_tbv_list), spacing=[25, 25, 25])
        
        ants.image_write(ants_ss_tbv, ants_ss_tbv_path)
        utils.clear_folder(utils.ANTS_REG_TMP)
    
    file_path = f"{file_path}/{donor_id}"
    os.makedirs(file_path, exist_ok = True)
    
    slice_reg_prefix = "sli_rg_" if is_slice_reg else ""
    
    ssmr_vol_path = f"{file_path}/{slice_reg_prefix}ssmr.nii.gz"
    dlmr_vol_path = f"{file_path}/{slice_reg_prefix}{net_name}_dlmr.nii.gz"
    allen_ss_tbv_path = f"{file_path}/allen_ssmr_tbv.nii.gz"
    ants_ss_tbv_path = f"{file_path}/{slice_reg_prefix}ants_ssmr_{ref_type}_tbv.nii.gz"
    ants_dm_tbv_path = f"{file_path}/{slice_reg_prefix}ants_{net_name}_dlmr_{ref_type}_tbv.nii.gz"
    
    donor_vol = ants.image_read(prg.get_donor_brain_vol(donor_id)[0])
    ref_vol = ants.image_read(utils.get_reference_space(ref_type))
    boundary_vol = ants.image_read(utils.get_boundary_space())
    
    ss_numpy = donor_vol.numpy()
    ss_numpy = np.mean(ss_numpy, axis = 3)
    donor_mean_vol = ants.from_numpy(ss_numpy, spacing=[25, 25, 25])
    ss_numpy = np.flip(ss_numpy.transpose(2, 1, 0), axis = 0)
    ss_vol = ants.from_numpy(ss_numpy, spacing=[25, 25, 25])
    
    if (is_force or not os.path.exists(ants_dm_tbv_path) or not os.path.exists(dlmr_vol_path)) and net_name:
        dl_vol = ants.image_read(prg.get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id = donor_id, net_name = net_name, **net_params)[0])
        dm_vol = prg.get_accord_ref_donor_vol(donor_id = 0, ref_type = "", vol = dl_vol)
        inner_registration_function(is_slice_reg, dm_vol, ref_vol, boundary_vol, dlmr_vol_path, ants_dm_tbv_path)
    
    if is_force or not os.path.exists(ants_ss_tbv_path):
        inner_registration_function(is_slice_reg, ss_vol, ref_vol, boundary_vol, ssmr_vol_path, ants_ss_tbv_path)
        
    if is_force or not os.path.exists(allen_ss_tbv_path):
        alignment_3d = prg.get_donors_info_by_exp_info()[donor_id]['alignment3d']
        trv_alignment3d = prg.test_build_alignment_3d(alignment_3d, 'tvr')
        ants_trv = ants.new_ants_transform(parameters = trv_alignment3d)
        allen_ss_tbv = ants_trv.apply_to_image(boundary_vol, donor_mean_vol, 'nearestneighbor')
        allen_ss_tbv_numpy = allen_ss_tbv.numpy().transpose(2, 1, 0)
        allen_ss_tbv_numpy = np.flip(allen_ss_tbv_numpy, axis = 0)
        allen_ss_tbv = ants.from_numpy(allen_ss_tbv_numpy, spacing=[25, 25, 25])
        ants.image_write(allen_ss_tbv, allen_ss_tbv_path)

    return ssmr_vol_path, dlmr_vol_path, allen_ss_tbv_path, ants_ss_tbv_path, ants_dm_tbv_path

def get_allen_boundary_vol_on_donor(donor_id:int, is_force = False, file_path = utils.STORE_REG_VOL_PATH, spacing = 25):    
    
    allen_ss_tbv_path = f"{file_path}/{donor_id}/allen_ssmr_tbv.nii.gz"
    os.makedirs(f"{file_path}/{donor_id}", exist_ok = True)
    
    if is_force or not os.path.exists(allen_ss_tbv_path):
        boundary_vol = ants.image_read(utils.get_boundary_space(spacing))
        donor_vol = ants.image_read(prg.get_donor_brain_vol(donor_id)[0])
        dm_vol = ants.average_images(ants.split_channels(donor_vol), False, None, 0, 0)
        alignment_3d = prg.get_donors_info_by_exp_info()[donor_id]['alignment3d']
        trv_alignment3d = prg.test_build_alignment_3d(alignment_3d, 'tvr')
        ants_trv = ants.new_ants_transform(parameters = trv_alignment3d)
        allen_ss_tbv = ants_trv.apply_to_image(boundary_vol, dm_vol, 'nearestneighbor')
        allen_ss_tbv_numpy = allen_ss_tbv.numpy().transpose(2, 1, 0)
        allen_ss_tbv_numpy = np.flip(allen_ss_tbv_numpy, axis = 0)
        allen_ss_tbv = ants.from_numpy(allen_ss_tbv_numpy, spacing=[25, 25, 25])
        ants.image_write(allen_ss_tbv, allen_ss_tbv_path)
    
    return allen_ss_tbv_path

def get_reclamation_slice_vol(vol:ants.core.ants_image.ANTsImage, type_of_transform:str = "Rigid"):
    
    '''
        Note that the axis of plane which use for registration is zero. 
    '''
    axis_index = 0
    
    mid_plane_idx = int(vol.shape[axis_index] / 2)
    rec_idx = -1
    fix_idx = mid_plane_idx
    mov_idx = mid_plane_idx - 1
    while mov_idx:
        fix = ants.slice_image(vol, axis = axis_index, idx = fix_idx)
        mov = ants.slice_image(vol, axis = axis_index, idx = mov_idx)
        if np.max(fix.numpy()) > 0 and np.max(mov.numpy()) > 0:
            res = ants.registration(fix, mov, type_of_transform = type_of_transform, outprefix=f'{utils.ANTS_REG_TMP}/', aff_metric="meansquares")
            vol[mov_idx, :, :] = res['warpedmovout']
            rec_idx = fix_idx
            fix_idx = mov_idx
            mov_idx = mov_idx - 1
             
        if np.max(fix.numpy()) <= 0:
            if rec_idx:
                fix = rec_idx
            elif np.max(mov.numpy()) > 0:
                fix_idx = mov_idx
            else:
                fix_idx = fix_idx - 1
        
        if np.max(mov.numpy()) <= 0:
             mov_idx = mov_idx - 1
    
    fix_idx = mid_plane_idx
    mov_idx = mid_plane_idx + 1
    rec_idx = -1
    while mov_idx < vol.shape[axis_index] - 1:
        
        fix = ants.slice_image(vol, axis = axis_index, idx = fix_idx)
        mov = ants.slice_image(vol, axis = axis_index, idx = mov_idx)
        
        if np.max(fix.numpy()) > 0 and np.max(mov.numpy()) > 0:
            res = ants.registration(fix, mov, type_of_transform = type_of_transform, outprefix=f'{utils.ANTS_REG_TMP}/', aff_metric="meansquares")
            vol[mov_idx, :, :] = res['warpedmovout']
            rec_idx = fix_idx
            fix_idx = mov_idx
            mov_idx = mov_idx + 1
                         
        if np.max(fix.numpy()) <= 0:
            if rec_idx:
                fix = rec_idx
            elif np.max(mov.numpy()) > 0:
                fix_idx = mov_idx
            else:
                fix_idx = fix_idx + 1
        
        if np.max(mov.numpy()) <= 0:
             mov_idx = mov_idx + 1
        
    return vol

# def get_donor_transform_parameters(donor_id:int, file_path:str = utils.STORE_REG_VOL_PATH, transform_type:typing.Literal["SyN", "Affine", "SyNRA"] = "SyN", is_force:bool = False, **ants_parameters):

#     parameters_prefix = f"{file_path}/{donor_id}/transform/"
#     os.makedirs(parameters_prefix, exist_ok = True)
#     warp_file = f"{parameters_prefix}1Warp.nii.gz"
#     affine_file = f"{parameters_prefix}0GenericAffine.mat"

#     if transform_type == "SyN":
#         transform_list = [affine_file, warp_file]
#     else:
#         transform_list = [affine_file]

#     if is_force or not os.path.exists(warp_file) or not os.path.exists(affine_file):
#         ss_vol = prg.get_accord_ref_donor_vol(6219, "")
#         ref = ants.image_read(utils.get_reference_space())

#         ants.registration(ss_vol, ref, transform_type, outprefix = parameters_prefix, **ants_parameters)

#     return transform_list

def get_donor_transform_parameters(donor_id:int, file_path:str = utils.STORE_REG_VOL_PATH, transform_type:typing.Literal["SyN", "Affine"] = "SyN", is_force:bool = False, net_name:str = "", **net_parameters):

    parameters_prefix = f"{file_path}/{donor_id}/transform/"
    os.makedirs(parameters_prefix, exist_ok = True)
    parameters_prefix = f"{parameters_prefix}{net_name}"
    warp_file = f"{parameters_prefix}1Warp.nii.gz"
    affine_file = f"{parameters_prefix}0GenericAffine.mat"

    if transform_type == "SyN":
        transform_list = [affine_file, warp_file]
    else:
        transform_list = [affine_file]

    if is_force or not os.path.exists(warp_file) or not os.path.exists(affine_file):
        if net_name:
            dl_vol = ants.image_read(prg.get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id, net_name, **net_parameters)[0])
            ss_vol = prg.get_accord_ref_donor_vol(0, "", dl_vol)
        else:
            ss_vol = prg.get_accord_ref_donor_vol(donor_id, "")
        ref = ants.image_read(utils.get_reference_space())
        ants.registration(ss_vol, ref, transform_type, outprefix = parameters_prefix)

    return transform_list

def get_reference_transform_exp_vol(sec_id:int, file_path:str = utils.STORE_EXP_VOL_PATH, is_force:bool = False, is_grid = False, net_name:str = "",**net_parameters):

    file_prefix = f"{file_path}/{sec_id}"
    os.makedirs(file_prefix, exist_ok = True)
    file_prefix = f"{file_prefix}/tvr_grid_ants" if is_grid else f"tvr_ants"  
    file_path = f"{file_prefix}_{net_name}.nii.gz" if net_name else f"{file_prefix}.nii.gz"

    if is_force or not os.path.exists(file_path):
        donor_id = utils.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include=f'specimen')[0]['specimen']['donor_id']
        exp_vol = ants.image_read(prg.get_ish_stack_expression_vol(sec_id, is_grid = is_grid)[0])
        acr_exp_vol = prg.get_accord_ref_donor_vol(0, "", exp_vol)
        ref_vol = ants.image_read(utils.get_reference_space())
        tvr_exp_vol = ants.apply_transforms(ref_vol, acr_exp_vol, get_donor_transform_parameters(donor_id, net_name = net_name, **net_parameters), interpolator = "nearestNeighbor")
        ants.image_write(tvr_exp_vol, file_path)
    
    return file_path
    
def t0():
    res = {}
    label_vol = ants.image_read(utils.get_label_space())
    ref_vol = ants.image_read(utils.get_reference_space())
    for donor_id in prg.DEMO_DONOR_IDS:
        dl_vol = ants.image_read(prg.get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id, f'{donor_id}_cng_k64_r9b', convert_grey = True, input_nc = 1, output_nc = 1, ngf = 64, pth_file = "/home/t207/wd_disk/server/allen_project/notebook/cgan/checkpoints/{donor_id}_cng_k64_r9b/latest_net_G_A.pth", netG = 'resnet_9blocks', is_force = False, convert_whole_brain = True)[0])
        dl_vol = prg.get_accord_ref_donor_vol(donor_id = 0, vol = dl_vol, ref_type = "")
        ss_vol = prg.get_accord_ref_donor_vol(donor_id = donor_id, ref_type = "")
        res1 = slice_registration_function(ss_vol = dl_vol, ref_vol = ref_vol, exp_vol = ss_vol, boundary_vol = label_vol, global_register_type = 'SyN', slice_register_type = "SyN", tmp_nii_dir = f"{utils.STORE_DONOR_VOL_PATH}/tmp")
        ants.image_write(res1[0], f'{donor_id}_SS.nii.gz')
        res2 = slice_registration_function(ss_vol = dl_vol, ref_vol = ref_vol, exp_vol = ss_vol, boundary_vol = label_vol, global_register_type = 'SyN', slice_register_type = "Rigid", tmp_nii_dir = f"{utils.STORE_DONOR_VOL_PATH}/tmp")
        ants.image_write(res2[0], f'{donor_id}_SR.nii.gz')
        res3 = slice_registration_function(ss_vol = dl_vol, ref_vol = ref_vol, exp_vol = ss_vol, boundary_vol = label_vol, global_register_type = 'Rigid', slice_register_type = "SyN", tmp_nii_dir = f"{utils.STORE_DONOR_VOL_PATH}/tmp")
        ants.image_write(res3[0], f'{donor_id}_RS.nii.gz')
        res[donor_id] = [res1, res2, res3]

    get_registration_boundary_vol(donor_id = 6219, net_name = '6219_cng_k64_r9b', convert_grey = True, input_nc = 1, output_nc = 1, ngf = 64, pth_file = "/home/t207/wd_disk/server/allen_project/notebook/cgan/checkpoints/6219_cng_k64_r9b/latest_net_G_A.pth", netG = 'resnet_9blocks', is_force = False, convert_whole_brain = True, is_slice_reg = True)
    
def t2():
    donors_ish_associate_nissl_info_dict = prg.get_sepcific_donor_ids_ish_associate_nissl_info()
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= 10]
    print('has ', len(donor_ids), 'to make')
    for donor_id in donor_ids:
        print(f'{donor_ids.index(donor_id)}th: make {donor_id}')
        res = get_slice_registration_vol(donor_id, global_register_type = "SyN", slice_register_type = "SyN",)
        ss_vol = ants.image_read(res[0])
        # rf_vol = ants.image_read(res[1])
        rf_vol = ants.iMath_normalize(ants.image_read(res[1])) * 255
        prg.basic_ants_make_dataset(ss_vol.astype('uint8'), rf_vol.astype('uint8'), '/home/t207/Lab_Data_preproc2/allen_data/dl_datasets/ish/r101_srg_nissl', A_image_prefix = f"{donor_id}_SS_", B_image_prefix = f"{donor_id}_SS_", slice_range = (5, 474))

def t3():
    sec_dict = prg.get_associate_genes_by_donor_id(6219)
    for genes, sec_id in sec_dict.items():
        prg.get_grid_ish_expression_vol(sec_id, use_img = 'ish', grid_vol_init_value = -1)
        prg.get_ish_stack_expression_vol(sec_id)

def t4():
    ss_denoise_rgb_vols = ants.split_channels(ants.image_read('6219_syn_denoise_rgb_vol.nii.gz'))
    ss_denoise_vol = ants.image_read('6219_syn_denoise_vol.nii.gz')
    ref_vol = ants.image_read(utils.get_reference_space())
    # rfp, tree = utils.get_reference_space_tree(25)
    # rfp.remove_unassigned()
    # label_vol = ants.from_numpy(rfp.annotation.copy(), spacing = [25,25,25])
    tr = slice_registration_function(ss_denoise_vol, ref_vol, ss_ex_vols = ss_denoise_rgb_vols, global_register_type = "SyN", slice_register_type = "SyN")
    ants.image_write(tr[0], './6219_SS_denoise_mr.nii.gz')
    ants.image_write(tr[1], './6219_SS_denoise_trv.nii.gz')
    ants.image_write(ants.merge_channels(tr[2]), './6219_SS_denoise_rgb.nii.gz')
        
def get_101_dl_SS_sample_for_template():
    res_dir = "/home/t207/Lab_Data_preproc2/allen_data/dl_datasets/ish/r101_srg_nissl"
    plane = "coronal"
    empty_slice_thval = 10
    donors_ish_associate_nissl_info_dict = prg.get_sepcific_donor_ids_ish_associate_nissl_info(plane)
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= empty_slice_thval]
    for donor_id in donor_ids:
        print(donor_ids.index(donor_id), "th:", donor_id)
        ss_reg_vol = ants.image_read(get_slice_registration_vol(donor_id, global_register_type = "SyN", slice_register_type = "SyN")[0])
        res = prg.get_dl_convert_vol(ss_reg_vol, input_nc = 1, output_nc = 1, ngf = 64, pth_file = "/home/t207/wd_disk/server/allen_project/notebook/cgan/checkpoints/ss101n_k64_r9b/latest_net_G_A.pth", netG = 'resnet_9blocks')
        ants.image_write(res, f'{res_dir}/{donor_id}_sli_rgs_SS_dl.nii.gz')

def get_101_syn_vol():
    ref_vol = ants.image_read(utils.get_reference_space())
    res_dir = f"{utils.STORE_REG_VOL_PATH}/c_icn_st10_s3"    
    os.makedirs(res_dir, exist_ok = True)
    plane = "coronal"
    empty_slice_thval = 10
    donors_ish_associate_nissl_info_dict = prg.get_sepcific_donor_ids_ish_associate_nissl_info(plane)
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= empty_slice_thval] 
    for donor_id in donor_ids:
        print(donor_ids.index(donor_id), "th:", donor_id)
        dl_vol = ants.image_read(prg.get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id = 6219, net_name = '6219_cng_k64_r9b', convert_grey = True, input_nc = 1, output_nc = 1, ngf = 64, pth_file = "/home/t207/Lab_Data_preproc2/allen_data/code/notebook/cgan/checkpoints/c_icn_st10_s3/latest_net_G_A.pth", netG = 'resnet_9blocks', is_force = False, convert_whole_brain = False)[0])
        dl_rf_vol = prg.get_accord_ref_donor_vol(0, "", dl_vol)
        res = ants.registration(ref_vol, dl_rf_vol, type_of_transform = "Affine", outprefix = f"{utils.ANTS_REG_TMP}")
        ants.image_write(res['warpedmovout'], f"{res_dir}/{donor_id}_aff.nii.gz")

def plot_enery_function():
    for sigma_2d in range(100,400,100):
        for sigma_3d in range(100,400,100):
            prg.get_grid_ish_expression_vol(71249740, file_path = ".", use_img = "exp", smth_2d_sigma = sigma_2d, smth_3d_z_sigma = sigma_3d, sync_index = 1)

def get_example_tbv_function():
    for donor_id in prg.DEMO_DONOR_IDS:
        get_registration_boundary_vol(donor_id, net_name = 'c_icn_st10_s3', convert_grey = False, input_nc = 3, output_nc = 3, ngf = 128, pth_file = "/home/t207/Lab_Data_preproc2/allen_data/code/notebook/cgan/checkpoints/c_icn_st10_s3/latest_net_G_A.pth", netG = 'resnet_9blocks', convert_whole_brain = False)

def get_528_allen_tvr_vol():
    import SimpleITK as sitk
    
    dl_res_dir = f"{utils.STORE_REG_VOL_PATH}/c_icn_st10_s3/allen_tvr"
    dl_raw_dir = f"{utils.STORE_REG_VOL_PATH}/raw/allen_tvr"
    os.makedirs(dl_res_dir, exist_ok = True)
    os.makedirs(dl_raw_dir, exist_ok = True)
    empty_slice_thval = 50
    donors_ish_associate_nissl_info_dict = prg.get_sepcific_donor_ids_ish_associate_nissl_info()
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= empty_slice_thval] 
    sum_vol = 0
    dl_sum_vol = 0
    net_name = 'c_icn_st10_s3'
    print(len(donor_ids))
    for donor_id in donor_ids:
        print(f"{donor_ids.index(donor_id)}th: {donor_id}")
        sample_vol = sitk.ReadImage(prg.get_donor_brain_vol(donor_id)[1])
        ms = sitk.VectorIndexSelectionCast(sample_vol, 0) / 3 + sitk.VectorIndexSelectionCast(sample_vol, 1) / 3 + sitk.VectorIndexSelectionCast(sample_vol, 2) / 3
        dl_vol = sitk.ReadImage(prg.get_deep_learning_single_donor_ish_convert_nissl_vol(donor_id, net_name = net_name, convert_grey = False, input_nc = 3, output_nc = 3, ngf = 128, pth_file = "/home/t207/Lab_Data_preproc2/allen_data/code/notebook/cgan/checkpoints/c_icn_st10_s3/latest_net_G_A.pth", netG = 'resnet_9blocks', convert_whole_brain = False)[1])
        md = sitk.VectorIndexSelectionCast(dl_vol, 0) / 3 + sitk.VectorIndexSelectionCast(dl_vol, 1) / 3 + sitk.VectorIndexSelectionCast(dl_vol, 2) / 3
        dl_sum_vol = md + dl_sum_vol
        sum_vol = ms + sum_vol
        sitk.WriteImage(md, f"{dl_res_dir}/{donor_id}_{net_name}_tvr.nii.gz")
        sitk.WriteImage(ms, f"{dl_raw_dir}/{donor_id}_tvr.nii.gz")
        
    sitk.WriteImage(dl_sum_vol, f"{dl_res_dir}/{net_name}_tvr_sum_thval50.nii.gz")
    sitk.WriteImage(sum_vol, f"{dl_raw_dir}/tvr_sum_thval50.nii.gz")

def get_25um_coronal_ish_expression_vol():
    sec_ids = list(utils.get_allen_ish_ids("coronal", 1))
    print(len(sec_ids))
    for sec_id in sec_ids:
        print(f"{sec_ids.index(sec_id)}th: {sec_id}")
        prg.get_grid_ish_expression_vol(sec_id, grid_spacing = 25)

def ants_tvr_run_function(donor_id):
    sec_ids = [sec_id for _, sec_id in prg.get_associate_genes_by_donor_id(donor_id).items()]
    for sec_id in sec_ids:
        get_reference_transform_exp_vol(sec_id, is_grid = True)
        get_reference_transform_exp_vol(sec_id, is_grid = True, net_name = 'c_icn_st10_s3', convert_grey = False, input_nc = 3, output_nc = 3, ngf = 128, pth_file = "/home/t207/Lab_Data_preproc2/allen_data/code/notebook/cgan/checkpoints/c_icn_st10_s3/latest_net_G_A.pth", netG = 'resnet_9blocks', convert_whole_brain = False)
    return donor_id

def get_donors_ish_ants_tvr_vol():
    import concurrent

    donors_ish_associate_nissl_info_dict = prg.get_sepcific_donor_ids_ish_associate_nissl_info()
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] > 50]
    print(len(donor_ids))
    #     for _, sec_id in prg.get_associate_genes_by_donor_id(donor_id).items():
    #         get_reference_transform_exp_vol(sec_id, is_grid = True)
    #         get_reference_transform_exp_vol(sec_id, is_grid = True, net_name = 'c_icn_st10_s3', convert_grey = False, input_nc = 3, output_nc = 3, ngf = 128, pth_file = "/home/t207/Lab_Data_preproc2/allen_data/code/notebook/cgan/checkpoints/c_icn_st10_s3/latest_net_G_A.pth", netG = 'resnet_9blocks', convert_whole_brain = False)
    # with concurrent.futures.ProcessPoolExecutor(max_workers = 16) as excutor:
    #     futs = [excutor.submit(ants_tvr_run_function, donor_id = donor_id) for donor_id in donor_ids]
    #     for fut in concurrent.futures.as_completed(futs):
    #         print(fut.result(), "completed")
    
    for donor_id in donor_ids:
        print(f"{donor_ids.index(donor_id)}th: {ants_tvr_run_function(donor_id)} completed")
        print(f"{donor_ids.index(donor_id)}th: {donor_id} completed")                

def build_template():
    dl_res_dir = f"{utils.STORE_REG_VOL_PATH}/c_icn_st10_s3/allen_tvr"
    # dl_raw_dir = f"{utils.STORE_REG_VOL_PATH}/raw/allen_tvr"
    template_dir = f"{dl_res_dir}/template"
    os.makedirs(template_dir, exist_ok = True)
    donors_ish_associate_nissl_info_dict = prg.get_sepcific_donor_ids_ish_associate_nissl_info()
    donor_ids = [donor_id for donor_id, donor_infos in donors_ish_associate_nissl_info_dict.items() if donor_infos['empty_sec_val'] <= 10] 
    net_name = 'c_icn_st10_s3'
    image_list = [ants.image_read(f"{dl_res_dir}/{donor_id}_{net_name}_tvr.nii.gz") for donor_id in donor_ids]
    template = ants.build_template(ants.image_read(f"{dl_res_dir}/tmp/MY_Affine_template0.nii.gz"), image_list)
    ants.image_write(template, f"{template_dir}/test528_template.nii.gz")

if __name__ == "__main__":
    prg.get_ish_to_nissl_data_set(file_path = "/home/t207/Lab_Data_preproc2/allen_data/dl_datasets/ish/r101_srg_nissl/denoise")
    pass