import os
import typing
import torch
import shutil
import gc


import SimpleITK as sitk
import numpy as np
import pandas as pd

from new_pro.utils import basic
from new_pro.utils import section

def syn_expression_img(ish_image:typing.Optional[sitk.Image] = None, exp_image:typing.Optional[sitk.Image] = None, use_img:typing.Literal['exp', 'ish'] = 'ish', ct_index:int = 2) -> sitk.Image:
    intensity_ct_dict = {1:[0.21, 0.72, 0.07], 2:[0.3, 0.59, 0.11]} # the order in list is red, green, blue
    # 1 is in https://community.brain-map.org/t/quantification-of-gene-expression-by-in-situ-hybridization-finding-and-using-the-raw-values/153/7 
    # 2 is in supplement of An anatomic gene expression atlas of the adult mouse brain article
    red_ct, green_ct, blue_ct = intensity_ct_dict[ct_index][0], intensity_ct_dict[ct_index][1], intensity_ct_dict[ct_index][2]
    if not ish_image:
        ish_image = sitk.ReadImage(f'{section.basic.SECTION_IMG_DATA_PATH}/74881161/raw/74825013.jpg', sitk.sitkVectorFloat32)
    if not exp_image:
        exp_image = sitk.ReadImage(f'{section.basic.SECTION_IMG_DATA_PATH}/74881161/expression/74825013.jpg', sitk.sitkVectorFloat32)
    pc_img = exp_image if use_img == 'exp' else ish_image
    gray_image = sitk.VectorIndexSelectionCast(exp_image, 0) + sitk.VectorIndexSelectionCast(exp_image, 1) + sitk.VectorIndexSelectionCast(exp_image, 2)  
    binary_mask = sitk.BinaryThreshold(gray_image, lowerThreshold = 1, upperThreshold = 255 * 3, insideValue = 1, outsideValue = 0)
    binary_mask = sitk.Cast(binary_mask, sitk.sitkFloat32)
    intensity_img = red_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 0, sitk.sitkFloat32) + green_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 1, sitk.sitkFloat32) + blue_ct * binary_mask * sitk.VectorIndexSelectionCast(pc_img, 2, sitk.sitkFloat32)
    return intensity_img

def grid_image_by_spacing(img:sitk.Image, grid_spacing:int = 200) -> sitk.Image:
    ''' using 2d sitk image type to grid image, the ref: https://community.brain-map.org/t/api-for-mouse-brain-atlas/2766'''
    if img.GetDimension() != 2 or img.GetNumberOfComponentsPerPixel() != 1:
        raise("error about image dimension and pixel components")
    
    raw_size = np.uint32(np.array(img.GetSize()))
    px_spacing = img.GetSpacing()[0]
    grid_px_size = int(np.floor(grid_spacing / px_spacing))
    grid_img_size = np.uint32(np.ceil(raw_size / grid_px_size))
    intensity_array = sitk.GetArrayFromImage(img).T
    pro_intensity_array = np.zeros(grid_img_size * grid_px_size)
    pro_intensity_array[:intensity_array.shape[0], :intensity_array.shape[1]] = intensity_array
    grid_array = []
    for h in range(0, pro_intensity_array.shape[1], grid_px_size):
        grid_row = list()
        for w in range(0, pro_intensity_array.shape[0], grid_px_size):
            grid_row.append(np.mean(pro_intensity_array[w:w + grid_px_size, h:h + grid_px_size]))
        grid_array.append(grid_row)
    grid_array = np.array(grid_array)
    grid_img = sitk.GetImageFromArray(grid_array)
    grid_img.SetSpacing((grid_spacing, grid_spacing))
    
    return grid_img

def resample_image_specific_spacing(image:sitk.Image, new_spacing:tuple, is_2d_grid:bool = False) -> sitk.Image:
    if is_2d_grid and image.GetDimension() == 2 and image.GetNumberOfComponentsPerPixel() == 1:
        return grid_image_by_spacing(image, new_spacing[0])

    original_size = image.GetSize()
    original_spacing = image.GetSpacing()
    
    if image.GetDimension() == 2:
        new_size = [int(round(original_size[0] * (original_spacing[0] / new_spacing[0]))),
                    int(round(original_size[1] * (original_spacing[1] / new_spacing[1])))]
    elif image.GetDimension() == 3:
        new_size = [int(round(original_size[0] * (original_spacing[0] / new_spacing[0]))),
                    int(round(original_size[1] * (original_spacing[1] / new_spacing[1]))),
                    int(round(original_size[2] * (original_spacing[2] / new_spacing[2])))]
    else:
        print(f"image.GetDimension() is equal to {image.GetDimension()}")
        return 0
    return sitk.Resample(image, new_size, sitk.Transform(), sitk.sitkNearestNeighbor, image.GetOrigin(), new_spacing, image.GetDirection(), 0.0, outputPixelType = image.GetPixelIDValue())

def build_alignment_2d(alignment2d:dict, ver:str = "tsv") -> tuple:
    return (alignment2d[f'{ver}_00'],alignment2d[f'{ver}_01'],alignment2d[f'{ver}_02'],alignment2d[f'{ver}_03'],alignment2d[f'{ver}_04'],alignment2d[f'{ver}_05'])

def build_alignment_3d(alignment3d:dict, ver:str = "tvr") -> tuple:
    return (alignment3d[f'{ver}_00'],alignment3d[f'{ver}_01'],alignment3d[f'{ver}_02'],alignment3d[f'{ver}_03'],alignment3d[f'{ver}_04'],alignment3d[f'{ver}_05'], alignment3d[f'{ver}_06'],alignment3d[f'{ver}_07'],alignment3d[f'{ver}_08'],alignment3d[f'{ver}_09'],alignment3d[f'{ver}_10'],alignment3d[f'{ver}_11'])

def get_allen_alingnment_vols(vols:typing.List[sitk.Image], ref_vol:sitk.Image, info_donor_id:int, use_ver3d:typing.Literal["trv", "tvr"]) -> typing.List[sitk.Image]:
    from new_pro.prg import info
    transform3d = sitk.AffineTransform(3)
    transform3d.SetParameters(build_alignment_3d(info.get_donors_info()[info_donor_id]['alignment3d'], use_ver3d))
    return [sitk.Resample(vol, ref_vol, transform3d, sitk.sitkNearestNeighbor) for vol in vols]

def check_dl_vol_status(vol:sitk.Image, mean_filter_val:int = 5) -> bool:
    if vol.GetNumberOfComponentsPerPixel() > 1:
        vol = sitk.VectorIndexSelectionCast(vol, 0)
    statfilter = sitk.StatisticsImageFilter()
    statfilter.Execute(vol)
    status = True if statfilter.GetMean() > mean_filter_val else False
    return status

def get_accord_vol(vol:sitk.Image) -> sitk.Image:
    ''' 
        Since the coronal plane in donor volume is different with ref vol, this function is to fix this, let the coronal plane accord with ref vol.
        Also, if get the re-convert vol, only apply this function on convert vol again.  
    '''
    # The dim of ref vol shape always is (coronal, horizontal, sagittal)
    # If the sample vol is compose of sagittal slices, the dim of sample vol is same as ref vol.  
    # Only the coronal slices vol need convert dim.  
    ss_numpy = sitk.GetArrayFromImage(vol)
    if vol.GetNumberOfComponentsPerPixel() == 3:
        rs_numpy = np.flip(ss_numpy.transpose(2, 1, 0, 3), axis = 2)
    else:
        rs_numpy = np.flip(ss_numpy.transpose(2, 1, 0), axis = 2)
    spacing = vol.GetSpacing()
    spacing = [spacing[2], spacing[1], spacing[0]]
    convert_vol = sitk.GetImageFromArray(rs_numpy, isVector = vol.GetNumberOfComponentsPerPixel() == 3)
    convert_vol.SetSpacing(spacing)
    return convert_vol

#TODO. waiting for better code
def get_DMBA_dwi_accord_ara_demo(file_path = 'DMBA_N02_dwi_M4D.nii.gz', target_path = 'DMBA_N02_dwi_M4D_25um_accord.nii.gz', target_spacing = 25):
    image = sitk.ReadImage(file_path)
    image.SetSpacing((15,15,15))
    image_25um = resample_image_specific_spacing(image, (target_spacing, target_spacing, target_spacing))
    sitk.WriteImage(image_25um, 'DMBA_N02_dwi_M4D_25um.nii.gz')
    image_25um_array = sitk.GetArrayFromImage(image_25um)
    accord_image_25um = sitk.GetImageFromArray(np.flip(image_25um_array.transpose(1,0,2).transpose(2,1,0), axis = [1,2]))
    accord_image_25um.SetSpacing((target_spacing, target_spacing, target_spacing))
    sitk.WriteImage(accord_image_25um, target_path)

def get_sam2_donor_mask_vol(donor_vol:sitk.Image, tmp_dir:str, sli_axis:int = 2, config_file:str = "configs/sam2.1/sam2.1_hiera_b+.yaml", ckpt_path:str = "", device:str = "cuda:1", ann_frame_idx:int = 110, ann_obj_id:int = 1, ptslist:list[list,list] = [[254, 200],[250,250]], ptstypeList:list = [1,1]) -> sitk.Image:  
    import sam2.modeling.backbones.hieradet
    import sam2.build_sam

    torch.autocast("cuda", dtype=torch.bfloat16).__enter__()
    os.makedirs(tmp_dir, exist_ok = True)
    
    if not ckpt_path:
        ckpt_path = f"{os.path.dirname(__file__)}/materials/Mouse755checkpoint.pt"
    
    donor_shape = donor_vol.GetSize()
    axis_idxs = [0, 0, 0]
    axis_size = [donor_shape[i] for i in range(2) if i != sli_axis]
    axis_size.insert(sli_axis, 0)
    num_frames = donor_shape[sli_axis]
    
    for sli in range(0, num_frames):
        axis_idxs[sli_axis] = sli
        sitk.WriteImage(sitk.Extract(donor_vol, axis_size, axis_idxs), f"{tmp_dir}/{sli}.png") 
                
    v_sam2_model = sam2.build_sam.build_sam2_video_predictor(config_file = config_file, ckpt_path = ckpt_path, device = device)
    inference_state = v_sam2_model.init_state(video_path = f"{tmp_dir}")
    points = np.array(ptslist, dtype=np.float32)
    labels = np.array(ptstypeList, np.int32)
    _, out_obj_ids, out_mask_logits = v_sam2_model.add_new_points_or_box(inference_state = inference_state, frame_idx = ann_frame_idx, obj_id = ann_obj_id, points = points, labels = labels)
    video_segments = {} 
    for out_frame_idx, out_obj_ids, out_mask_logits in v_sam2_model.propagate_in_video(inference_state, start_frame_idx = 0):
        video_segments[out_frame_idx] = {out_obj_id: (out_mask_logits[i] > 0.0).cpu().numpy() for i, out_obj_id in enumerate(out_obj_ids)}
    
    sli_size = [size for size in axis_size if size != 0]
    mask_vol = sitk.Image(donor_vol.GetSize(), sitk.sitkUInt8)
    mask_vol.CopyInformation(donor_vol)
    for out_frame_idx in range(0, num_frames):
        axis_idxs[sli_axis] = out_frame_idx
        sli_mask_array = np.zeros(sli_size)
        for _, out_mask in video_segments[out_frame_idx].items():
            out_mask = out_mask.squeeze(0)
            sli_mask_array += out_mask
        sli_mask = sitk.GetImageFromArray(sli_mask_array.astype(np.uint8))
        sli_mask.CopyInformation(sitk.Extract(mask_vol, axis_size, axis_idxs))
        mask_vol = sitk.Paste(mask_vol, sli_mask, sli_size, destinationIndex = axis_idxs)
    shutil.rmtree(f"{tmp_dir}")
    
    del v_sam2_model 
    del video_segments  
    gc.collect()
    torch.cuda.empty_cache()  
    return mask_vol

def get_cgan_convert_vol(raw_vol:sitk.Image, sli_axis:int = 2, convert_slice_idxs:list = [], device = "cuda:1", input_nc:int = 3, output_nc:int = 3, ngf:int = 128, pth_file:str = "", netG:str = 'resnet_9blocks', norm:str ='instance', use_dropout:bool = False) -> str:
    import cgan_net
    from torchvision import transforms
    from PIL import Image
    
    if not pth_file:
        pth_file = f"{os.path.dirname(__file__)}/materials/c_icn_st10_s3.pt"
    is_grey = raw_vol.GetNumberOfComponentsPerPixel() == 1
    tras = transforms.Compose([transforms.Grayscale(1), transforms.ToTensor(), transforms.Normalize((0.5,), (0.5,))]) if is_grey else transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    net = cgan_net.load_G(input_nc = input_nc, output_nc = output_nc, ngf = ngf, pth_file = pth_file, device = device, netG = netG, norm = norm, use_dropout = use_dropout)
    net.to(device)
    net.eval()
    
    donor_shape = raw_vol.GetSize()
    axis_idxs = [0, 0, 0]
    axis_size = [donor_shape[i] for i in range(2) if i != sli_axis]
    axis_size.insert(sli_axis, 0)
    sli_frames = donor_shape[sli_axis]
    convert_slice_idxs = [idx for idx in range(sli_frames)] if not convert_slice_idxs else convert_slice_idxs
    res_vol = sitk.Image(raw_vol)
    
    for idx in convert_slice_idxs:
        axis_idxs[sli_axis] = idx
        raw_sli = sitk.Extract(raw_vol, axis_size, axis_idxs)
        sli = Image.fromarray(sitk.GetArrayFromImage(raw_sli), mode = None if is_grey else "RGB") 
        if np.max(sli) > 0: 
            ori_tensor = tras(sli).unsqueeze(0).to(device).float() if is_grey else tras(sli).to(device).float()
            with torch.no_grad():
                ori_fake = net(ori_tensor)
            dl_sli_np = cgan_net.tensor2im(ori_fake.detach(), is_greyscale_to_RGB = False).squeeze() if is_grey else cgan_net.tensor2im(ori_fake.detach()).transpose(1,2,0)
            dl_sli = sitk.GetImageFromArray(dl_sli_np, isVector = not is_grey)
            dl_sli.CopyInformation(raw_sli)
            res_vol = sitk.Paste(res_vol, dl_sli, dl_sli.GetSize(), destinationIndex = axis_idxs)
    del net 
    del ori_fake  
    gc.collect()
    torch.cuda.empty_cache()      
    return res_vol

def get_donor_brain_vol_path(donor_id:int, set_size:typing.Optional[tuple] = None, transform_spacing:int = 25, img_path:str = "", view:typing.Literal['raw', 'expression'] = "raw", vol_path:str = "", is_force:bool = False, background:typing.Literal['w', 'b'] = 'b', is_2d_grid:bool = False, is_denoise:bool = False, is_dl:bool = False, gen_mask_params:dict = {}, net_name:str = "c_icn_st10_s3", convert_whole_vol:bool = False, gen_dl_params:dict = {}, is_accord:bool = False, is_tvr:bool = False, return_process_files:bool = False, is_mask_force:bool = False, is_dl_force:bool = False, is_tvr_force:bool = False) -> typing.Union[str, list]:
    img_path = basic.SECTION_IMG_DATA_PATH if not img_path else img_path
    vol_path = basic.DONOR_VOL_DATA_PATH if not vol_path else vol_path
    if view == "raw":
        suffix_file = f"{background}.nii.gz"
    else:
        is_dl = False
        is_denoise = False
        background = 'w'
        suffix_file = f"{view}.nii.gz"
    if transform_spacing != 25:
        suffix_file = f"{transform_spacing}um_{suffix_file}"
    transform_spacing = [transform_spacing, transform_spacing]
    if is_2d_grid:
        suffix_file = f"grid_{suffix_file}"
    process_ss_paths = dict()
    os.makedirs(f"{vol_path}/{donor_id}", exist_ok = True)
    ss_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
    process_ss_paths["ss"] = ss_path
    
    if is_tvr and is_accord:
        raise("If is_tvr and is_accord are all true, this will cause error!")
    
    if is_force or not os.path.exists(ss_path): 
        img_dtype = sitk.sitkVectorUInt8 if view == "raw" else sitk.sitkFloat32
        pixel_components_num = 3 if view == "raw" else 1
        section_data_metas = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}]), section_images(alignment2d), treatments')
        section_thickness = list(set([section_data_meta['section_thickness'] for section_data_meta in section_data_metas]))
        sec_treatment_kinds = {section_data_meta['id']:section_data_meta['treatments'][0]['name'] for section_data_meta in section_data_metas}
        view_type = None if view == "raw" else view
        imgs_meta = pd.concat([pd.DataFrame(section_data_meta['section_images']) for section_data_meta in section_data_metas]).sort_values('section_number')
        stack_vol_list = []
        prev_section_number = -1
        if not set_size:
            set_size = (12800, 12800) if section_data_metas[0]['plane_of_section_id'] == 1 else (16000, 16000)
        sample_image = sitk.Image((set_size[1], set_size[0]), img_dtype, pixel_components_num) 
        transform_spacing_sample_image = resample_image_specific_spacing(sample_image, transform_spacing, is_2d_grid)
        # start to stack sample vol
        for row in imgs_meta[['data_set_id','id','section_number','alignment2d']].itertuples():
            if view == "expression" and sec_treatment_kinds[row[1]] != "ISH":
                img = sitk.Image(transform_spacing_sample_image) 
            elif basic.recon_download_image(row[2], view = view_type, file_path = f"{img_path}/{row[1]}/{view}/{row[2]}.jpg"):
                img = 255 - sitk.ReadImage(f"{img_path}/{row[1]}/{view}/{row[2]}.jpg", sitk.sitkVectorUInt8) if background == 'b' else sitk.ReadImage(f"{img_path}/{row[1]}/{view}/{row[2]}.jpg", sitk.sitkVectorUInt8)
                if view == "expression" and basic.recon_download_image(row[2], view = "raw", file_path = f"{img_path}/{row[1]}/raw/{row[2]}.jpg"):
                    ish_img = sitk.ReadImage(f"{img_path}/{row[1]}/raw/{row[2]}.jpg")
                    img = syn_expression_img(ish_img, img)
            else:
                img = sitk.Image(transform_spacing_sample_image) 
            transform2d = sitk.AffineTransform(2)
            transform2d.SetParameters(build_alignment_2d(row[4], "tvs"))
            timage = sitk.Resample(img, sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0, img_dtype)
            stack_vol_list = stack_vol_list + [sitk.Image(transform_spacing_sample_image) for _ in range(row[3] - prev_section_number - 1)]
            stack_vol_list.append(resample_image_specific_spacing(timage, transform_spacing, is_2d_grid))
            prev_section_number = row[3]
        stack_vol_list.append(sitk.Image(transform_spacing_sample_image))
        stack_vol = sitk.JoinSeries(stack_vol_list)
        stack_vol.SetSpacing((transform_spacing[0], transform_spacing[1], section_thickness[0])) 
        sitk.WriteImage(stack_vol, ss_path)
    
    if is_denoise:
        mask_path = f"{vol_path}/{donor_id}/mask_ss_{suffix_file}"
        suffix_file = f"denoise_{suffix_file}"
        denoise_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
        if is_force or not os.path.exists(denoise_path) or is_mask_force:
            plane_of_section_id = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}])')[0]['plane_of_section_id']
            sli_axis = 2 if plane_of_section_id == 1 else 0
            gen_mask_params["sli_axis"] = sli_axis
            gen_mask_params["ann_frame_idx"] =  110 if "ann_frame_idx" not in gen_mask_params.keys() else gen_mask_params["ann_frame_idx"]
            gen_mask_params["ptstypeList"] = [0, 0] 
            donor_vol = sitk.ReadImage(ss_path)
            try_times = 3
            gen_time = 0
            while gen_time < try_times:
                print(f"{gen_time} time to make mask")
                gen_mask_params["ann_frame_idx"] = gen_mask_params["ann_frame_idx"] + 10 * gen_time
                gen_mask_params["ptstypeList"] = [ptsty + np.power(-1, gen_time) for ptsty in gen_mask_params["ptstypeList"]]
                print(f"the gen mask parameters is {gen_mask_params}")
                mask_vol = get_sam2_donor_mask_vol(donor_vol, tmp_dir = f"{vol_path}/{donor_id}/tmp_sli", **gen_mask_params)
                check_status = check_dl_vol_status(sitk.Mask(donor_vol, mask_vol))
                if check_status:
                    break
                gen_time = gen_time + 1
            if check_status:
                sitk.WriteImage(mask_vol, mask_path)
                sitk.WriteImage(sitk.Mask(donor_vol, mask_vol), denoise_path)
            else:
                raise("Check the denoise process seems failed.")
        ss_path = denoise_path
        process_ss_paths["denoise"] = denoise_path
        process_ss_paths["mask"] = mask_path
    
    if is_dl:
        from new_pro.prg import info
        donor_info = info.get_donors_info()[donor_id]
        if donor_info['status'] == "NISSL":
            raise("cgan convert will not work, cause this donor just contain nissl sections")
        if not net_name:
            raise("get the deep learning convert vol must give an net name about your network")
        suffix_file = f"dl_{net_name}_{suffix_file}"
        dl_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
        if is_force or not os.path.exists(dl_path) or is_dl_force:
            plane_of_section_id = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}])')[0]['plane_of_section_id']
            sli_axis = 2 if plane_of_section_id == 1 else 0
            gen_dl_params["sli_axis"] = sli_axis
            donor_vol = sitk.ReadImage(ss_path)
            if not convert_whole_vol:
                # gen_dl_params['convert_slice_idxs'] = [ish_section_order for ish_section_order, _ in info.get_donors_ish_associate_nissl_info()[donor_id]['section_number_of_ish_to_associate_nissl_info'].items()]
                donor_pd = donor_info['section_images_pd']
                gen_dl_params['convert_slice_idxs'] = list(donor_pd.loc[donor_pd['treatment'] == "ISH", "section_number"])
            dl_vol = get_cgan_convert_vol(donor_vol, **gen_dl_params)
            sitk.WriteImage(dl_vol, dl_path)
        ss_path = dl_path
        process_ss_paths["dl"] = dl_path
        
    if is_accord:
        suffix_file = f"accord_{suffix_file}"
        accord_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
        plane_of_section_id = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}])')[0]['plane_of_section_id']
        # Only the coronal slices sample vol need convert.  
        if plane_of_section_id == 1:
            if is_force or not os.path.exists(accord_path):
                sitk.WriteImage(get_accord_vol(sitk.ReadImage(ss_path)), accord_path)
            ss_path = accord_path
        process_ss_paths["accord"] = ss_path
    
    if is_tvr:
        suffix_file = f"tvr_{suffix_file}"
        tvr_path = f"{vol_path}/{donor_id}/{suffix_file}"
        if is_force or not os.path.exists(tvr_path) or is_tvr_force:
            rf_space = sitk.Image(basic.MOUSE_VOL_SHAPE[transform_spacing[0]], sitk.sitkFloat32)
            rf_space[:,:,:] = 1
            rf_space.SetSpacing((transform_spacing[0], transform_spacing[0], transform_spacing[0]))
            tvr_vol = get_allen_alingnment_vols([sitk.ReadImage(ss_path)], rf_space, donor_id, "trv")[0]
            sitk.WriteImage(tvr_vol, tvr_path)
        ss_path = tvr_path
        process_ss_paths["tvr"] = ss_path
        
    if return_process_files:
        return process_ss_paths
    return ss_path

def get_ish_vol_path(sec_id:int, view:str = 'expression', vol_path:str = "", is_force:bool = False, is_grid:bool = True, transform_spacing:int = 25, is_accord:bool = False, **args) -> str:
    vol_path = basic.EXP_VOL_DATA_PATH if not vol_path else vol_path
    sec_info = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include = f'specimen, section_images')
    donor_id = sec_info[0]['specimen']['donor_id']
    plane_of_section_id = sec_info[0]['plane_of_section_id']
    donor_vol_path = get_donor_brain_vol_path(donor_id, view = view, is_2d_grid = is_grid, transform_spacing = transform_spacing, is_accord = is_accord, **args)
    _, sample_name = os.path.split(donor_vol_path)
    sample_name = f"raw_{sample_name}" if view == "raw" else sample_name
    ish_path = f"{vol_path}/{sec_id}/{sample_name}"
    os.makedirs(f"{vol_path}/{sec_id}", exist_ok = True)
    if is_force or not os.path.exists(ish_path):
        if not sec_info:
            raise("the info of this sec_id is None! Check it")
        donor_vol = sitk.ReadImage(donor_vol_path)
        mask_image = sitk.Image(donor_vol.GetSize(), donor_vol.GetPixelIDValue())
        mask_image.CopyInformation(donor_vol)
        for image_info in sec_info[0]['section_images']:
            if plane_of_section_id == 1 and is_accord:
                mask_image[donor_vol.GetSize()[0] - image_info['section_number'] - 1, :, :] = 1
            else:
                mask_image[:, :, image_info['section_number']] = 1
        ish_vol =  sitk.GetImageFromArray(sitk.GetArrayFromImage(mask_image) * sitk.GetArrayFromImage(donor_vol), donor_vol.GetNumberOfComponentsPerPixel() == 3)
        ish_vol.CopyInformation(donor_vol)
        sitk.WriteImage(ish_vol, ish_path)
    return ish_path

def get_ssec_dl_vol(donor_id:int, file_path:str = "", is_denoise:bool = False, is_force:bool = False) -> str:
    cgan_path = "/home/t207/Lab_Data_preproc2/allen_data/code/deep-learning-package/cgan"
    if not file_path:
        file_path = f"{basic.DONOR_VOL_DATA_PATH}/{donor_id}"
    os.makedirs(file_path, exist_ok = True)
    prefix = "dn_" if is_denoise else ""
    file_name = f"ss_secdl_k64_r9b_denoise.nii.gz" if is_denoise else f"ss_secdl_k64_r9b.nii.gz"
    file_path = f"{file_path}/{file_name}"
    if is_force or not os.path.exists(file_path):
        from new_pro.prg import info
        dl_sec_list = []
        sec_ids = [sec_id for _, sec_id in info.get_associate_genes_by_donor_id(donor_id).items()]
        for sec_id in sec_ids:
            sec_vol = get_ish_vol_path(sec_id, view = "raw", is_grid = False, is_denoise = is_denoise)
            pth_file = f"{cgan_path}/checkpoints/{prefix}sec{sec_id}_k64_r9b/latest_net_G_A.pth"
            dl_sec_list.append(get_cgan_convert_vol(sec_vol, ngf = 64, pth_file = pth_file))
        dl_vol = sitk.Mean(dl_sec_list) * len(dl_sec_list)
        sitk.WriteImage(dl_vol, file_path)
    return file_path

def download_donor_section_images(donor_id:int, img_path:str = ""):
    from new_pro.prg import info
    img_path = basic.SECTION_IMG_DATA_PATH if not img_path else img_path
    for row in info.get_donor_section_images_infos(donor_id).itertuples():
        basic.recon_download_image(row[2], view = "raw", file_path = f"{img_path}/{row[1]}/raw/{row[2]}.jpg")
        if row[4] == "ISH":
            basic.recon_download_image(row[2], view = "expression", file_path = f"{img_path}/{row[1]}/expression/{row[2]}.jpg")
    return donor_id

@DeprecationWarning
def get_donor_tvr_vol_path(donor_id:int, is_force:bool = False, ref_spacing:int = 25, ref_type:str = "nissl", ref_file:str = "nrrd", **donor_vol_args) -> str:
    ss_vol_path = get_donor_brain_vol_path(donor_id, **donor_vol_args)
    dir_name, ss_name = os.path.split(ss_vol_path)
    tvr_name = str.replace(ss_name, "ss", "tvr")
    tvr_vol_path = f"{dir_name}/{tvr_name}"
    if is_force or not os.path.exists(tvr_vol_path):
        from new_pro.utils import rf
        tvr_vol = get_allen_alingnment_vols([sitk.ReadImage(ss_vol_path)], sitk.ReadImage(rf.get_reference_vol_path(ref_type, ref_file, ref_spacing)), "trv")[0]
        tvr_vol = get_allen_alingnment_vols([sitk.ReadImage(ss_vol_path)], sitk.Image(basic.MOUSE_VOL_SHAPE[ref_spacing], sitk.sitkFloat32), "trv")[0]
        sitk.WriteImage(tvr_vol, tvr_vol_path)
    return tvr_vol_path

@DeprecationWarning
def old_get_donor_brain_vol_path(donor_id:int, set_size:typing.Optional[tuple] = None, transform_spacing:int = 25, img_path:str = "", view:typing.Literal['raw', 'expression'] = "raw", vol_path:str = "", is_force:bool = False, ref_vol:typing.Optional[sitk.Image] = None, background:typing.Literal['w', 'b'] = 'b', is_2d_grid:bool = False, is_denoise:bool = False, is_dl:bool = False, gen_mask_params:dict = {}, net_name:str = "c_icn_st10_s3", convert_whole_vol:bool = False, gen_dl_params:dict = {}, is_accord:bool = False, ver2d:str = "tvs", ver3d:tuple = ("trv", "tvr")) -> str:

    img_path = basic.SECTION_IMG_DATA_PATH if not img_path else img_path
    vol_path = basic.DONOR_VOL_DATA_PATH if not vol_path else vol_path
    
    if view == "raw":
        suffix_file = f"{background}.nii.gz"
    else:
        is_dl = False
        is_denoise = False
        background = 'w'
        suffix_file = f"{view}.nii.gz"

    if transform_spacing != 25:
        suffix_file = f"{transform_spacing}um_{suffix_file}"
    transform_spacing = [transform_spacing, transform_spacing]

    if is_2d_grid:
        suffix_file = f"grid_{suffix_file}"
    
    os.makedirs(f"{vol_path}/{donor_id}", exist_ok = True)
    ss_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
    tvr_path = f"{vol_path}/{donor_id}/tvr_{suffix_file}"
    trv_path = f"{vol_path}/{donor_id}/trv_{suffix_file}"
    
    if is_force or not os.path.exists(ss_path): 
        
        img_dtype = sitk.sitkVectorUInt8 if view == "raw" else sitk.sitkFloat32
        pixel_components_num = 3 if view == "raw" else 1
        section_data_metas = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}]), alignment3d, section_images(alignment2d), treatments')
        section_thickness = list(set([section_data_meta['section_thickness'] for section_data_meta in section_data_metas]))
        sec_treatment_kinds = {section_data_meta['id']:section_data_meta['treatments'][0]['name'] for section_data_meta in section_data_metas}
        view_type = None if view == "raw" else view
        imgs_meta = pd.concat([pd.DataFrame(section_data_meta['section_images']) for section_data_meta in section_data_metas]).sort_values('section_number')
        stack_vol_list = []
        prev_section_number = -1
        if not set_size:
            set_size = (12800, 12800) if section_data_metas[0]['plane_of_section_id'] == 1 else (16000, 12000)
        sample_image = sitk.Image((set_size[1], set_size[0]), img_dtype, pixel_components_num) 
        transform_spacing_sample_image = resample_image_specific_spacing(sample_image, transform_spacing, is_2d_grid)
        # start to stack sample vol
        for row in imgs_meta[['data_set_id','id','section_number','alignment2d']].itertuples():
            print(row[3])
            if view == "expression" and sec_treatment_kinds[row[1]] != "ISH":
                img = sitk.Image(transform_spacing_sample_image) 
            elif basic.recon_download_image(row[2], view = view_type, file_path = f"{img_path}/{row[1]}/{view}/{row[2]}.jpg"):
                img = 255 - sitk.ReadImage(f"{img_path}/{row[1]}/{view}/{row[2]}.jpg", sitk.sitkVectorUInt8) if background == 'b' else sitk.ReadImage(f"{img_path}/{row[1]}/{view}/{row[2]}.jpg", sitk.sitkVectorUInt8)
                if view == "expression" and basic.recon_download_image(row[2], view = "raw", file_path = f"{img_path}/{row[1]}/raw/{row[2]}.jpg"):
                    ish_img = sitk.ReadImage(f"{img_path}/{row[1]}/raw/{row[2]}.jpg")
                    img = syn_expression_img(ish_img, img)
            else:
                img = sitk.Image(transform_spacing_sample_image) 
            transform2d = sitk.AffineTransform(2)
            transform2d.SetParameters(build_alignment_2d(row[4], ver2d))
            timage = sitk.Resample(img, sample_image, transform2d, sitk.sitkNearestNeighbor, 0.0, img_dtype)
            stack_vol_list = stack_vol_list + [sitk.Image(transform_spacing_sample_image) for _ in range(row[3] - prev_section_number - 1)]
            stack_vol_list.append(resample_image_specific_spacing(timage, transform_spacing, is_2d_grid))
            prev_section_number = row[3]

        stack_vol_list.append(sitk.Image(transform_spacing_sample_image))
        stack_vol = sitk.JoinSeries(stack_vol_list)
        stack_vol.SetSpacing((transform_spacing[0], transform_spacing[1], section_thickness[0])) 
        tvr_alignment3ds = list(set([build_alignment_3d(section_data_meta['alignment3d'], ver3d[0]) for section_data_meta in section_data_metas]))
        trv_alignment3ds = list(set([build_alignment_3d(section_data_meta['alignment3d'], ver3d[1]) for section_data_meta in section_data_metas]))
        if len(tvr_alignment3ds) > 1 or len(trv_alignment3ds) > 1 or len(section_thickness) > 1:
            raise("check alignment3ds and section_thickness, it may have different donor in one data set")
        tvr_transform3d = sitk.AffineTransform(3)
        tvr_transform3d.SetParameters(tvr_alignment3ds[0])
        trv_transform3d = sitk.AffineTransform(3)
        trv_transform3d.SetParameters(trv_alignment3ds[0])
        
        if not ref_vol:
            from new_pro.utils import rf
            ref_vol = sitk.ReadImage(rf.get_reference_vol_path(spacing = transform_spacing[0]))
            
        sitk.WriteImage(sitk.Resample(stack_vol, ref_vol, tvr_transform3d, sitk.sitkNearestNeighbor), tvr_path)
        sitk.WriteImage(sitk.Resample(ref_vol, stack_vol, trv_transform3d, sitk.sitkNearestNeighbor), trv_path)    
        sitk.WriteImage(stack_vol, ss_path)
    
    if is_denoise:
        mask_path = f"{vol_path}/{donor_id}/mask_ss_{suffix_file}"
        suffix_file = f"denoise_{suffix_file}"
        denoise_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
        if is_force or not os.path.exists(denoise_path):
            plane_of_section_id = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}])')[0]['plane_of_section_id']
            sli_axis = 2 if plane_of_section_id == 1 else 0
            gen_mask_params["sli_axis"] = sli_axis
            donor_vol = sitk.ReadImage(ss_path)
            if os.path.exists(mask_path):
                mask_vol = sitk.ReadImage(mask_path)  
            else:
                mask_vol = get_sam2_donor_mask_vol(donor_vol, tmp_dir = f"{vol_path}/{donor_id}/tmp_sli", **gen_mask_params)
                sitk.WriteImage(mask_vol, mask_path)
            sitk.WriteImage(sitk.Mask(donor_vol, mask_vol), denoise_path)
        ss_path = denoise_path
    
    if is_dl:
        if not net_name:
            raise("get the deep learning convert vol must give an net name about your network")
        suffix_file = f"dl_{net_name}_{suffix_file}"
        dl_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
        if is_force or not os.path.exists(dl_path):
            plane_of_section_id = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}])')[0]['plane_of_section_id']
            sli_axis = 2 if plane_of_section_id == 1 else 0
            gen_dl_params["sli_axis"] = sli_axis
            donor_vol = sitk.ReadImage(ss_path)
            if not convert_whole_vol:
                from new_pro.prg import info
                gen_dl_params['convert_slice_idxs'] = [ish_section_order for ish_section_order, _ in info.get_donors_ish_associate_nissl_info()[donor_id]['section_number_of_ish_to_associate_nissl_info'].items()]
            dl_vol = get_cgan_convert_vol(donor_vol, **gen_dl_params)
            sitk.WriteImage(dl_vol, dl_path)
        ss_path = dl_path

    if is_accord:
        suffix_file = f"accord_{suffix_file}"
        accord_path = f"{vol_path}/{donor_id}/ss_{suffix_file}"
        plane_of_section_id = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f'specimen(donor[id$eq{donor_id}])')[0]['plane_of_section_id']
        # Only the coronal slices sample vol need convert.  
        if plane_of_section_id == 1 and (is_force or not os.path.exists(accord_path)):
            sitk.WriteImage(get_accord_vol(sitk.ReadImage(ss_path)), accord_path)
            ss_path = accord_path
            
    return ss_path

@DeprecationWarning
def old_get_ish_expression_vol_path(sec_id:int, vol_path:str = "", is_force:bool = False, is_grid:bool = True, transform_spacing:int = 25, **args) -> str:
    vol_path = basic.EXP_VOL_DATA_PATH if not vol_path else vol_path
    suffix_file = ".nii.gz"
    if transform_spacing != 25:
        suffix_file = f"_{transform_spacing}um{suffix_file}"
    if is_grid:
        suffix_file = f"_grid{suffix_file}"
    exp_path = f"{vol_path}/{sec_id}/ss{suffix_file}"
    os.makedirs(f"{vol_path}/{sec_id}", exist_ok = True)
    if is_force or not os.path.exists(exp_path):
        sec_info = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include = f'specimen')
        if not sec_info:
            raise("the info of this sec_id is None! Check it")
        donor_id = sec_info[0]['specimen']['donor_id']
        donor_exp_vol = sitk.ReadImage(get_donor_brain_vol_path(donor_id, view = 'expression', is_2d_grid = is_grid, transform_spacing = transform_spacing, **args))
        exp_mask_image = sitk.Image(donor_exp_vol.GetSize(), sitk.sitkUInt8)
        for image_info in sec_info[0]['section_images']:
            exp_mask_image[:, :, image_info['section_number']] = 1
        exp_vol = sitk.GetImageFromArray(sitk.GetArrayFromImage(donor_exp_vol) * sitk.GetArrayFromImage(exp_mask_image))
        exp_vol.CopyInformation(donor_exp_vol)
        sitk.WriteImage(exp_vol, exp_path)
    return exp_path