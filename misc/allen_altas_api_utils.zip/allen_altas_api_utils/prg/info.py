import os
import pickle
import typing
import pandas as pd
import concurrent.futures

from utils import basic

# This script use to product the information of mouse(P56) donor.  
# Beacuse the process will take a long time, we offer all dicts of information in the materials dir.  
# The param 'file_path' should be not changed, all the function will load the dicts in the materials dir.  
# Use basic.recon_model_query(model = "Product", num_rows = "all") to see all the product of allen. 

def get_donors_info_by_plane(plane:str = "coronal", product:int = 1, file_path:str = "", is_force:bool = False) -> dict:
    if not file_path:
        file_path = f"{os.path.dirname(__file__)}/materials"
    donor_info_dict_path = f"{file_path}/{plane}_{product}_donor_ids_info.dict" 
    if not is_force and os.path.exists(donor_info_dict_path):
        with open(donor_info_dict_path, 'rb') as f:
            donor_info_dict = pickle.load(f)
        return donor_info_dict
    # since the web limits for the query reply, split the ish and nissl to proccess repesctively.
    ish_info = basic.recon_model_query(model = 'Donor', num_rows = 'all', include = f"specimens(data_sets(treatments[name$eq'ISH'], [failed$eq'false'], products[id$eq{product}], plane_of_section[name$eq'{plane}']))")
    nissl_info = basic.recon_model_query(model = 'Donor', num_rows = 'all', include = f"specimens(data_sets(treatments[name$eq'NISSL'], [failed$eq'false'], products[id$eq{product}], plane_of_section[name$eq'{plane}']))")
    ish_datasets = {}
    for ifo in ish_info:
        ish_datasets[ifo['id']] = []
        for did in ifo['specimens'][0]['data_sets']:
            ish_datasets[ifo['id']].append(did['id'])
    nissl_datasets = {}
    for ifo in nissl_info:
        nissl_datasets[ifo['id']] = []
        for did in ifo['specimens'][0]['data_sets']:
            nissl_datasets[ifo['id']].append(did['id'])
    ni_intersect_list = list(set(nissl_datasets.keys()) & set(ish_datasets.keys()))
    uni_nissl_list = list(set(nissl_datasets.keys()) - set(ish_datasets.keys()))
    uni_ish_list = list(set(ish_datasets.keys()) - set(nissl_datasets.keys()))
    all_datasets = {}
    for donor_id in ni_intersect_list:
        all_datasets[donor_id] = ish_datasets[donor_id] + nissl_datasets[donor_id]
    for donor_id in uni_ish_list:
        all_datasets[donor_id] = ish_datasets[donor_id]
    for donor_id in uni_nissl_list:
        all_datasets[donor_id] = nissl_datasets[donor_id]
    donor_info_dict = {}
    print(f"the num of donor is {len(all_datasets.keys())}")
    index_process = 0
    # TODO. need to change the pandas dataframe to normal dict to save memory and compatibility.
    for donor_id, secdataset_ids in all_datasets.items():
        print(f"The {index_process}th donor {donor_id} start process")
        index_process = index_process + 1
        secs_pd_dict = {}
        secs_pd_dict['section_images_pd'] = {}
        for secdataset_id in secdataset_ids:
            sec_info = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq{secdataset_id}], [failed$eq'false']", include = "treatments, alignment3d, section_images(alignment2d), genes")
            if 'alignment3d' not in list(sec_info[0].keys()) or 'alignment2d' not in list(sec_info[0]['section_images'][0].keys()):
                continue
            secs_pd_dict['alignment3d'] = sec_info[0]['alignment3d']
            sec_pd = pd.DataFrame(sec_info[0]['section_images'])
            sec_pd['treatment'] = sec_info[0]['treatments'][0]['name']
            sec_pd['gene_name'] = sec_info[0]['genes'][0]['acronym'] if sec_info[0]['genes'] else sec_info[0]['treatments'][0]['name']
            sec_pd['associates_nissl_info'] = ""
            if sec_info[0]['genes'] and donor_id in ni_intersect_list:
                associate_nissl_info_pd = pd.DataFrame(basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq{secdataset_id}], [failed$eq'false']", include = "section_images(associates(data_set(treatments[name$eq'NISSL'])))")[0]['section_images'])[['section_number', "associates"]]
                for row in associate_nissl_info_pd.itertuples():
                    associate_nissl_info = row[2][0]
                    associate_nissl_dict = dict(data_set_id = associate_nissl_info["data_set_id"], image_id = associate_nissl_info["id"], section_number = associate_nissl_info["section_number"])
                    sec_pd.loc[sec_pd['section_number'] == row[1], 'associates_nissl_info'] = [associate_nissl_dict]
            secs_pd_dict['section_images_pd'].append(sec_pd[['data_set_id', 'id', 'section_number', 'resolution', 'alignment2d', 'treatment', 'gene_name', 'associates_nissl_info']])
        if not secs_pd_dict['section_images_pd']:
            secs_pd_dict['status'] = 'Null'
        else:    
            secs_pd_dict['section_images_pd'] = pd.concat(secs_pd_dict['section_images_pd']).sort_values('section_number')
            if donor_id in ni_intersect_list:
                secs_pd_dict['status'] = 'Hybrid'
            elif donor_id in uni_ish_list:
                secs_pd_dict['status'] = 'ISH'
            else:
                secs_pd_dict['status'] = 'NISSL'
            secs_pd_dict['empty_sec_val'] = max(secs_pd_dict['section_images_pd']["section_number"]) - len(secs_pd_dict['section_images_pd'].index)
        donor_info_dict[donor_id] = secs_pd_dict    
    
    print(f"Writing info into file")                
    with open(donor_info_dict_path, 'wb') as f:
        pickle.dump(donor_info_dict, f)
    return donor_info_dict

def get_donors_info(product:int = 1, file_path:str = "", is_force:bool = False) -> dict:
    if not file_path:
        file_path = f"{os.path.dirname(__file__)}/materials"     
    res_path = f"{file_path}/all_{product}_donor_ids_info.dict"
    if is_force or not os.path.exists(res_path):
        co = get_donors_info_by_plane(plane = "coronal", product = product, file_path = file_path)
        sa = get_donors_info_by_plane(plane = "sagittal", product = product, file_path = file_path)
        co.update(sa)
        with open(res_path, 'wb') as f:
            pickle.dump(co, f)
    with open(res_path, 'rb') as f:
        res = pickle.load(f)
    return res

def get_single_donor_ish_associate_nissl_info(donor_id:int, section_images_pd:typing.Optional[pd.DataFrame]= None, **args) -> tuple:
    '''This function is just used to product infos'''
    ish_associate_nissl_info_dict = {}
    section_images_pd = section_images_pd if type(section_images_pd) == pd.DataFrame else get_donors_info_by_plane(args)[donor_id]['section_images_pd']
    ish_associate_nissl_info_dict['empty_sec_val'] = section_images_pd[['section_number']].iloc[-1, 0] - len(section_images_pd.index)
    ish_associate_nissl_info_dict['section_number_of_ish_to_associate_nissl_info'] = {}
    for row in section_images_pd[['id','section_number', 'treatment']].itertuples():
        associate_nissl_info_dict = {}
        if row[3] == "ISH":
            associate_nissl_image_info = basic.recon_model_query(model = 'SectionImage', criteria = f"[id$eq{row[1]}]", include = f"associates(data_set(treatments[name$eq'NISSL']))")[0]['associates'][0]
            associate_nissl_info_dict['associate_nissl_data_set_id'] = associate_nissl_image_info['data_set_id']
            associate_nissl_info_dict['associate_nissl_image_id'] = associate_nissl_image_info['id']
            associate_nissl_info_dict['associate_nissl_image_section_number'] = associate_nissl_image_info['section_number']
            ish_associate_nissl_info_dict['section_number_of_ish_to_associate_nissl_info'][row[2]] = associate_nissl_info_dict
    return donor_id, ish_associate_nissl_info_dict

def get_donors_ish_associate_nissl_info_by_plane(plane:str = "coronal", product:int = 1, file_path:str = "", is_force:bool = False, n_process:int = 8) -> dict:   
    ''' for all donors, just use in nissl which already have larger empty section numbers( >= 240 slices false qc), then use small thval will give us ish-nissl donors'''
    if not file_path:
        file_path = f"{os.path.dirname(__file__)}/materials"    
    donors_ish_associate_nissl_info_dict_path = f"{file_path}/{plane}_{product}_donors_ish_associate_nissl_info.dict"
    if not is_force and os.path.exists(donors_ish_associate_nissl_info_dict_path):
        with open(donors_ish_associate_nissl_info_dict_path, "rb") as f:
            donors_ish_associate_nissl_info_dict = pickle.load(f)
        return donors_ish_associate_nissl_info_dict
    
    donor_id_infos = get_donors_info_by_plane(plane = plane, product = product, file_path = file_path)
    donors_ish_associate_nissl_info_dict = {}
    
    with concurrent.futures.ProcessPoolExecutor(max_workers = n_process) as excutor:
        futs = [excutor.submit(get_single_donor_ish_associate_nissl_info, donor_id = donor_id, file_path = file_path, section_images_pd = donor_infos['section_images_pd']) for donor_id, donor_infos in donor_id_infos.items() if donor_infos['status'] == 'Hybrid']
        for fut in concurrent.futures.as_completed(futs):
            print(f"the donor_id {fut.result()[0]} complete")
            donors_ish_associate_nissl_info_dict[fut.result()[0]] = fut.result()[1]
    
    if donors_ish_associate_nissl_info_dict:        
        with open(donors_ish_associate_nissl_info_dict_path, 'wb') as f:
            pickle.dump(donors_ish_associate_nissl_info_dict, f)
    return donors_ish_associate_nissl_info_dict

def get_donors_ish_associate_nissl_info(product:int = 1, file_path:str = "", is_force:bool = False) -> dict:
    if not file_path:
        file_path = f"{os.path.dirname(__file__)}/materials"  
    res_path = f"{file_path}/all_{product}_donor_ish_associate_nissl_info.dict"
    if is_force or not os.path.exists(res_path):
        co = get_donors_ish_associate_nissl_info_by_plane(plane = "coronal", product = product, file_path = file_path)
        sa = get_donors_ish_associate_nissl_info_by_plane(plane = "sagittal", product = product, file_path = file_path)
        co.update(sa)
        with open(res_path, 'wb') as f:
            pickle.dump(co, f)
    with open(res_path, 'rb') as f:
        res = pickle.load(f)
    return res

def get_donor_section_images_infos(donor_id:int) -> pd.DataFrame:
    donor_info =  basic.recon_model_query(model = 'Donor', num_rows = 'all', criteria=f"[id$eq{donor_id}]", include = f"specimens(data_sets(treatments[name$in'ISH', 'NISSL'], [failed$eq'false'], genes))")
    section_images_pd_list = []
    for sec_info in donor_info[0]['specimens'][0]['data_sets']:
        imgs_info = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq{sec_info['id']}], [failed$eq'false']", include = "treatments, alignment3d, section_images(alignment2d)")
        if 'alignment3d' in list(imgs_info[0].keys()) and 'alignment2d' in list(imgs_info[0]['section_images'][0].keys()):
            sec_pd = pd.DataFrame(imgs_info[0]['section_images'])
            sec_pd['treatment'] = imgs_info[0]['treatments'][0]['name']
            sec_pd['gene_name'] = sec_info['genes'][0]['acronym'] if sec_info['genes'] else imgs_info[0]['treatments'][0]['name']
            section_images_pd_list.append(sec_pd[['data_set_id', 'id', 'section_number', 'treatment', 'gene_name']])
    if section_images_pd_list:
        section_images_pd = pd.concat(section_images_pd_list, ignore_index = True).sort_values('section_number')
        return section_images_pd
    else:
        return False

def get_associate_genes_by_donor_id(donor_id:int) -> dict:
    res_dict = {}
    sec_infos = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f"specimen(donor[id$eq{donor_id}]), genes")
    for sec_info in sec_infos:
        if sec_info['genes']:
            res_dict[sec_info['genes'][0]['acronym']] = sec_info['id']
    return res_dict

def get_associate_sec_id_by_donor(donor_id:int, treatments:str = 'ISH', product_index:int = 1) -> dict:
    sec_infos = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f"specimen(donor[id$eq{donor_id}]),  treatments[name$eqISH], products[id$eq1]")
    sec_ids = []
    for sec_info in sec_infos:
        if sec_info['id']:
            sec_ids.append(sec_info['id'])
    return sec_ids

def get_associate_sec_id_by_genes(acronym:str, treatments:str = 'ISH', product_index:int = 1) -> dict:
    sec_infos = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[failed$eq'false']", include=f"genes[acronym$eq{acronym}], treatments[name$eq{treatments}], products[id$eq{product_index}]")
    res_dict = {}
    if sec_infos:
        res_dict["coronal"] = []
        res_dict["sagittal"] = []
        for sec_info in sec_infos:
            if sec_info['plane_of_section_id'] == 1:
                res_dict["coronal"].append(sec_info['id'])
            else:
                res_dict["sagittal"].append(sec_info['id'])
    return res_dict

def cal_metric_nissl_to_ish_by_donor(donor_id:int, is_force:bool = False, cor_dict_path:str = ""):
    import functools
    import os
    import cv2
    import numpy as np

    donor_pd = get_donors_info()[donor_id]['section_images_pd']
    if not cor_dict_path:
        cor_dict_path = basic.DONOR_VOL_DATA_PATH + f"/{donor_id}/" +  "cor_ish_to_nissl.dict"
    if is_force or not os.path.exists(cor_dict_path):
        res_dict = dict()
        res_dict['donor_id'] = []
        res_dict['metric'] = []
        res_dict['gene'] = []
        res_dict['relation'] = []
        res_dict['status'] = []
        res_dict['section_number'] = []
        res_dict['channel'] = []
        res_dict['res_val'] = []

        metric_kind_function_dict = {"hist_cor":functools.partial(cv2.compareHist, method = cv2.HISTCMP_CORREL), "hist_chi_square":functools.partial(cv2.compareHist, method = cv2.HISTCMP_CHISQR), "hist_intersection":functools.partial(cv2.compareHist, method = cv2.HISTCMP_INTERSECT), "hist_bhattacharyya":functools.partial(cv2.compareHist, method = cv2.HISTCMP_BHATTACHARYYA)}

        channels = {"r":0, "g":1, "b":2, "gray":0}
        status_masks = ["delete_exp", "no_mask", "delete_background"]

        for row in donor_pd.itertuples():
            if row[6] == "ISH":
                raw = cv2.imread(f"{basic.SECTION_IMG_DATA_PATH}/{row[1]}/raw/{row[2]}.jpg")
                exp = cv2.imread(f"{basic.SECTION_IMG_DATA_PATH}/{row[1]}/expression/{row[2]}.jpg", 0)
                nissl = cv2.imread(f"{basic.SECTION_IMG_DATA_PATH}/{row[8]['data_set_id']}/raw/{row[8]['image_id']}.jpg")
                gray_raw = np.mean(raw, 2)
                # gray_nissl = np.mean(nissl, 2)
                delete_exp_mask = exp.copy()
                delete_background_mask = exp.copy()
                delete_exp_mask[exp > 0] = 0
                delete_exp_mask[exp == 0] = 1
                delete_background_mask[exp > 0] = 1
                for status_mask in status_masks:
                    if status_mask == "delete_exp":
                        mask_seq = delete_exp_mask
                    elif status_mask == "delete_background":
                        mask_seq = delete_background_mask
                    else:
                        mask_seq = np.ones_like(gray_raw)
                    for channel, channel_index in channels.items():
                        raw_seq = 255 - np.mean(255 - raw, axis = 2, dtype = np.uint8) if channel == "gray" else np.take(raw, channel_index, 2).astype(np.uint8)
                        raw_seq = mask_seq * raw_seq
                        raw_seq = raw_seq.astype(np.uint8)
                        nissl_seq = 255 - np.mean(255 - nissl, axis = 2, dtype = np.uint8) if channel == "gray" else np.take(nissl, channel_index, 2).astype(np.uint8)
                        hist_raw = cv2.calcHist([raw_seq],[0], None, [256], [0,256])
                        hist_nissl = cv2.calcHist([nissl_seq],[0], None, [256], [0,256])
                        for metric, metric_function in metric_kind_function_dict.items():
                            res_dict['donor_id'].append(donor_id)
                            res_dict['metric'].append(metric)
                            res_dict['gene'].append(row[7])
                            res_dict['relation'].append("ish_to_nissl")
                            res_dict['status'].append(status_mask)
                            res_dict['section_number'].append(row[3])
                            res_dict['channel'].append(channel)
                            if metric in ["ssim", "mse"]:
                                res_dict['res_val'].append(metric_function(raw_seq, nissl_seq))
                            else:
                                res_dict['res_val'].append(metric_function(hist_raw, hist_nissl))
        with open(cor_dict_path, "wb") as f:
            pickle.dump(res_dict, f)
    with open(cor_dict_path, "rb") as f:
        res_dict = pickle.load(f)
    return res_dict

@DeprecationWarning
def get_donors_info_by_plane_pd_fomat(plane:str = "coronal", product:int = 1, file_path:str = "", is_force:bool = False) -> dict:
    if not file_path:
        file_path = f"{os.path.dirname(__file__)}/materials"
    donor_info_dict_path = f"{file_path}/{plane}_{product}_donor_ids_info.dict" 
    if not is_force and os.path.exists(donor_info_dict_path):
        with open(donor_info_dict_path, 'rb') as f:
            donor_info_dict = pickle.load(f)
        return donor_info_dict
    # since the web limits for the query reply, split the ish and nissl to proccess repesctively.
    ish_info = basic.recon_model_query(model = 'Donor', num_rows = 'all', include = f"specimens(data_sets(treatments[name$eq'ISH'], [failed$eq'false'], products[id$eq{product}], plane_of_section[name$eq'{plane}']))")
    nissl_info = basic.recon_model_query(model = 'Donor', num_rows = 'all', include = f"specimens(data_sets(treatments[name$eq'NISSL'], [failed$eq'false'], products[id$eq{product}], plane_of_section[name$eq'{plane}']))")
    ish_datasets = {}
    for ifo in ish_info:
        ish_datasets[ifo['id']] = []
        for did in ifo['specimens'][0]['data_sets']:
            ish_datasets[ifo['id']].append(did['id'])
    nissl_datasets = {}
    for ifo in nissl_info:
        nissl_datasets[ifo['id']] = []
        for did in ifo['specimens'][0]['data_sets']:
            nissl_datasets[ifo['id']].append(did['id'])
    ni_intersect_list = list(set(nissl_datasets.keys()) & set(ish_datasets.keys()))
    uni_nissl_list = list(set(nissl_datasets.keys()) - set(ish_datasets.keys()))
    uni_ish_list = list(set(ish_datasets.keys()) - set(nissl_datasets.keys()))
    all_datasets = {}
    for donor_id in ni_intersect_list:
        all_datasets[donor_id] = ish_datasets[donor_id] + nissl_datasets[donor_id]
    for donor_id in uni_ish_list:
        all_datasets[donor_id] = ish_datasets[donor_id]
    for donor_id in uni_nissl_list:
        all_datasets[donor_id] = nissl_datasets[donor_id]
    donor_info_dict = {}
    print(f"the num of donor is {len(all_datasets.keys())}")
    index_process = 0
    for donor_id, secdataset_ids in all_datasets.items():
        print(f"The {index_process}th donor {donor_id} start process")
        index_process = index_process + 1
        secs_pd_dict = {}
        secs_pd_dict['section_images_pd'] = []
        for secdataset_id in secdataset_ids:
            sec_info = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq{secdataset_id}], [failed$eq'false']", include = "treatments, alignment3d, section_images(alignment2d), genes")
            if 'alignment3d' not in list(sec_info[0].keys()) or 'alignment2d' not in list(sec_info[0]['section_images'][0].keys()):
                continue
            secs_pd_dict['alignment3d'] = sec_info[0]['alignment3d']
            sec_pd = pd.DataFrame(sec_info[0]['section_images'])
            sec_pd['treatment'] = sec_info[0]['treatments'][0]['name']
            sec_pd['gene_name'] = sec_info[0]['genes'][0]['acronym'] if sec_info[0]['genes'] else sec_info[0]['treatments'][0]['name']
            sec_pd['associates_nissl_info'] = ""
            if sec_info[0]['genes'] and donor_id in ni_intersect_list:
                associate_nissl_info_pd = pd.DataFrame(basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq{secdataset_id}], [failed$eq'false']", include = "section_images(associates(data_set(treatments[name$eq'NISSL'])))")[0]['section_images'])[['section_number', "associates"]]
                for row in associate_nissl_info_pd.itertuples():
                    associate_nissl_info = row[2][0]
                    associate_nissl_dict = dict(data_set_id = associate_nissl_info["data_set_id"], image_id = associate_nissl_info["id"], section_number = associate_nissl_info["section_number"])
                    sec_pd.loc[sec_pd['section_number'] == row[1], 'associates_nissl_info'] = [associate_nissl_dict]
            secs_pd_dict['section_images_pd'].append(sec_pd[['data_set_id', 'id', 'section_number', 'resolution', 'alignment2d', 'treatment', 'gene_name', 'associates_nissl_info']])
        if not secs_pd_dict['section_images_pd']:
            secs_pd_dict['status'] = 'Null'
        else:    
            secs_pd_dict['section_images_pd'] = pd.concat(secs_pd_dict['section_images_pd']).sort_values('section_number')
            if donor_id in ni_intersect_list:
                secs_pd_dict['status'] = 'Hybrid'
            elif donor_id in uni_ish_list:
                secs_pd_dict['status'] = 'ISH'
            else:
                secs_pd_dict['status'] = 'NISSL'
            secs_pd_dict['empty_sec_val'] = max(secs_pd_dict['section_images_pd']["section_number"]) - len(secs_pd_dict['section_images_pd'].index)
        donor_info_dict[donor_id] = secs_pd_dict    
    print(f"Writing info into file")                
    with open(donor_info_dict_path, 'wb') as f:
        pickle.dump(donor_info_dict, f)
    return donor_info_dict

if __name__ == "__main__":
    print(get_associate_genes_by_donor_id(6219))