from allensdk.core.reference_space_cache import ReferenceSpaceCache
from allensdk.api.queries.ontologies_api import OntologiesApi
from allensdk.core.structure_tree import StructureTree
from allensdk.core.reference_space import ReferenceSpace
from allensdk.api.api import Api
from allensdk.api.api import stream_file_over_http
from new_pro.utils import basic

import SimpleITK as sitk
import pathlib
import typing
import os
import numpy as np
import ants

# CCF_DOWNLOAD_PARENT_LINK = "https://download.alleninstitute.org/informatics-archive"
CCF_DOWNLOAD_PARENT_LINK = Api().informatics_archive_endpoint

def get_other_mouse_reference_space(file_name:str = "DMBA", spacing:int = 25, is_accord:bool = False, in_ara:bool = False, is_force:bool = False):
    '''
    All other altas files are pre-downloaded.
    DMBA: The Duke Mouse Brain Atlas. MRI and light sheet microscopy stereotaxic atlas of the mouse brain.
    WHS: Waxholm Space atlas of the rat brain. a 3D atlas supporting data analysis and integration.
    '''
    from new_pro.prg import vlp
    file_dir = "/home/t207/lab_data_preproc4/allen_data/reference_cache/other"
    if file_name == "DMBA":
        suffix = "DMBA_N02_dwi_M4D"
        raw_spacing = (15,15,15)
    elif file_name == "WHS":
        suffix = "WHS_SD_rat_DWI_v1.01"
        raw_spacing = (39,39,39)
    else:
        raise("error for selecting refernce name")

    raw_file_path = f"{file_dir}/{suffix}.nii.gz"
    file_path = f"{file_dir}/{suffix}_{spacing}um"
    if is_force or not os.path.exists(f"{file_path}.nii.gz"):
        image = sitk.ReadImage(raw_file_path)
        image.SetSpacing(raw_spacing)
        image = vlp.resample_image_specific_spacing(image, (spacing, spacing, spacing))
        sitk.WriteImage(image, f"{file_path}.nii.gz")

    if is_accord:
        image = sitk.ReadImage(f"{file_path}.nii.gz")
        file_path = f"{file_path}_accord"
        if is_force or not os.path.exists(f"{file_path}.nii.gz"):
            image_array = sitk.GetArrayFromImage(image)
            image = sitk.GetImageFromArray(np.flip(image_array.transpose(1,0,2).transpose(2,1,0), axis = [1,2]))
            image.SetSpacing(raw_spacing)
            sitk.WriteImage(image, f"{file_path}.nii.gz")

    if in_ara:
        image = ants.image_read(f"{file_path}.nii.gz")
        file_path = f"{file_path}_in_ara"
        if is_force or not os.path.exists(f"{file_path}.nii.gz"):
            ara_image = ants.image_read(get_reference_vol_path(spacing = spacing))
            image = ants.registration(ara_image, image, "SyN", None, file_path, aff_metric = "mi", syn_metric = "mi", reg_iterations = [800, 200, 100, 10], write_composite_transform = True)['warpedmovout']
            ants.image_write(image, f"{file_path}.nii.gz")
    
    return f"{file_path}.nii.gz"

#TODO. wait for fixing to get other alats. the code is not good. 
def get_reference_vol_path(ref_type:str = "nissl", file_type:typing.Literal["nrrd", "nii.gz"] = "nrrd", spacing:int = 25, file_dir:typing.Optional[str] = None, is_force:bool = False, half:str = "", **other_parameters) -> str:
    '''
        ref_type: nissl, stpt, annotation and others e.g. dess101k64r9b 
    '''
    ref_dir = ref_type
    if file_type == "nii.gz":
        download_link = f"{CCF_DOWNLOAD_PARENT_LINK}/converted_mouse_ccf"
    else:
        download_link = f"{CCF_DOWNLOAD_PARENT_LINK}/current-release/mouse_ccf"
    if ref_type == "stpt":
        download_link = f"{download_link}/average_template/average_template_{spacing}.{file_type}"
    elif ref_type == "nissl":
        download_link = f"{download_link}/ara_nissl/ara_nissl_{spacing}.{file_type}"
    elif ref_type == "annotation":
        download_link = f"{download_link}/annotation/ccf_2017/annotation_{spacing}.{file_type}"
    elif ref_type == "DMBA" or ref_type == "WHS":
        return get_other_mouse_reference_space(ref_type, spacing = spacing, is_force = is_force, **other_parameters)
    else:
        ref_dir = "dlt"
    if not file_dir:
        file_dir = f"{basic.REF_MANIFEST_PATH}/{ref_dir}"
    
    os.makedirs(file_dir, exist_ok = True)
    file_path = f"{file_dir}/{ref_type}_{spacing}.{file_type}"
    #TODO. waiting for fixing the function of checking "dlt", file type and spacing
    if is_force or not os.path.exists(file_path):
        if ref_dir != "dlt":
            print(download_link)
            stream_file_over_http(download_link, file_path)
    if half:
        half_file_path = f"{file_dir}/{half}half_{ref_type}_{spacing}.{file_type}"
        if is_force or not os.path.exists(half_file_path):
            whole_image = sitk.ReadImage(file_path)
            whole_size = whole_image.GetSize()[2]
            half_size = int(whole_size / 2)
            if half == "l":
                whole_image[:, :, half_size:whole_size] = 0
            elif half == "r":
                whole_image[:, :, 0:half_size] = 0
            else:
                raise("half value is set error")
            sitk.WriteImage(whole_image, half_file_path)
        file_path = half_file_path
    return file_path

def get_resample_spacing_rfvol_path(file_path:str, res_file_path:str, spacing:int = 25, is_force:bool = False) -> str:
    if is_force or not os.path.exists(res_file_path):
        vol = sitk.ReadImage(file_path)
        res_vol = sitk.Resample(vol, basic.MOUSE_VOL_SHAPE[spacing], sitk.Transform(), sitk.sitkNearestNeighbor, vol.GetOrigin(), (spacing, spacing, spacing), vol.GetDirection(), 0.0, vol.GetPixelIDValue())
        sitk.WriteImage(res_vol, res_file_path)
    return res_file_path 

def get_boundary_vol_path(spacing:int = 25, file_path:str = "", is_force:bool = False, file_type:typing.Literal["nrrd", "nii.gz"] = "nrrd") -> str:
    '''
        The 10um raw boundary file is from https://alleninstitute.github.io/abc_atlas_access/notebooks/ccf_and_parcellation_annotation_tutorial.html.
        Even now do not find other api of allensdk to donwload this boundary file, so already downloaded the boundary file in the materials dir.  
    '''
    if not file_path:
        file_path = f"{os.path.dirname(__file__)}/materials"   
    file_name = f"annotation_boundary_{spacing}.{file_type}"
    # Beacuse the raw annotation_boundary_10.nii.gz has different direction with of direction of stpt.nrrd or ara_nissl.nrrd,
    # then convert it to has same direction with ara_nissl refernce vol. 
    if not os.path.exists(f"{file_path}/annotation_boundary_10.nrrd"):
        nii_vol = sitk.ReadImage(f"{file_path}/annotation_boundary_10.nii.gz")
        nrrd_vol = sitk.GetImageFromArray(sitk.GetArrayFromImage(nii_vol))
        nrrd_vol.SetSpacing((10, 10, 10))
        sitk.WriteImage(nrrd_vol, f"{file_path}/annotation_boundary_10.nrrd")
    raw_file_name = f"annotation_boundary_10.{file_type}"
    if is_force or not os.path.exists(f"{file_path}/{file_name}"):
        get_resample_spacing_rfvol_path(f"{file_path}/{raw_file_name}", f"{file_path}/{file_name}", spacing = spacing)
    return f"{file_path}/{file_name}"

def get_label_vol_path(spacing:int = 25, file_path:str = "", is_force:bool = False, file_type:typing.Literal["nrrd", "nii.gz"] = "nrrd", ccf_version:str = "ccf_2017") -> str:
    if not file_path:
        file_path = f"{basic.REF_MANIFEST_PATH}/annotation/{ccf_version}"
    os.makedirs(file_path, exist_ok = True)
    file_path = f"{file_path}/annotation_{spacing}.{file_type}"
    if is_force or not os.path.exists(file_path):
        nrrd_link = f"https://download.alleninstitute.org/informatics-archive/current-release/mouse_ccf/annotation/{ccf_version}/annotation_{spacing}.{file_type}"
        nii_link = f"https://download.alleninstitute.org/informatics-archive/converted_mouse_ccf/annotation/{ccf_version}/annotation_{spacing}.{file_type}"
        url = nrrd_link if file_type == "nrrd" else nii_link
        if not stream_file_over_http(url = url, filename = file_path):
            raise RuntimeError("Downloading annotation file fails.")
    return file_path

def make_allensdk_annotation_space(vol:np.ndarray, resolution:int, structure_graph_ids:int = 1):
    # structure_graph_ids, ID 1 is the adult mouse structure graph
    oapi = OntologiesApi()
    structure_graph = oapi.get_structures_with_sets(structure_graph_ids)
    structure_graph = StructureTree.clean_structures(structure_graph)
    tree = StructureTree(structure_graph)
    sspace = ReferenceSpace(tree, vol, resolution)
    return sspace

def get_allensdk_anatomy_acronyms_ids(acronyms:list = [], structure_graph_ids:int = 1) -> list:
    oapi = OntologiesApi()
    structure_graph = oapi.get_structures_with_sets(structure_graph_ids)
    structure_graph = StructureTree.clean_structures(structure_graph)
    tree = StructureTree(structure_graph)
    return [res['id'] for res in tree.get_structures_by_acronym(acronyms)]

def get_allensdk_annotation_tree(resolution:int, manifest_path:str = "") -> tuple:
    '''
        resolution is one int number in (10, 25, 50, 100, 200). If resolution < 200, then could use offical function api for getting reference space. If resolution equals 200um, this is for grid expression and no api support it, then we need download annotation file by manual and construct rfp and tree.
        reference_space_key is in fact the data path in allen web server. This is the url of data: https://download.alleninstitute.org/informatics-archive/current-release/mouse_ccf/annotation/
    '''
    if not manifest_path:
        manifest_path = f"{basic.REF_MANIFEST_PATH}"
    if resolution == 200:
        annotation_200um_file_name = "P56_Mouse_gridAnnotation.zip"
        annotation_200um_file_path = f"{manifest_path}/annotation/{annotation_200um_file_name}"
        os.makedirs(f"{manifest_path}/annotation", exist_ok = True)
        if not os.path.exists(annotation_200um_file_path):
                if not stream_file_over_http(url = f"http://download.alleninstitute.org/informatics-archive/current-release/mouse_annotation/{annotation_200um_file_name}", filename = annotation_200um_file_path):
                    raise RuntimeError("Downloading 200um annotation file fails.")
        annotation_200um = basic.extract_zip_numpy(zip_file_path = annotation_200um_file_path, fn = "gridAnnotation.raw", dtype = "int32")
        oapi = OntologiesApi()
        structure_graph = oapi.get_structures_with_sets(1) # ID 1 is the adult mouse structure graph
        structure_graph = StructureTree.clean_structures(structure_graph) 
        tree = StructureTree(structure_graph)
        rfp = ReferenceSpace(tree, annotation_200um, resolution)
        rfp.remove_unassigned()
        return rfp, tree
            
    reference_space_key = f'annotation/ccf_2017'
    rspc = ReferenceSpaceCache(resolution = resolution, reference_space_key = reference_space_key, manifest = pathlib.Path(manifest_path) / 'manifest.json')
    rspc.get_annotation_volume()
    return rspc.get_reference_space(), rspc.get_structure_tree(structure_graph_id = 1) # ID 1 is the adult mouse structure graph

@DeprecationWarning
def raw_get_boundary_vol_path(spacing:int = 25, file_path:str = "", is_force:bool = False, only_isocortex:bool = False):
    file_name = f"isocortex_boundary" if only_isocortex else f"annotation_boundary"
    raw_boundary_file_path = f"{file_path}/{file_name}_{10}.nii.gz"
    boundary_file_path = f"{file_path}/{file_name}_{spacing}.nrrd"
    if not os.path.exists(raw_boundary_file_path):
        basic.download_file("https://download.alleninstitute.org/informatics-archive/current-release/mouse_ccf/cortical_coordinates/ccf_2017/")
    return get_resample_spacing_rfvol_path(raw_boundary_file_path, boundary_file_path, spacing, is_force) 

@DeprecationWarning
def raw_get_isocortex_mask_vol(spacing = 25, file_path = '/home/t207/Lab_Data_preproc2/allen_data/ccf_files', is_force = False):
    # TODO. Need to fix the local boundary file for downloading
    raw_mask_file_path = f"{file_path}/isocortex_mask_10.nii.gz"
    mask_file_path = f"{file_path}/isocortex_mask_{spacing}.nrrd"
    return get_resample_spacing_rfvol_path(raw_mask_file_path, mask_file_path, spacing, is_force)

@DeprecationWarning
def old_get_reference_vol_path(ref_type:typing.Literal["nissl", "stpt", "annotation", "dlt"] = "nissl", file_type:typing.Literal["nrrd", "nii.gz"] = "nrrd", spacing:int = 25, file_dir:typing.Optional[str] = None, dlt_name:str = "des101k64r9b", is_force:bool = False) -> str:
    if not file_dir:
        file_dir = f"{basic.REF_MANIFEST_PATH}/{ref_type}"
    os.makedirs(file_dir, exist_ok = True)
    file_path = f"{file_dir}/{ref_type}_{spacing}.{file_type}"
    if is_force or not os.path.exists(file_path):
        if file_type == "nii.gz":
            download_link = f"{CCF_DOWNLOAD_PARENT_LINK}/converted_mouse_ccf"
        else:
            download_link = f"{CCF_DOWNLOAD_PARENT_LINK}/current-release/mouse_ccf"
        if ref_type == "stpt":
            download_link = f"{download_link}/average_template/average_template_{spacing}.{file_type}"
        if ref_type == "nissl":
            download_link = f"{download_link}/ara_nissl/ara_nissl_{spacing}.{file_type}"
        if ref_type == "annotation":
            download_link = f"{download_link}/annotation/ccf_2017/annotation_{spacing}.{file_type}"
        print(download_link)
        stream_file_over_http(download_link, file_path)
    return file_path