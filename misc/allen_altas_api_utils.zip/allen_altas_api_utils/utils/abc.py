import os
import json
import anndata
import abc_atlas_access
import concurrent
import typing
import pathlib
import numpy as np

# import new_pro.utils.basic as basic
from abc_atlas_access.abc_atlas_cache.abc_project_cache import AbcProjectCache

# ABC_MANIFEST_PATH = basic.PATH_PRFIX + "/" + "abc_data"
ABC_MANIFEST_PATH = "/home/t207/Lab_Data_preproc2/allen_data" + "/" + "abc_data"

ALLEN_CCF = 'Allen-CCF-2020'
ALLEN_CCF_FILES = ['average_template_10', 'annotation_10', 'annotation_boundary_10']
SP_DATASETS = ['Zhuang-ABCA-1', 'Zhuang-ABCA-2', 'Zhuang-ABCA-3', 'Zhuang-ABCA-4', 'MERFISH-C57BL6J-638850', 'MERFISH-C57BL6J-638850-imputed']
ALLEN_CCF_FILENAME = 'ccf_coordinates'
GENE_EXPR_NUMERIC_TYPES = ['log2', 'raw']

def get_abc_cache(manifest_path:str = ABC_MANIFEST_PATH, is_check_downloaded_data_json:bool = False) -> abc_atlas_access.abc_atlas_cache.abc_project_cache.AbcProjectCache:
    if not os.path.exists(manifest_path):
        os.makedirs(manifest_path)

    # if have downloaded data, and changed the path in somewhere, then the all data paths in "/_downloaded_data.json" must be also changed to the new path in coord with the new manifest_path.  
    # offical api will not change it by itself.  
    download_data_json_path = manifest_path + "/_downloaded_data.json"
    if os.path.exists(download_data_json_path) and is_check_downloaded_data_json:
        with open(download_data_json_path, "r") as f:
            data_paths = json.load(f)
        if data_paths:
            data_path = data_paths[0]
            # TODO.  use simple key words to get the path prefix.  
            for key_word in ["expression_matrices", "image_volumes", "mapmycells", "metadata"]:
                if key_word in data_path:
                    old_manifest_prefix_right_border = data_path.index(key_word)
                    break
            old_manifest_path = data_path[:old_manifest_prefix_right_border]
            new_data_paths = []
            for data_path in data_paths: 
                if old_manifest_path in data_path:
                    new_data_paths.append(data_path.replace(old_manifest_path, manifest_path + "/"))
            with open(download_data_json_path,"w") as f:
                json.dump(new_data_paths, f)

    return AbcProjectCache.from_s3_cache(pathlib.Path(manifest_path))


def get_abc_cache(manifest_path:str = ABC_MANIFEST_PATH, is_check_downloaded_data_json:bool = False) -> abc_atlas_access.abc_atlas_cache.abc_project_cache.AbcProjectCache:
    if not os.path.exists(manifest_path):
        os.makedirs(manifest_path)

    # if have downloaded data, and changed the path in somewhere, then the all data paths in "/_downloaded_data.json" must be also changed to the new path in coord with the new manifest_path.  
    # offical api will not change it by itself.  
    download_data_json_path = manifest_path + "/_downloaded_data.json"
    if os.path.exists(download_data_json_path) and is_check_downloaded_data_json:
        with open(download_data_json_path, "r") as f:
            data_paths = json.load(f)
        if data_paths:
            data_path = data_paths[0]
            # TODO.  use simple key words to get the path prefix.  
            for key_word in ["expression_matrices", "image_volumes", "mapmycells", "metadata"]:
                if key_word in data_path:
                    old_manifest_prefix_right_border = data_path.index(key_word)
                    break
            old_manifest_path = data_path[:old_manifest_prefix_right_border]
            new_data_paths = []
            for data_path in data_paths: 
                if old_manifest_path in data_path:
                    new_data_paths.append(data_path.replace(old_manifest_path, manifest_path + "/"))
            with open(download_data_json_path,"w") as f:
                json.dump(new_data_paths, f)

    return AbcProjectCache.from_s3_cache(pathlib.Path(manifest_path))

def get_abc_all_data(abc_cache:typing.Optional[abc_atlas_access.abc_atlas_cache.abc_project_cache.AbcProjectCache], skip_hash_check:bool = True, force_download:bool = False, max_workers:int = 8) -> bool:
    def work_download_function(item):
        try:
            abc_cache.get_directory_data(directory = item, skip_hash_check = skip_hash_check, force_download = force_download)
        except:
            abc_cache.get_directory_metadata(directory = item, skip_hash_check = skip_hash_check, force_download = force_download)

    '''manifest_path is the path for data storing'''
    if abc_cache is None:  
        return False
    abc_cache.load_latest_manifest()
    with concurrent.futures.ThreadPoolExecutor(max_workers = max_workers) as executor:
        futs = [executor.submit(work_download_function, item = item) for item in abc_cache.list_directories]
        for _ in concurrent.futures.as_completed(futs):
            pass
    return True

def convert_pixel_continuous_coordinates_to_voxels_index(coordinate:typing.Union[np.ndarray, float], spacing:typing.Union[np.ndarray, float] = 10) -> typing.Union[np.ndarray, float]:

    return np.floor((np.around(coordinate, 3) + (spacing / 2)) / spacing)

def convert_ccf_coordinates_to_voxels_index(coordinate:typing.Union[np.ndarray, float], spacing:typing.Literal[10, 25, 50, 100, 200] = 10) -> typing.Union[np.ndarray, np.float64]:
    '''
        For that convert every cell's ccf coordinate(x, y, z) to the indexs of voxels in the Allen CCFv3 10um's template. 
        For example, if spacing is 10um, the defualte extent for the coordinates of voxels in template is (-0.5 * spacing[0], (size[0]-0.5) * spacing[0], (size[1]-0.5) * spacing[1], -0.5 * spacing[1])
        size: (1320, 800, 1140) voxels
        spacing: (0.001, 0.001, 0.001) mm
    '''
    # spacing is the params of 10um, 25um, 50um, 100um, 200um
    # return np.floor((np.around(x, 3) + 0.005) /  ((spacing / 10) * 0.01))
    return convert_pixel_continuous_coordinates_to_voxels_index(coordinate, spacing * 0.001)

def get_abc_sp_h5ad_by_ccf_voxel_index(DatasetName:typing.Literal['Zhuang-ABCA-1', 'Zhuang-ABCA-2', 'Zhuang-ABCA-3', 'Zhuang-ABCA-4', 'MERFISH-C57BL6J-638850', 'MERFISH-C57BL6J-638850-imputed'], VoxelKind:typing.Literal['x', 'y', 'z', 'X', 'Y', 'Z'], VoxelSliceIndex:int, QueryGeneSymbols:list, GeneExprNumericType:typing.Literal['log2', 'raw']) -> anndata.AnnData:
    '''
        Different VoxelKind decide which direction will be selected and VoxelSliceIndex decide which Nth slices in this directrion to return. 
        i.e. VoxelKind is "x" and VoxelSliceIndex is 260, repsent that the 260th slice along the ML is selected.  
        The Common Coordinate Framework (CCF) is defined in a basic image coordinate system, using the top-left-rear pixel as its origin, and incrementing in the X, Y and Z axes up to the number of pixels in each dimension (ML, DV, AP respectively).  
    '''
    VoxelKind = str.lower(VoxelKind)
    voxel_index_name = VoxelKind+'_voxels_index'
    abc_cache = get_abc_cache()

    DatasetNameCCF = DatasetName + '-CCF' if DatasetName != 'MERFISH-C57BL6J-638850-imputed' else 'MERFISH-C57BL6J-638850' + '-CCF'
    ccf_coordinates = abc_cache.get_metadata_dataframe(DatasetNameCCF, file_name = 'ccf_coordinates')
    ccf_coordinates[voxel_index_name] = convert_ccf_coordinates_to_voxels_index(ccf_coordinates[VoxelKind])
    query_cell_labels = list(ccf_coordinates['cell_label'][ccf_coordinates[voxel_index_name] == VoxelSliceIndex])
    if len(query_cell_labels) == 0:
        raise RuntimeError(f"{DatasetName} does not have the cells on the {VoxelKind} direction of {VoxelSliceIndex}th slices!")
    # print(f"Number of query cell is {len(query_cell_labels)}")

    expression_h5data_filenames = [filename for filename in abc_cache.list_data_files(DatasetName) if filename.count(GeneExprNumericType)]
    if not expression_h5data_filenames:
        print(abc_cache.list_data_files(DatasetName)) 
        raise RuntimeError(f"{DatasetName} does not have the {GeneExprNumericType} type expression file!")

    expression_h5data = anndata.read_h5ad(abc_cache.get_data_path(directory = DatasetName, file_name = expression_h5data_filenames[0]), backed='r')
    contain_gene_symbol = [gs for gs in QueryGeneSymbols if np.isin(gs, expression_h5data.var['gene_symbol'])]

    if not contain_gene_symbol:
        raise RuntimeError(f"Your query gene symbols is not in the {DatasetName}!")
    
    not_contain_gene_symbol = [gs for gs in QueryGeneSymbols if not np.isin(gs, expression_h5data.var['gene_symbol'])]
    if not_contain_gene_symbol:
        print(f"There has {len(not_contain_gene_symbol)} gene symbol is not in the {DatasetName}:")
        print(not_contain_gene_symbol)

    # Always error in this code, so use another way to get result.
    # expression_query_anndatas = expression_h5data[query_cell_labels, list(expression_h5data.var.query('gene_symbol in @QueryGeneSymbols').index)].to_memory()

    expression_query_anndata_list = []
    for gs in contain_gene_symbol:
        # Only the index of gene symbol in h5ad data could be used for select.    
        gs_index = list(expression_h5data.var.loc[expression_h5data.var['gene_symbol'] == gs].index)[0]
        expression_query_anndata = expression_h5data[query_cell_labels, gs_index].to_memory()
        expression_query_anndata_list.append(expression_query_anndata)

    expression_h5data.file.close()
    expression_query_anndatas = anndata.concat(expression_query_anndata_list, axis = 1, join = 'inner', merge = 'same').to_memory()

    return expression_query_anndatas