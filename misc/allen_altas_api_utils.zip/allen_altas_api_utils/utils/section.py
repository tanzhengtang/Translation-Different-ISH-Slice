import typing
import os
import numpy as np
import concurrent
import SimpleITK as sitk

from allensdk.api.queries.grid_data_api import GridDataApi
from allensdk.api.queries.image_download_api import ImageDownloadApi
from allensdk.core.mouse_connectivity_cache import MouseConnectivityCache
from allensdk.api.queries.synchronization_api import SynchronizationApi
from utils import basic


def get_close_altas_image_sec_id(sec_id:int, altas_id:int = 1) -> int:
    SynApi = SynchronizationApi()
    return SynApi.get_image_to_atlas(sec_id, 0, 0, altas_id)['image_sync']['section_image_id']

def get_section_dataset_ids(criteria:str) -> list:
    # SectionDataSet of Allen is a very big dataset contains differen subsets. i.e. conn data, ish data.  
    # how to use criteria to find the id you want, please see: 
    # https://allensdk.readthedocs.io/en/latest/data_api_client.html and
    # http://api.brain-map.org/api/v2/data/SectionDataSet/describe.xml
    return [sec_info['id'] for sec_info in basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = criteria, only = ['id'])]

def get_section_dataset_gene_acronym(sec_id:int) -> str:
    # TODO. this simple script for accessing gene symbol. 
    return basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria=f"[id$eq{sec_id}]", include = 'genes')[0]['genes'][0]['acronym']

def download_section_dataset_images(sec_id:int, query_type:typing.Literal['altas','section_data_set'] = 'section_data_set',  file_path:str = "", view:typing.Literal["raw", "expression", "projection", "tumor_feature_annotation", "tumor_feature_boundary"] = "raw") -> list:
    '''
    Ref: https://community.brain-map.org/t/downloading-an-image/2865  
    img_info: RMA.model_query('SectionImage', num_rows = 'all', criteria = criteria, include = include)
    '''    
    file_path = basic.SECTION_IMG_DATA_PATH if not file_path else file_path
    imapi = ImageDownloadApi()
    if query_type == 'altas':
        query_image_function = imapi.atlas_image_query
        store_path = f'{file_path}/altas/{sec_id}'
        '''allensdk.api.queries.ontologies_api.OntologiesApi.get_atlases` can also be used to list atlases along with their ids.'''
    else:
        query_image_function = imapi.section_image_query
        store_path = f"{file_path}/{sec_id}/{view}"

    img_ids = [it['id'] for it in query_image_function(sec_id)]

    if not os.path.exists(store_path):
        os.makedirs(store_path)

    img_downloaded_list = []
    for image_id in img_ids:
        img_download_path = f"{store_path}/{image_id}.jpg"
        if basic.recon_download_image(image_id = image_id, view = view, file_path = img_download_path):
            img_downloaded_list.append(img_download_path)

    return img_downloaded_list

def parallel_download_section_dataset_image(sec_ids:list, file_path:str = "", n_process:int = 8, view = 'raw'):
    file_path = basic.SECTION_IMG_DATA_PATH if not file_path else file_path
    with concurrent.futures.ThreadPoolExecutor(max_workers = n_process) as excutor:
        futs = [excutor.submit(download_section_dataset_images, sec_id = sec_id, view = view, file_path = file_path) for sec_id in sec_ids]
        for _ in concurrent.futures.as_completed(futs):
            pass

def get_ish_nissl_sec_ids(plane:typing.Literal["sagittal","coronal","both"], product:typing.Literal[1,3], treatments:typing.Literal["ISH", "NISSL"]):
    if plane == "both":
        criteria = f"[failed$eq'false'], products[id$eq{product}], treatments[name$eq'{treatments}']"
    else:
        criteria = f"[failed$eq'false'], products[id$eq{product}], plane_of_section[name$eq'{plane}'], treatments[name$eq'{treatments}']" 
    return get_section_dataset_ids(criteria)

def get_ish_plane_ids(plane, product):
    # ISH data is part of SectionDataSet in Allen. 
    # product param value just in [1,3], 1 for adult mouse, 3 for develop mouse. 
    # plane param value coulde see: https://community.brain-map.org/t/api-for-mouse-brain-atlas/2766. 
    return get_ish_nissl_sec_ids(plane, product, "ISH")

def get_ish_grid_data(sec_id:int, file_path:str = "", volume_type:typing.Literal['energy', 'density', 'intensity'] = 'energy') -> np.ndarray:
    
    file_path = basic.ISH_GRID_DATA_PATHif if not file_path else file_path
    final_file_path = f"{file_path}/{sec_id}.zip" if volume_type == 'energy' else f"{file_path}/{sec_id}_{volume_type}.zip" 
    if not os.path.exists(final_file_path):
        gaai = GridDataApi()
        '''Note: GridDataApi.download_gene_expression_grid_data function will download the zip file and auto extract the files of zip. In fact it use the retrieve_file_over_http(url, path, zipped=True) to get the zip file. Here change the zipped=True to zipped=False in source code to prevent the auto-extract, just get the zip file.'''
        gaai.download_gene_expression_grid_data(sec_id, volume_type, final_file_path) 
        
    return basic.extract_zip_numpy(final_file_path, f"{volume_type}.raw", "float32")        
        
def download_projection_grid(exp_id:int, resolution:typing.Literal[10, 25, 50, 100, 200] = 10, file_path:str = "", data_type:typing.Literal['projection_density', 'projection_energy', 'injection_fraction', 'injection_density', 'injection_energy', 'data_mask'] = "projection_energy", is_cache:bool = True, proj_file_name:str = "", data_mask:bool = True) -> typing.Union[str, tuple]:
    
    file_path = basic.SECTION_CON_DATA_PATH if not file_path else file_path
    grid_api = GridDataApi()
    if not proj_file_name:
        proj_file_name = f"{file_path}/{exp_id}/{data_type}_{resolution}.nrrd"
    if not os.path.exists(proj_file_name) or os.path.getsize(proj_file_name) < 1024:
        is_cache = False
    if not is_cache:
        if not os.path.exists(file_path + "/" + f"{exp_id}"):
            os.makedirs(file_path + "/" + f"{exp_id}")
        if resolution == 200:
            proj_file_100um_name = f"{file_path}/{exp_id}/{data_type}_{100}.nrrd"
            if not os.path.exists(proj_file_100um_name):
                grid_api.download_projection_grid_data(exp_id, [data_type], 100, proj_file_100um_name)
            proj_vol = sitk.ReadImage(proj_file_100um_name)
            proj_vol = sitk.Resample(proj_vol, basic.MOUSE_VOL_SHAPE[200], sitk.Transform(), sitk.sitkNearestNeighbor, proj_vol.GetOrigin(), [200, 200, 200], proj_vol.GetDirection(), 0.0, outputPixelType = proj_vol.GetPixelIDValue())
            sitk.WriteImage(proj_vol, proj_file_name)
        else:
            grid_api.download_projection_grid_data(exp_id, [data_type], resolution, proj_file_name)

    if data_mask:
        data_mask_file_name = f"{file_path}/{exp_id}/data_mask_{resolution}.nrrd"
        if not os.path.exists(data_mask_file_name) or os.path.getsize(data_mask_file_name) < 1024:
            if resolution == 200:
                data_mask_100um_file_name = f"{file_path}/{exp_id}/data_mask_{100}.nrrd"
                if not os.path.exists(data_mask_100um_file_name):
                    grid_api.download_projection_grid_data(exp_id, ["data_mask"], 100, data_mask_100um_file_name)
                data_mask_vol = sitk.ReadImage(data_mask_100um_file_name)
                data_mask_vol = sitk.Resample(data_mask_vol, basic.MOUSE_VOL_SHAPE[200], sitk.Transform(), sitk.sitkNearestNeighbor, data_mask_vol.GetOrigin(), [200, 200, 200], data_mask_vol.GetDirection(), 0.0, outputPixelType = data_mask_vol.GetPixelIDValue())
                sitk.WriteImage(data_mask_vol, data_mask_file_name)
            else:
                grid_api.download_projection_grid_data(exp_id, ["data_mask"], resolution, data_mask_file_name)

        return proj_file_name, data_mask_file_name

    return proj_file_name

def download_all_projection_grid(n_thread:int = 16, injection_structure_ids:typing.Optional[list] = None, cre:typing.Optional[list] = None, resolution:int = 10, file_path:str = "", data_type:str = "projection_energy") -> list:
    
    file_path = basic.SECTION_CON_DATA_PATH if not file_path else file_path
    mcc = MouseConnectivityCache(resolution = resolution, manifest_file = file_path + '/' + 'manifest.json')
    proj_ids = list(mcc.get_experiments(dataframe = True, cre = cre, injection_structure_ids = injection_structure_ids).id)
    download_paths = []

    with concurrent.futures.ThreadPoolExecutor(max_workers = n_thread) as excutor:
        futs = [excutor.submit(download_projection_grid, exp_id = exp_id, resolution = resolution, cache_dir = file_path, data_type = data_type) for exp_id in proj_ids]
        for fut in concurrent.futures.as_completed(futs):
            download_paths.append(fut.result()[data_type])

    return download_paths