# %%
import requests
import zipfile
import os
import time
import shutil
import numpy as np

from allensdk.api.queries.rma_api import RmaApi
from allensdk.api.queries.image_download_api import ImageDownloadApi
from allensdk.api.queries.synchronization_api import SynchronizationApi

# %%
# All the global path will be set real value in 'set_path_prefix' function.
PATH_PRFIX, REF_MANIFEST_PATH, SECTION_IMG_DATA_PATH, ISH_GRID_DATA_PATH, SECTION_CON_DATA_PATH, DONOR_VOL_DATA_PATH, EXP_VOL_DATA_PATH, REG_VOL_DATA_PATH = "", "", "", "", "", "", "", ""
# The Common Coordinate Framework (CCF) is defined in a basic image coordinate system, using the top-left-rear pixel as its origin, and incrementing in the X, Y and Z axes up to the number of pixels in each dimension (ML, DV, AP respectively).
MOUSE_REF_PLANES_INDEX = ["coronal", "horizontal", "sagittal"] 
MOUSE_VOL_SHAPE = { # RES : (AP,DV,ML)
        10 : (1320, 800, 1140),
        25 : (528, 320, 456),
        50 : (264, 160, 228),
        100 : (132, 80, 114),
        200 : (67, 41, 58)
        }
MOUSE_ISH_GRID_SHAPE = (58, 41, 67) # (ML, DV, AP)
SAG_NO_ENERGY_ID = [1013, 822, 526, 819, 784, 1267, 1426, 813, 375, 639, 386, 442, 695, 627, 564] # Note: those IDs is sagital plane ISH grid data and have no energy voulume type data.

WRONG_SLI_SORT_DONOR_ID = [6130, 7469, 7502, 7771, 6053]
WARN_DENOISE_DONOR_ID = [6652, 6850, 7026, 7045, 7070, 7143, 7368, 7440, 7441, 7466, 7478, 7479, 7491, 7498, 7504, 7746, 8009]
REDO_DENOISE_DONOR_ID = [7401]

# %%
def set_path_prefix(path_prefix:str = "/home/t207/lab_data_preproc4/allen_data", ref_manifest_path_name:str = "reference_cache", section_img_path_name:str = "img_data", ish_grid_path_name:str = "ish_data", section_conn_path_name:str = "con_data", donor_vol_path_name:str = "donor_vol", exp_vol_path_name:str = "exp_vol", reg_vol_path_name = "reg_vol"):
    # TODO. waiting for fixing reg_vol_path
    globals()["PATH_PRFIX"] = path_prefix
    globals()["REF_MANIFEST_PATH"] = globals()["PATH_PRFIX"] + "/" + ref_manifest_path_name
    globals()["SECTION_IMG_DATA_PATH"] = globals()["PATH_PRFIX"] + "/" + section_img_path_name
    globals()["ISH_GRID_DATA_PATH"] = globals()["PATH_PRFIX"] + "/" + ish_grid_path_name
    globals()["SECTION_CON_DATA_PATH"] = globals()["PATH_PRFIX"] + "/" + section_conn_path_name
    globals()["DONOR_VOL_DATA_PATH"] = globals()["PATH_PRFIX"] + "/" + donor_vol_path_name
    globals()["EXP_VOL_DATA_PATH"] = globals()["PATH_PRFIX"] + "/" + exp_vol_path_name
    # globals()["REG_VOL_DATA_PATH"] = globals()["PATH_PRFIX"] + "/" + reg_vol_path_name
    globals()["REG_VOL_DATA_PATH"] = "/home/t207/Lab_Data_preproc3/allen_data" + "/" + reg_vol_path_name


set_path_prefix()

def find_files_with_suffix(directory, suffix):
    matching_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(suffix):
                matching_files.append(os.path.join(root, file))
    return matching_files

def clear_folder(folder_path:str):
    if not os.path.exists(folder_path):
        print("the dir does not exists")
        return
    
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print(f"has a error when delete {file_path}: {e}")

def download_file(url:str, filename:str) -> bool:
    # Send a GET request to the URL
    response = requests.get(url)
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Open the file in binary write mode and write the content from the response
        with open(filename, 'wb') as file:
            file.write(response.content)
        return True
    return False

def check_internet_status() -> bool:
    response = requests.get('https://www.baidu.com', timeout=10)
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        return True
    return False

def extract_zip_numpy(zip_file_path:str, fn:str, dtype:str = "float32") -> np.ndarray:
    with zipfile.ZipFile(zip_file_path, mode="r") as archive:
        buf = archive.read(fn)
        var = np.frombuffer(buf, dtype = dtype, count = -1)
    return var

def write_zip_numpy(var:np.ndarray, zip_file_path:str, zn:str = 'energy.raw'):
    fn = "tmpfile"
    with zipfile.ZipFile(zip_file_path, mode = "w", compression = zipfile.ZIP_DEFLATED, compresslevel = 9) as archive:
        with open(fn, "wb") as f:
            var.tofile(f)
        archive.write(filename = fn, arcname = zn)
    os.remove(fn)

def remove_empty_dirs(path:str):
    if not os.path.exists(path):
        return
    
    if not os.path.isdir(path):
        return
    
    if not os.listdir(path):
        print(f'Deleting empty directory: {path}')
        os.rmdir(path)
    else:
        for item in os.listdir(path):
            item_path = os.path.join(path, item)
            remove_empty_dirs(item_path)
# %%
def recon_allen_function(allen_sdk_function, query_times = 10, sleep_times = 2, *args, **kwargs):
    while query_times:
        try:
            res_info = allen_sdk_function(*args, **kwargs)
            return res_info
        except:
            query_times = query_times - 1
            time.sleep(sleep_times)
    if query_times == 0:
        print(f"the connection of from allen web site is broken, please check again")
    return ""
    
def recon_model_query(query_times:int = 10, sleep_times:int = 2, *args, **kwargs):
    RMA = RmaApi()
    return recon_allen_function(RMA.model_query, query_times = query_times, sleep_times = sleep_times, *args, **kwargs)

def recon_download_image(image_id:int, view:str, file_path:str, log_path:str = "./", check_size:int = 4096, query_times:int = 3, sleep_times:int = 2, *args, **kwargs) -> bool:
    view = None if view == "raw" else view
    imapi = ImageDownloadApi()
    abs_dir, _ = os.path.split(file_path)
    os.makedirs(abs_dir, exist_ok = True)
    download_times = 3
    while (not os.path.exists(file_path) or os.path.getsize(file_path) < check_size) and download_times:
        recon_allen_function(imapi.download_image, query_times = query_times, sleep_times = sleep_times, image_id = image_id, view = view, file_path = file_path, *args, **kwargs)
        download_times = download_times - 1
    if not download_times:
        log_file_path = os.path.join(log_path, 'download_image.log')
        with open(log_file_path, 'a') as log_file:
            log_file.write(f"{file_path} is less {check_size} KB, check it\n")
            print("the download image seems to be failed, please check the image status and log!")
        return False
    else:
        print(f"{file_path} already download!")
    return True