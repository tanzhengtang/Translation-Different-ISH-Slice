import os
import SimpleITK as sitk

from new_pro.prg import vlp
from new_pro.prg import info
from new_pro.utils import basic

CGAN_PATH = "/home/t207/Lab_Data_preproc2/allen_data/code/deep-learning-package/cgan"

def make_single_donor_data_set_of_ish_to_nissl(donor_id:int, file_path:str = ".", is_aligned:bool = False, **donor_parameters):
    ish_dir = f"{file_path}/trainA"
    nissl_dir = f"{file_path}/trainB"
    os.makedirs(ish_dir, exist_ok = True)
    os.makedirs(nissl_dir, exist_ok = True)
    associate_nissl_info = info.get_donors_ish_associate_nissl_info()[donor_id]
    donor_vol = sitk.ReadImage(vlp.get_donor_brain_vol_path(donor_id, is_tvr = False, is_dl = False, is_accord = False, **donor_parameters))
    for ish_sec, nissl_info in associate_nissl_info['section_number_of_ish_to_associate_nissl_info'].items():
        nissl_sec = nissl_info['associate_nissl_image_section_number']
        sitk.WriteImage(donor_vol[:,:, ish_sec], f"{ish_dir}/{donor_id}_{ish_sec}.png")
        if is_aligned:
            sitk.WriteImage(donor_vol[:,:, nissl_sec], f"{nissl_dir}/{donor_id}_{ish_sec}.png")
        else:
            sitk.WriteImage(donor_vol[:,:, nissl_sec], f"{nissl_dir}/{donor_id}_{nissl_sec}.png")
    return donor_id

def make_sec_data_set_of_ish_to_nissl(sec_id:int, file_path:str = ".", **donor_parameters):
    ish_dir = f"{file_path}/trainA"
    nissl_dir = f"{file_path}/trainB"
    os.makedirs(ish_dir, exist_ok = True)
    os.makedirs(nissl_dir, exist_ok = True)
    from new_pro.utils import basic
    sec_info = basic.recon_model_query(model = 'SectionDataSet', num_rows = 'all', criteria = f"[id$eq'{sec_id}']", include = f'specimen, section_images')
    donor_id = sec_info[0]['specimen']['donor_id']
    associate_nissl_info = info.get_donors_ish_associate_nissl_info()[donor_id]
    donor_vol = sitk.ReadImage(vlp.get_donor_brain_vol_path(donor_id, is_tvr = False, is_dl = False, is_accord = False, **donor_parameters))
    for image_info in sec_info[0]['section_images']:
        nissl_sec = associate_nissl_info['section_number_of_ish_to_associate_nissl_info'][image_info['section_number']]['associate_nissl_image_section_number']
        sitk.WriteImage(donor_vol[:,:, image_info['section_number']], f"{ish_dir}/{sec_id}_{image_info['section_number']}.png")
        sitk.WriteImage(donor_vol[:,:, nissl_sec], f"{nissl_dir}/{sec_id}_{nissl_sec}.png")
    return file_path

def run_cgan_train_process(dataset_path:str, net_name:str = "", is_rm_data:bool = False, model:str = "cycle_gan", netG:str = "resnet_9blocks", gpu_ids:str = "0", dataset_mode:str = "unaligned", nc:int = 3, ngdf:int = 64, batch_size:int = 5, n_epochs:int = 85, n_epochs_decay:int = 85, init_type:str = "kaiming", convert_RGB:str = "N", continue_train:bool = False):
    if not net_name:
        _, n1 = os.path.split(dataset_path)
        n2 = f"k{ngdf}"
        n3 = "r9b" if netG == "resnet_9blocks" else "r6b"
        net_name = f"{n1}_{n2}_{n3}"
    command_list = []
    command_list.append(f"python3 train.py --model {model} --dataroot {dataset_path} --name {net_name} --dataset_mode {dataset_mode} --netG {netG} --gpu_ids {gpu_ids} --input_nc {nc} --output_nc {nc} --preprocess none --no_flip --no_html --num_threads 16 --ndf {ngdf} --ngf {ngdf} --batch_size {batch_size} --n_epochs {n_epochs} --n_epochs_decay {n_epochs_decay} --init_type {init_type} --convert_RGB {convert_RGB}")
    if continue_train:
        command_list.append("--continue_train")
    command = str.join(" ", command_list)
    print(f"train command is: {command}")
    os.chdir(CGAN_PATH)
    print("change work path to:", os.getcwd())
    os.system(command)
    if is_rm_data:
        import shutil
        shutil.rmtree(dataset_path)
    return True

def get_ssec_dl_vol(donor_id:int, file_path:str = "", is_denoise:bool = False, is_force:bool = False) -> str:
    if not file_path:
        file_path = f"{basic.DONOR_VOL_DATA_PATH}/{donor_id}"
    os.makedirs(file_path, exist_ok = True)
    prefix = "dn_" if is_denoise else ""
    file_name = f"ss_secdl_k64_r9b_denoise.nii.gz" if is_denoise else f"ss_secdl_k64_r9b.nii.gz"
    file_path = f"{file_path}/{file_name}"
    if is_force or not os.path.exists(file_path):
        dl_sec_list = []
        sec_ids = [sec_id for _, sec_id in info.get_associate_genes_by_donor_id(donor_id).items()]
        for sec_id in sec_ids:
            sec_vol = sitk.ReadImage(vlp.get_ish_vol_path(sec_id, view = "raw", is_denoise = is_denoise, is_grid = False))
            pth_file = f"{CGAN_PATH}/checkpoints/{prefix}sec{sec_id}_k64_r9b/latest_net_G_A.pth"
            dl_sec_list.append(vlp.get_cgan_convert_vol(sec_vol, ngf = 64, pth_file = pth_file))
        dl_vol = 0
        for dv in dl_sec_list:
            dl_vol = dv + dl_vol
        sitk.WriteImage(dl_vol, file_path)
    return file_path

@DeprecationWarning
def old_run_cgan_train_process(donor_id, is_denoise:bool = False, is_rm_data:bool = False, model:str = "cycle_gan", dataset_path:str = "", net_name:str = "", netG:str = "resnet_9blocks", gpu_ids:str = "0", dataset_mode:str = "unaligned", nc:int = 3, ngdf:int = 64, batch_size:int = 5, n_epochs:int = 85, n_epochs_decay:int = 85, init_type:str = "kaiming", convert_RGB:str = "N", continue_train:bool = False):

    dir_suffix = "_denoise" if is_denoise else ""
    if not dataset_path:
        dataset_path = f"{CGAN_PATH}/datasets/ish/{donor_id}{dir_suffix}"
    make_single_donor_data_set_of_ish_to_nissl(donor_id, dataset_path, is_denoise = is_denoise)
    if not net_name:
        n1 = f"{donor_id}{dir_suffix}"
        n2 = f"k{ngdf}"
        n3 = "r9b" if netG == "resnet_9blocks" else "r6b"
        net_name = f"{n1}_{n2}_{n3}"
    command_list = []
    command_list.append(f"python3 train.py --model {model} --dataroot {dataset_path} --name {net_name} --dataset_mode {dataset_mode} --netG {netG} --gpu_ids {gpu_ids} --input_nc {nc} --output_nc {nc} --preprocess none --no_flip --no_html --num_threads 16 --ndf {ngdf} --ngf {ngdf} --batch_size {batch_size} --n_epochs {n_epochs} --n_epochs_decay {n_epochs_decay} --init_type {init_type} --convert_RGB {convert_RGB}")
    if continue_train:
        command_list.append("--continue_train")
    command = str.join(" ", command_list)
    print(f"train command is: {command}")
    os.chdir(CGAN_PATH)
    print("change work path to:", os.getcwd())
    os.system(command)
    if is_rm_data:
        import shutil
        shutil.rmtree(dataset_path)
    return donor_id