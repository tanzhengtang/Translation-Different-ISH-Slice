from prg import info
from allensdk.api.queries.synchronization_api import SynchronizationApi

if __name__ == "__main__":
    # print(info.get_associate_genes_by_donor_id(6219))
    SynApi = SynchronizationApi()
    print(SynApi.get_image_to_atlas(69750516, 0, 0, 1))